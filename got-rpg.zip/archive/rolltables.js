// module/logic/rolltables.js
// Rolltabellen-System für GoT RPG - Modular und entfernbar
// Kann jederzeit ohne Konflikte deaktiviert/entfernt werden

/**
 * Rolltabellen-Daten
 */
export const ROLLTABLES = {
  intrigen: {
    name: "Intrigen-Ereignisse",
    description: "Zufällige Intrigen und politische Verwicklungen",
    entries: [
      "Ein Spion wird in den eigenen Reihen entdeckt",
      "Ein Komplott gegen einen Verbündeten wird aufgedeckt",
      "Kompromittierende Briefe fallen in die falschen Hände",
      "Ein Gerücht über einen Skandal verbreitet sich am Hof",
      "Ein ehemaliger Feind macht ein überraschendes Friedensangebot",
      "Ein Attentatsversuch schlägt fehl, der Auftraggeber bleibt unbekannt",
      "Eine arrangierte Hochzeit wird in letzter Minute abgesagt",
      "Ein wichtiger Verbündeter wechselt unerwartet die Seiten",
      "Eine geheime Liaison wird öffentlich bekannt",
      "Ein alter Schwur wird eingefordert",
      "Erpressungsversuche durch einen unbekannten Absender",
      "Ein Bastard erhebt Anspruch auf ein Erbe",
      "Vergiftungsgerüchte bei einem Festmahl",
      "Ein Maester wird der Spionage bezichtigt",
      "Eine politische Gefangene entkommt",
      "Ein Konkurrent verbreitet falsche Gerüchte über deine Familie",
      "Ein junges Familienmitglied verliebt sich in den falschen",
      "Ein alter Feind fordert ein Duell",
      "Geheimdokumente werden gestohlen",
      "Ein vertrauenswürdiger Berater wird bestochen"
    ]
  },

  reise: {
    name: "Reise-Komplikationen",
    description: "Unvorhergesehene Ereignisse auf Reisen",
    entries: [
      "Plötzlicher Wetterumschwung - Sturm oder Schneesturm",
      "Banditen lauern am Wegesrand",
      "Eine wichtige Brücke ist eingestürzt",
      "Wildtiere greifen das Lager an (Wölfe, Bären)",
      "Ein Pferd lahmt oder wird krank",
      "Vorräte sind verdorben oder wurden gestohlen",
      "Der Weg ist durch einen Erdrutsch blockiert",
      "Begegnung mit feindlichen Soldaten oder Deserteuren",
      "Ein Fluss ist über die Ufer getreten",
      "Die Gruppe verirrt sich im Nebel",
      "Ein Mitreisender wird schwer krank",
      "Räuber haben die nächste Herberge überfallen",
      "Ein wichtiger Gegenstand geht verloren",
      "Begegnung mit misstrauischen Dorfbewohnern",
      "Ein Rad am Wagen bricht",
      "Wildlinge werden gesichtet (im Norden)",
      "Eine verlassene Siedlung mit bösen Vorzeichen",
      "Streit innerhalb der Reisegruppe eskaliert",
      "Ein mysteriöser Fremder folgt der Gruppe",
      "Unpassierbares Gelände erzwingt einen Umweg"
    ]
  },

  geruechte: {
    name: "Gerüchte",
    description: "Klatsch und Tratsch aus den Sieben Königslanden",
    entries: [
      "Der Winter naht, und er wird härter als je zuvor",
      "Wildlinge sammeln sich jenseits der Mauer in großer Zahl",
      "Ein Drache wurde im Osten gesichtet",
      "Die Eisenmänner planen neue Raubzüge",
      "Eine reiche Handelskarawane wird bald durch die Gegend kommen",
      "Ein Septon verkündet düstere Prophezeiungen",
      "In den Flusslanden wurden Leichen ohne Köpfe gefunden",
      "Ein Lord plant heimlich eine Rebellion",
      "Gold wurde in den nahen Bergen entdeckt",
      "Eine schöne Jungfer sucht einen Gemahl von Stand",
      "Piraten treiben ihr Unwesen an der Küste",
      "Eine geheimnisvolle Krankheit breitet sich aus",
      "Der König plant eine große Hochzeit oder ein Turnier",
      "Ein verschollener Erbe ist zurückgekehrt",
      "Wölfe haben das Vieh angegriffen - oder waren es Schattenwölfe?",
      "Ein alter Schatz soll in Ruinen verborgen sein",
      "Die Ernte war schlecht, Hunger droht im Winter",
      "Ein berühmter Ritter ist auf Wanderschaft",
      "Hexerei wird in einem nahen Dorf praktiziert",
      "Die Weißen Wanderer sind nur eine Legende - oder doch nicht?"
    ]
  },

  haus: {
    name: "Haus-Ereignisse",
    description: "Ereignisse die ein Adelshaus betreffen",
    entries: [
      "Ein Vasall rebelliert und verweigert den Lehnseid",
      "Ein Bote bringt schlechte Nachrichten vom König",
      "Ein wichtiger Verbündeter stirbt unerwartet",
      "Die Ernte auf den Ländereien ist außergewöhnlich gut",
      "Ein Erbe wird geboren",
      "Ein Familienmitglied erkrankt schwer",
      "Ein Nachbarhaus fordert alte Schulden ein",
      "Räuber plündern Dörfer auf eurem Land",
      "Ein talentierter Handwerker bietet seine Dienste an",
      "Die Minen bringen weniger Ertrag als erwartet",
      "Ein Skandal erschüttert das Ansehen des Hauses",
      "Ein alter Anspruch auf Land wird erhoben",
      "Die Burgmauern zeigen Risse und müssen repariert werden",
      "Ein wichtiger Handelsvertrag wird angeboten",
      "Söldner bieten ihre Dienste an - zu hohem Preis",
      "Ein Vasall bittet um militärische Unterstützung",
      "Ein junges Familienmitglied verschwindet spurlos",
      "Eine reiche Witwe sucht Schutz bei eurem Haus",
      "Der Maester des Hauses wird abberufen",
      "Ein Turnier soll auf der Burg ausgerichtet werden"
    ]
  }
};

/**
 * Würfelt ein zufälliges Ergebnis aus einer Rolltabelle
 * @param {string} tableKey - Schlüssel der Tabelle (intrigen, reise, geruechte, haus)
 * @returns {Object} - {entry: string, index: number, tableName: string}
 */
export function rollOnTable(tableKey) {
  const table = ROLLTABLES[tableKey];
  if (!table) {
    console.error(`Rolltabelle "${tableKey}" nicht gefunden`);
    return null;
  }

  const index = Math.floor(Math.random() * table.entries.length);
  return {
    entry: table.entries[index],
    index: index + 1,
    total: table.entries.length,
    tableName: table.name,
    description: table.description
  };
}

/**
 * Postet ein Rolltabellen-Ergebnis in den Chat
 * @param {string} tableKey - Schlüssel der Tabelle
 * @param {Actor} actor - Optional: Der Actor der würfelt
 */
export async function rollTableToChat(tableKey, actor = null) {
  const result = rollOnTable(tableKey);
  if (!result) return;

  const Roll = foundry.dice?.Roll || window.Roll;
  const roll = await new Roll(`1d${result.total}`).evaluate({ async: true });
  
  const content = `
    <div class="got-rolltable-result">
      <h3>${result.tableName}</h3>
      <p class="table-description"><em>${result.description}</em></p>
      <div class="roll-result">
        <strong>Ergebnis (${result.index}/${result.total}):</strong>
        <p>${result.entry}</p>
      </div>
    </div>
  `;

  ChatMessage.create({
    speaker: actor ? ChatMessage.getSpeaker({ actor }) : { alias: "Spielleiter" },
    content: content,
    roll: roll,
    type: CONST.CHAT_MESSAGE_TYPES.ROLL
  });
}

/**
 * Zeigt einen Dialog mit allen verfügbaren Rolltabellen
 */
export function showRolltableDialog() {
  const content = `
    <form>
      <div class="form-group">
        <label>Wähle eine Rolltabelle:</label>
        <select name="table" autofocus>
          <option value="intrigen">Intrigen-Ereignisse</option>
          <option value="reise">Reise-Komplikationen</option>
          <option value="geruechte">Gerüchte</option>
          <option value="haus">Haus-Ereignisse</option>
        </select>
      </div>
    </form>
  `;

  new Dialog({
    title: "Rolltabelle würfeln",
    content: content,
    buttons: {
      roll: {
        icon: '<i class="fas fa-dice"></i>',
        label: "Würfeln",
        callback: async (html) => {
          const tableKey = html.find('[name="table"]').val();
          await rollTableToChat(tableKey);
        }
      },
      cancel: {
        icon: '<i class="fas fa-times"></i>',
        label: "Abbrechen"
      }
    },
    default: "roll"
  }).render(true);
}
