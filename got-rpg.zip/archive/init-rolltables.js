// module/init-rolltables.js
// MAIN INIT für Rolltabellen-Feature
// ============================================
// FEATURE AKTIVIEREN/DEAKTIVIEREN:
// - Um zu aktivieren: Import in got-rpg.js einkommentieren
// - Um zu deaktivieren: Import in got-rpg.js auskommentieren
// ============================================

import { initializeRolltables, registerSceneControlsHook, setupMacros } from './logic/rolltables-init.js';

/**
 * Registriert alle Hooks für das Rolltabellen-System
 */
export function registerRolltableHooks() {
  
  // Registriere Scene Controls Hook SOFORT (nicht in ready)
  registerSceneControlsHook();
  
  // Initialisiere nach dem Ready
  Hooks.once('ready', () => {
    initializeRolltables();
  });

  // Optional: Erstelle Makros beim ersten Laden
  // Auskommentieren falls nicht gewünscht
  /*
  Hooks.once('ready', async () => {
    await setupMacros();
  });
  */
}
