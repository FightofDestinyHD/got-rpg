// module/logic/dice.js
// Würfel-Logik und Kampfsystem

import { MODULE_ID, SETTINGS, Logger } from './constants.js';

/**
 * Dice und Combat Helpers
 */
export class DiceHelpers {
  /**
   * Führt einen Angriffswurf durch
   * @param {Actor} actor - Der angreifende Actor
   * @param {Item} item - Die verwendete Waffe
   * @param {Object} options - Zusätzliche Optionen
   * @returns {Promise<Roll>}
   */
  static async rollAttack(actor, item, options = {}) {
    if (!actor || !item) {
      Logger.error("DiceHelpers.rollAttack: Actor oder Item fehlt");
      return null;
    }

    let formula = '1d6';
    
    // Prüfe ob Fernkampfbonus aktiv ist
    const fertigkeitsBonusAktiv = game.settings.get(MODULE_ID, SETTINGS.FERTIGKEITS_BONUS_AKTIV);
    if (fertigkeitsBonusAktiv) {
      const schuetze = Number(actor.system.fertigkeiten?.schuetze) || 0;
      const entfernungssinn = Number(actor.system.fertigkeiten?.entfernungssinn) || 0;
      const bonusActive = (schuetze >= 5) && (entfernungssinn >= 5);
      const isEquipped = !!item.system?.equipped;
      const isRanged = this.isRangedWeapon(item);
      
      if (bonusActive && isEquipped && isRanged) {
        formula = `${formula} + 1d6`;
      }
    }

    // Erstelle Roll mit foundry.dice.Roll (V13+ kompatibel)
    const RollClass = foundry.dice?.Roll || Roll;
    const roll = await (new RollClass(formula)).roll({ async: true });
    
    // Sende Nachricht
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: actor }),
      flavor: `Angriff (${item.name})${formula.includes('+') ? ' [+1W6 Bonus]' : ''}`
    });

    return roll;
  }

  /**
   * Führt einen Schadenswurf durch
   * @param {Actor} actor - Der angreifende Actor
   * @param {Item} item - Die verwendete Waffe
   * @returns {Promise<Roll>}
   */
  static async rollDamage(actor, item) {
    if (!actor || !item) {
      Logger.error("DiceHelpers.rollDamage: Actor oder Item fehlt");
      return null;
    }

    let formula = item.system?.schaden || '1d6';
    
    // Prüfe ob Fernkampfbonus aktiv ist
    const fertigkeitsBonusAktiv = game.settings.get(MODULE_ID, SETTINGS.FERTIGKEITS_BONUS_AKTIV);
    if (fertigkeitsBonusAktiv) {
      const schuetze = Number(actor.system.fertigkeiten?.schuetze) || 0;
      const entfernungssinn = Number(actor.system.fertigkeiten?.entfernungssinn) || 0;
      const bonusActive = (schuetze >= 5) && (entfernungssinn >= 5);
      const isEquipped = !!item.system?.equipped;
      const isRanged = this.isRangedWeapon(item);
      
      if (bonusActive && isEquipped && isRanged) {
        formula = formula ? `${formula} + 1d6` : '1d6';
      }
    }

    const RollClass = foundry.dice?.Roll || Roll;
    const roll = await (new RollClass(formula)).roll({ async: true });
    
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: actor }),
      flavor: `Schaden (${item.name})`
    });

    return roll;
  }

  /**
   * Prüft ob eine Waffe eine Fernkampfwaffe ist
   * @param {Item} item - Die zu prüfende Waffe
   * @returns {boolean}
   */
  static isRangedWeapon(item) {
    if (!item) return false;
    const name = item.name || '';
    const reichweite = item.system?.reichweite || '';
    return /bogen|armbrust/i.test(name) || /fernkampf/i.test(reichweite);
  }

  /**
   * Berechnet den Schadenbonus für eine Waffe
   * @param {Actor} actor - Der Actor
   * @param {Item} item - Die Waffe
   * @returns {string} - Die Schadensformel inkl. Boni
   */
  static calculateDamageFormula(actor, item) {
    if (!actor || !item) return '';
    
    let base = item.system?.schaden || '';
    
    const fertigkeitsBonusAktiv = game.settings.get(MODULE_ID, SETTINGS.FERTIGKEITS_BONUS_AKTIV);
    if (fertigkeitsBonusAktiv) {
      const schuetze = Number(actor.system.fertigkeiten?.schuetze) || 0;
      const entfernungssinn = Number(actor.system.fertigkeiten?.entfernungssinn) || 0;
      const bonusActive = (schuetze >= 5) && (entfernungssinn >= 5);
      const isEquipped = !!item.system?.equipped;
      const isRanged = this.isRangedWeapon(item);
      
      if (bonusActive && isEquipped && isRanged) {
        return base ? `${base} + 1W6` : '1W6';
      }
    }
    
    return base;
  }

  /**
   * Führt einen Attribut-Wurf durch
   * @param {Actor} actor - Der Actor
   * @param {string} attrName - Name des Attributs (geschick, staerke, etc.)
   * @param {number} modifier - Optionaler Modifikator (positiv = Bonus, negativ = Malus)
   * @param {Object} options - Zusätzliche Optionen { advantage, disadvantage }
   * @returns {Promise<Roll>}
   */
  static async rollAttribute(actor, attrName, modifier = 0, options = {}) {
    if (!actor || !attrName) {
      Logger.error("DiceHelpers.rollAttribute: Actor oder Attributname fehlt");
      return null;
    }

    const baseAttrValue = Number(actor.system.attribute?.[attrName]?.value) || 0;
    const attrValue = baseAttrValue + modifier;
    
    let formula = `1d20`;
    let advantageType = '';
    
    if (options.advantage && !options.disadvantage) {
      formula = `2d20kl`; // Keep lowest
      advantageType = ' [Vorteil]';
    } else if (options.disadvantage && !options.advantage) {
      formula = `2d20kh`; // Keep highest
      advantageType = ' [Nachteil]';
    }
    
    const RollClass = foundry.dice?.Roll || Roll;
    const roll = await (new RollClass(formula)).roll({ async: true });
    
    const success = roll.total <= attrValue;
    const attrLabel = attrName.charAt(0).toUpperCase() + attrName.slice(1);
    
    let flavorText = `${attrLabel}-Probe${advantageType} (Zielwert: ${baseAttrValue}`;
    if (modifier !== 0) {
      flavorText += ` ${modifier > 0 ? '+' : ''}${modifier} = ${attrValue}`;
    }
    flavorText += `) - ${success ? '✓ Erfolg' : '✗ Fehlschlag'}`;
    
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: actor }),
      flavor: flavorText
    });

    return roll;
  }

  /**
   * Führt einen Fertigkeits-Wurf durch
   * @param {Actor} actor - Der Actor
   * @param {string} skillName - Name der Fertigkeit
   * @param {number} modifier - Optionaler Modifikator (positiv = Bonus, negativ = Malus)
   * @param {Object} options - Zusätzliche Optionen { advantage, disadvantage }
   * @returns {Promise<Roll>}
   */
  static async rollSkill(actor, skillName, modifier = 0, options = {}) {
    if (!actor || !skillName) {
      Logger.error("DiceHelpers.rollSkill: Actor oder Fertigkeitname fehlt");
      return null;
    }

    const baseSkillValue = Number(actor.system.fertigkeiten?.[skillName]) || 0;
    const skillValue = baseSkillValue + modifier;
    
    let formula = `1d20`;
    let advantageType = '';
    
    if (options.advantage && !options.disadvantage) {
      formula = `2d20kl`; // Keep lowest (besser bei Probe <= Zielwert)
      advantageType = ' [Vorteil]';
    } else if (options.disadvantage && !options.advantage) {
      formula = `2d20kh`; // Keep highest (schlechter)
      advantageType = ' [Nachteil]';
    }
    
    const RollClass = foundry.dice?.Roll || Roll;
    const roll = await (new RollClass(formula)).roll({ async: true });
    
    const success = roll.total <= skillValue;
    
    let flavorText = `${skillName.charAt(0).toUpperCase() + skillName.slice(1)}-Probe${advantageType} (Zielwert: ${baseSkillValue}`;
    if (modifier !== 0) {
      flavorText += ` ${modifier > 0 ? '+' : ''}${modifier} = ${skillValue}`;
    }
    flavorText += `) - ${success ? '✓ Erfolg' : '✗ Fehlschlag'}`;
    
    roll.toMessage({
      speaker: ChatMessage.getSpeaker({ actor: actor }),
      flavor: flavorText
    });

    return roll;
  }

  /**
   * Zeigt erweiterten Roll-Dialog mit Vorteil/Nachteil-Optionen
   * @param {string} title - Titel des Dialogs
   * @param {Function} rollCallback - Callback-Funktion die mit (modifier, options) aufgerufen wird
   * @returns {Promise}
   */
  static async showAdvancedRollDialog(title, rollCallback) {
    return new Promise((resolve) => {
      new Dialog({
        title: title,
        content: `
          <form>
            <div class="form-group">
              <label>Modifikator:</label>
              <input type="number" name="modifier" value="0" autofocus />
            </div>
            <div class="form-group">
              <label>
                <input type="checkbox" name="advantage" /> Vorteil (2W20, niedrigster Wert)
              </label>
            </div>
            <div class="form-group">
              <label>
                <input type="checkbox" name="disadvantage" /> Nachteil (2W20, höchster Wert)
              </label>
            </div>
          </form>
        `,
        buttons: {
          roll: {
            icon: '<i class="fas fa-dice-d20"></i>',
            label: "Würfeln",
            callback: async (html) => {
              const modifier = parseInt(html.find('[name="modifier"]').val()) || 0;
              const advantage = html.find('[name="advantage"]').is(':checked');
              const disadvantage = html.find('[name="disadvantage"]').is(':checked');
              
              await rollCallback(modifier, { advantage, disadvantage });
              resolve(true);
            }
          },
          cancel: {
            icon: '<i class="fas fa-times"></i>',
            label: "Abbrechen",
            callback: () => resolve(false)
          }
        },
        default: 'roll'
      }).render(true);
    });
  }
}
