// module/logic/constants.js
// Zentrale Konstanten und Konfiguration

export const MODULE_ID = "got-rpg";

export const SETTINGS = {
  START_PUNKTE: "startPunkte",
  FERTIGKEITS_BONUS_AKTIV: "fertigkeitsBonusAktiv",
  WAFFEN_PACK_GEFUELLT: "waffenPackGefuellt",
  ARMOR_PACK_GEFUELLT: "armorPackGefuellt",
  FOOD_PACK_GEFUELLT: "foodPackGefuellt"
};

export const FIELD_PREFIXES = {
  ATTRIBUTE: "system.attribute.",
  FERTIGKEITEN: "system.fertigkeiten.",
  WAEHRUNG: "system.waehrung.",
  LEBENSPUNKTE: "system.lebenspunkte.",
  HAUS: "system.haus."
};

// Logging-Utilities mit konsistentem Präfix
const LOG_PREFIX = "GoT-RPG |";

export const Logger = {
  debug: (...args) => console.debug(LOG_PREFIX, ...args),
  info: (...args) => console.info(LOG_PREFIX, ...args),
  log: (...args) => console.log(LOG_PREFIX, ...args),
  warn: (...args) => console.warn(LOG_PREFIX, ...args),
  error: (...args) => console.error(LOG_PREFIX, ...args)
};
