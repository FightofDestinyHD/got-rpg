// module/logic/helpers.js
// Zentrale Helper-Funktionen für DOM-Manipulation und Datenextraktion

/**
 * Robuste DOM-Selektor Hilfsfunktionen
 * Verhindert stille Fehler bei Template-Änderungen
 */

export class DOMHelpers {
  /**
   * Liest einen Number-Wert aus einem Input-Feld
   * @param {jQuery} html - Das HTML-Element
   * @param {string} name - Der name-Attribut des Input-Feldes
   * @param {number} defaultValue - Standardwert wenn nicht gefunden/ungültig
   * @returns {number}
   */
  static getNumberField(html, name, defaultValue = 0) {
    try {
      const value = html.find(`input[name="${name}"]`).val();
      const num = Number(value);
      return isNaN(num) ? defaultValue : num;
    } catch (e) {
      console.warn(`DOM Helper: Feld "${name}" nicht gefunden oder ungültiger Wert. Verwende Default: ${defaultValue}`, e);
      return defaultValue;
    }
  }

  /**
   * Liest einen Text-Wert aus einem Input/Textarea-Feld
   * @param {jQuery} html - Das HTML-Element
   * @param {string} name - Der name-Attribut des Feldes
   * @param {string} defaultValue - Standardwert wenn nicht gefunden
   * @returns {string}
   */
  static getTextField(html, name, defaultValue = "") {
    try {
      const value = html.find(`input[name="${name}"], textarea[name="${name}"]`).val();
      return value !== undefined ? String(value) : defaultValue;
    } catch (e) {
      console.warn(`DOM Helper: Feld "${name}" nicht gefunden. Verwende Default: "${defaultValue}"`, e);
      return defaultValue;
    }
  }

  /**
   * Liest einen Checkbox-Wert
   * @param {jQuery} html - Das HTML-Element
   * @param {string} name - Der name-Attribut der Checkbox
   * @param {boolean} defaultValue - Standardwert wenn nicht gefunden
   * @returns {boolean}
   */
  static getCheckboxField(html, name, defaultValue = false) {
    try {
      const element = html.find(`input[name="${name}"][type="checkbox"]`);
      return element.length ? element.is(':checked') : defaultValue;
    } catch (e) {
      console.warn(`DOM Helper: Checkbox "${name}" nicht gefunden. Verwende Default: ${defaultValue}`, e);
      return defaultValue;
    }
  }

  /**
   * Liest einen Select-Wert
   * @param {jQuery} html - Das HTML-Element
   * @param {string} name - Der name-Attribut des Select-Feldes
   * @param {string} defaultValue - Standardwert wenn nicht gefunden
   * @returns {string}
   */
  static getSelectField(html, name, defaultValue = "") {
    try {
      const value = html.find(`select[name="${name}"]`).val();
      return value !== undefined ? String(value) : defaultValue;
    } catch (e) {
      console.warn(`DOM Helper: Select "${name}" nicht gefunden. Verwende Default: "${defaultValue}"`, e);
      return defaultValue;
    }
  }

  /**
   * Setzt einen Wert in ein Input-Feld
   * @param {jQuery} html - Das HTML-Element
   * @param {string} name - Der name-Attribut des Input-Feldes
   * @param {any} value - Der zu setzende Wert
   * @returns {boolean} - true wenn erfolgreich, false bei Fehler
   */
  static setFieldValue(html, name, value) {
    try {
      const element = html.find(`input[name="${name}"], textarea[name="${name}"], select[name="${name}"]`);
      if (element.length) {
        element.val(value);
        return true;
      }
      console.warn(`DOM Helper: Feld "${name}" nicht gefunden zum Setzen des Wertes.`);
      return false;
    } catch (e) {
      console.error(`DOM Helper: Fehler beim Setzen von "${name}":`, e);
      return false;
    }
  }

  /**
   * Prüft ob ein Feld existiert
   * @param {jQuery} html - Das HTML-Element
   * @param {string} name - Der name-Attribut des Feldes
   * @returns {boolean}
   */
  static fieldExists(html, name) {
    try {
      return html.find(`[name="${name}"]`).length > 0;
    } catch (e) {
      return false;
    }
  }
}

/**
 * Zentrale Konfiguration für Feld-Namen
 * Erleichtert Refactoring und Template-Änderungen
 */
export const FIELD_NAMES = {
  // Währung
  CURRENCY_KS: "system.waehrung.ks",
  CURRENCY_SH: "system.waehrung.sh",
  CURRENCY_GD: "system.waehrung.gd",
  
  // Lebenspunkte
  LP_CURRENT: "system.lebenspunkte.aktuell",
  LP_MAX: "system.lebenspunkte.max",
  
  // Punkte
  PUNKTE_TOTAL: "system.punkte.gesamt",
  PUNKTE_SPENT: "system.punkte.ausgegeben",
  
  // Details
  DETAILS_NAME: "name",
  DETAILS_IMG: "img",
  DETAILS_ALTER: "system.details.alter",
  DETAILS_GESCHLECHT: "system.details.geschlecht",
  DETAILS_KULTUR: "system.details.kultur",
  DETAILS_KONTINENT: "system.details.kontinent",
  DETAILS_ADELSSTAND: "system.details.adelsstand",
  DETAILS_GROESSE: "system.details.groesse",
  DETAILS_GEWICHT: "system.details.gewicht",
  
  // Attribute
  ATTR_STAERKE: "system.attribute.staerke",
  ATTR_GESCHICKLICHKEIT: "system.attribute.geschicklichkeit",
  ATTR_INTELLIGENZ: "system.attribute.intelligenz",
  ATTR_CHARISMA: "system.attribute.charisma",
  ATTR_ZAEHIGKEIT: "system.attribute.zaehigkeit",
  ATTR_WILLENSKRAFT: "system.attribute.willenskraft",
  
  // Haus
  HAUS_NAME: "system.haus.name",
  HAUS_WAPPEN: "system.haus.wappen",
  HAUS_MOTTO: "system.haus.motto",
  HAUS_EINFLUSS: "system.haus.einfluss",
  HAUS_REICHTUM: "system.haus.reichtum",
  HAUS_ANSEHEN: "system.haus.ansehen"
};

/**
 * Handlebars Helper Registrierung
 * Zentrale Stelle für alle Template-Helpers
 */
export function registerHandlebarsHelpers() {
  // Math Helpers
  Handlebars.registerHelper('multiply', function(a, b) {
    return (Number(a) || 0) * (Number(b) || 0);
  });

  Handlebars.registerHelper('divide', function(a, b) {
    const divisor = Number(b) || 1;
    return (Number(a) || 0) / divisor;
  });

  Handlebars.registerHelper('add', function(a, b) {
    return (Number(a) || 0) + (Number(b) || 0);
  });

  // Comparison Helpers
  Handlebars.registerHelper('eq', function(a, b) {
    return a === b;
  });

  Handlebars.registerHelper('gt', function(a, b) {
    return a > b;
  });

  Handlebars.registerHelper('lt', function(a, b) {
    return a < b;
  });

  Handlebars.registerHelper('gte', function(a, b) {
    return a >= b;
  });

  Handlebars.registerHelper('lte', function(a, b) {
    return a <= b;
  });

  // GoT-spezifische Helpers
  Handlebars.registerHelper('carryCapacity', function(staerke, zaehigkeit) {
    const s = Number(staerke) || 0;
    const z = Number(zaehigkeit) || 0;
    return ((s + z) / 2) * 20;
  });

  Handlebars.registerHelper('lpBarColor', function(current, max) {
    const c = Number(current) || 0;
    const m = Number(max) || 1;
    const pct = (c / m) * 100;
    if (pct > 75) return 'linear-gradient(to right, #2a5c2a, #4a8c4a)';
    if (pct > 50) return 'linear-gradient(to right, #6b6b2a, #9b9b4a)';
    if (pct > 25) return 'linear-gradient(to right, #8b5a2a, #bb7a3a)';
    return 'linear-gradient(to right, #7a1a1a, #aa2a2a)';
  });

  // Localization Helper
  Handlebars.registerHelper('localize', function(key) {
    if (typeof key !== 'string') return key;
    return game.i18n.localize(key);
  });
}
