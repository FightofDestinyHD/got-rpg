// module/logic/rolltables-init.js
// Initialisierung des Rolltabellen-Systems - Modular und entfernbar
// Um das Feature zu deaktivieren, einfach den Import in got-rpg.js entfernen

import { MACROS, createFoundryMacros } from './macros.js';
import { rollTableToChat, showRolltableDialog, ROLLTABLES } from './rolltables.js';

/**
 * Initialisiert das Rolltabellen-System
 * Wird beim Ready-Hook aufgerufen
 */
export function initializeRolltables() {
  console.log("GoT RPG | Rolltabellen-System wird geladen...");

  // Stelle Funktionen global zur Verfügung (für Makros)
  game.gotRpg = game.gotRpg || {};
  game.gotRpg.macros = MACROS;
  game.gotRpg.rolltables = {
    roll: rollTableToChat,
    showDialog: showRolltableDialog,
    tables: ROLLTABLES
  };

  console.log("GoT RPG | Rolltabellen-System geladen");
}

/**
 * Registriert den Hook für Scene Controls
 * Muss VOR ready aufgerufen werden
 */
export function registerSceneControlsHook() {
  Hooks.on('getSceneControlButtons', (controls) => {
    // Nur für GMs
    if (!game.user.isGM) return;
    
    // In V13 ist controls manchmal ein Objekt statt Array
    const controlsArray = Array.isArray(controls) ? controls : (controls?.controls || []);
    
    // Füge zu den Notes-Controls hinzu
    const notesControl = controlsArray.find(c => c.name === "notes");
    if (notesControl) {
      notesControl.tools.push({
        name: "got-rolltables",
        title: "GoT Rolltabellen",
        icon: "fas fa-scroll",
        button: true,
        onClick: () => showRolltableDialog()
      });

      notesControl.tools.push({
        name: "got-macros",
        title: "GoT SL-Makros",
        icon: "fas fa-dice",
        button: true,
        onClick: () => MACROS.showMacroDialog()
      });
    }
  });
}

/**
 * Optional: Erstellt Foundry-Makros beim ersten Laden
 * Kann auskommentiert werden, wenn nicht gewünscht
 */
export async function setupMacros() {
  if (game.user.isGM) {
    await createFoundryMacros();
  }
}
