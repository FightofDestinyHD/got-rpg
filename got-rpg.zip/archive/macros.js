// module/logic/macros.js
// SL-Makros für GoT RPG - Modular und entfernbar
// Kann jederzeit ohne Konflikte deaktiviert/entfernt werden

import { rollTableToChat, ROLLTABLES } from './rolltables.js';

/**
 * Makro-Funktionen die dem SL zur Verfügung stehen
 */
export const MACROS = {
  
  /**
   * Würfelt ein zufälliges Gerücht und postet es in den Chat
   */
  async rollRandomRumor() {
    await rollTableToChat('geruechte');
  },

  /**
   * Würfelt ein Haus-Ereignis
   */
  async rollHouseEvent() {
    await rollTableToChat('haus');
  },

  /**
   * Würfelt ein Intrigen-Ereignis
   */
  async rollIntrigue() {
    await rollTableToChat('intrigen');
  },

  /**
   * Würfelt eine Reise-Komplikation
   */
  async rollTravelComplication() {
    await rollTableToChat('reise');
  },

  /**
   * Wählt einen zufälligen Actor aus einer Gruppe/Ordner
   * @param {string} folderName - Optional: Name des Ordners
   */
  async pickRandomNPC(folderName = null) {
    let actors = [];
    
    if (folderName) {
      // Suche Ordner nach Namen
      const folder = game.folders.find(f => f.type === "Actor" && f.name === folderName);
      if (folder) {
        actors = folder.contents;
      } else {
        ui.notifications.warn(`Ordner "${folderName}" nicht gefunden`);
        return;
      }
    } else {
      // Alle NPCs (nicht vom Typ "character")
      actors = game.actors.filter(a => a.type !== "character");
    }

    if (actors.length === 0) {
      ui.notifications.warn("Keine NSCs gefunden");
      return;
    }

    const randomActor = actors[Math.floor(Math.random() * actors.length)];
    
    const content = `
      <div class="got-random-npc">
        <h3>Zufälliger NSC</h3>
        ${folderName ? `<p><em>aus Gruppe: ${folderName}</em></p>` : ''}
        <div class="npc-card">
          <img src="${randomActor.img}" alt="${randomActor.name}" style="width: 100px; height: 100px; object-fit: cover; border-radius: 4px;">
          <h4>${randomActor.name}</h4>
          <p><em>${randomActor.type}</em></p>
        </div>
      </div>
    `;

    ChatMessage.create({
      speaker: { alias: "Spielleiter" },
      content: content
    });
  },

  /**
   * Zeigt einen Dialog zum Auswählen eines Makros
   */
  async showMacroDialog() {
    const content = `
      <form>
        <div class="form-group">
          <label>Wähle ein Makro:</label>
          <select name="macro" autofocus>
            <option value="rumor">Zufälliges Gerücht</option>
            <option value="house">Haus-Ereignis</option>
            <option value="intrigue">Intrigen-Ereignis</option>
            <option value="travel">Reise-Komplikation</option>
            <option value="npc">Zufälliger NSC</option>
            <option value="npc-folder">Zufälliger NSC aus Ordner</option>
          </select>
        </div>
        <div class="form-group" id="folder-group" style="display: none;">
          <label>Ordnername (optional):</label>
          <input type="text" name="folder" placeholder="z.B. Stadtwache, Adlige" />
        </div>
      </form>
      <script>
        document.querySelector('[name="macro"]').addEventListener('change', (e) => {
          const folderGroup = document.getElementById('folder-group');
          folderGroup.style.display = e.target.value === 'npc-folder' ? 'block' : 'none';
        });
      </script>
    `;

    new Dialog({
      title: "SL-Makro ausführen",
      content: content,
      buttons: {
        execute: {
          icon: '<i class="fas fa-play"></i>',
          label: "Ausführen",
          callback: async (html) => {
            const macro = html.find('[name="macro"]').val();
            const folder = html.find('[name="folder"]').val();

            switch(macro) {
              case 'rumor':
                await MACROS.rollRandomRumor();
                break;
              case 'house':
                await MACROS.rollHouseEvent();
                break;
              case 'intrigue':
                await MACROS.rollIntrigue();
                break;
              case 'travel':
                await MACROS.rollTravelComplication();
                break;
              case 'npc':
                await MACROS.pickRandomNPC();
                break;
              case 'npc-folder':
                await MACROS.pickRandomNPC(folder || null);
                break;
            }
          }
        },
        cancel: {
          icon: '<i class="fas fa-times"></i>',
          label: "Abbrechen"
        }
      },
      default: "execute"
    }).render(true);
  }
};

/**
 * Erstellt Foundry-Makros für schnellen Zugriff
 */
export async function createFoundryMacros() {
  const macrosToCreate = [
    {
      name: "GoT: Zufälliges Gerücht",
      type: "script",
      command: "game.gotRpg.macros.rollRandomRumor();",
      img: "icons/sundries/scrolls/scroll-bound-brown-red.webp"
    },
    {
      name: "GoT: Haus-Ereignis",
      type: "script",
      command: "game.gotRpg.macros.rollHouseEvent();",
      img: "icons/environment/settlement/castle.webp"
    },
    {
      name: "GoT: Intrige",
      type: "script",
      command: "game.gotRpg.macros.rollIntrigue();",
      img: "icons/skills/social/theft-pickpocket-bribery-brown.webp"
    },
    {
      name: "GoT: Reise-Komplikation",
      type: "script",
      command: "game.gotRpg.macros.rollTravelComplication();",
      img: "icons/environment/wilderness/terrain-road-worn.webp"
    },
    {
      name: "GoT: Zufälliger NSC",
      type: "script",
      command: "game.gotRpg.macros.pickRandomNPC();",
      img: "icons/environment/people/commoner.webp"
    },
    {
      name: "GoT: SL-Makros",
      type: "script",
      command: "game.gotRpg.macros.showMacroDialog();",
      img: "icons/sundries/gaming/dice-runed-brown.webp"
    }
  ];

  let created = 0;
  for (const macroData of macrosToCreate) {
    const existing = game.macros.find(m => m.name === macroData.name);
    if (!existing) {
      await Macro.create(macroData);
      created++;
    }
  }

  if (created > 0) {
    ui.notifications.info(`${created} GoT-Makros wurden erstellt`);
  }
}
