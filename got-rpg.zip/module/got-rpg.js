// module/got-rpg.js
// GoT RPG System - Foundry VTT V13+ kompatibel

import { DOMHelpers, FIELD_NAMES, registerHandlebarsHelpers } from './logic/helpers.js';
import { DiceHelpers } from './logic/dice.js';
import { MODULE_ID, SETTINGS, FIELD_PREFIXES, Logger } from './logic/constants.js';

// ============================================
// OPTIONAL: Rolltabellen-System (DEAKTIVIERT - nutze native Foundry RollTables)
// ============================================
// Um das Feature zu aktivieren, folgende Zeile einkommentieren:
// import { registerRolltableHooks } from './init-rolltables.js';
// Um zu deaktivieren, einfach auskommentieren (// davor setzen)
// ============================================

// Einfacher Fallback für verschiedene Foundry-Versionen
export class GotCharacterSheet extends ActorSheet {
  static get defaultOptions() {
    return foundry.utils.mergeObject(super.defaultOptions, {
      classes: ["got-rpg", "sheet", "actor"],
      template: "systems/got-rpg/templates/actors/character-sheet.hbs",
      width: 850,
      height: 900,
      tabs: [{ navSelector: ".sheet-tabs", contentSelector: ".sheet-body", initial: "allgemein" }],
      submitOnChange: false,
      submitOnClose: false,
      closeOnSubmit: false,
      resizable: true
    });
  }

  async exportCharacter() {
    try {
      const data = {
        name: this.actor.name,
        img: this.actor.img,
        type: this.actor.type,
        system: foundry.utils.duplicate(this.actor.system),
        items: this.actor.items.map(it => ({
          name: it.name,
          type: it.type,
          img: it.img,
          system: foundry.utils.duplicate(it.system)
        })),
        flags: foundry.utils.duplicate(this.actor.flags),
        exportedAt: new Date().toISOString(),
        version: game.system.version
      };
      const json = JSON.stringify(data, null, 2);
      const blob = new Blob([json], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${this.actor.name.replace(/[^a-z0-9]/gi, '_')}_character.json`;
      a.click();
      URL.revokeObjectURL(url);
      ui.notifications?.info(`Charakter ${this.actor.name} exportiert.`);
    } catch (e) {
      console.error('Export fehlgeschlagen:', e);
      ui.notifications?.error('Export fehlgeschlagen.');
    }
  }

  async importCharacter(jsonData) {
    try {
      const data = JSON.parse(jsonData);
      const updates = {
        name: data.name,
        img: data.img,
        system: data.system
      };
      await this.actor.update(updates);
      // Items löschen und neu anlegen
      const existingIds = this.actor.items.map(it => it.id);
      if (existingIds.length) await this.actor.deleteEmbeddedDocuments('Item', existingIds);
      if (data.items?.length) await this.actor.createEmbeddedDocuments('Item', data.items);
      // Flags wiederherstellen
      if (data.flags) {
        for (const [scope, scopeData] of Object.entries(data.flags)) {
          for (const [key, val] of Object.entries(scopeData || {})) {
            await this.actor.setFlag(scope, key, val);
          }
        }
      }
      ui.notifications?.info('Charakter importiert.');
      this.render(false);
    } catch (e) {
      console.error('Import fehlgeschlagen:', e);
      ui.notifications?.error('Import fehlgeschlagen - ungültige Datei?');
    }
  }

  async getData(options) {
    const context = await super.getData(options);
    // Add GM status to context for template
    context.isGM = game.user.isGM;
    
    // Add settings to context
    context.settings = {
      fertigkeitsBonusAktiv: game.settings.get(MODULE_ID, SETTINGS.FERTIGKEITS_BONUS_AKTIV),
      traglastRegel: game.settings.get(MODULE_ID, "traglastRegel"),
      ruestungVerteidigungRegel: game.settings.get(MODULE_ID, "ruestungVerteidigungRegel"),
      maxAttributWert: game.settings.get(MODULE_ID, "maxAttributWert"),
      maxFertigkeitWert: game.settings.get(MODULE_ID, "maxFertigkeitWert")
    };
    
    // Berechne LP-Prozentsatz und Punkte-Status für UI-Warnungen
    const lpCurrent = Number(this.actor.system.lebenspunkte?.aktuell) || 0;
    const lpMax = Number(this.actor.system.lebenspunkte?.maximum) || 1;
    context.lpPercent = (lpCurrent / lpMax) * 100;
    context.punkteVerfuegbar = Number(this.actor.system.punkte?.verfuegbar) || 0;
    
    try {
      // Sortierte Items: Ausgerüstet zuerst, dann Name
      const itemsArr = this.actor.items.contents.slice();
      itemsArr.sort((a,b) => {
        const ae = !!a.system?.equipped;
        const be = !!b.system?.equipped;
        if (ae !== be) return be - ae; // true zuerst
        return (a.name||'').localeCompare(b.name||'');
      });
      context.sortedItems = itemsArr;
      // Bonus-Zusammenfassung aller ausgerüsteten Items
      const attrSum = {}; const skillSum = {};
      for (const it of itemsArr) {
        if (!it.system?.equipped) continue;
        const boni = it.system?.boni || {};
        const aB = boni.attribute || {}; const sB = boni.fertigkeiten || {};
        for (const [k,v] of Object.entries(aB)) { const num = Number(v)||0; if (!num) continue; attrSum[k] = (attrSum[k]||0)+num; }
        for (const [k,v] of Object.entries(sB)) { const num = Number(v)||0; if (!num) continue; skillSum[k] = (skillSum[k]||0)+num; }
      }
      context.equippedBonusSummary = { attribute: attrSum, fertigkeiten: skillSum };
      // Kampflog laden
      context.combatLog = this.actor.getFlag('got-rpg', 'combatLog') || [];
      // Erfahrungslog laden
      context.experienceLog = this.actor.getFlag('got-rpg', 'experienceLog') || [];
    } catch (e) {
      console.warn('Bonus-Zusammenfassung fehlgeschlagen:', e);
      context.sortedItems = context.actor.items;
      context.equippedBonusSummary = { attribute:{}, fertigkeiten:{} };
      context.combatLog = [];
      context.experienceLog = [];
    }
    return context;
  }

  // Kampflog-Methoden
  async addCombatLogEntry(entry) {
    const log = this.actor.getFlag('got-rpg', 'combatLog') || [];
    const newEntry = {
      id: foundry.utils.randomID(),
      timestamp: new Date().toLocaleString('de-DE'),
      ...entry
    };
    log.unshift(newEntry); // Neueste zuerst
    if (log.length > 100) log.length = 100; // Limit auf 100 Einträge
    await this.actor.setFlag('got-rpg', 'combatLog', log);
    this.render(false);
  }

  async clearCombatLog() {
    await this.actor.setFlag('got-rpg', 'combatLog', []);
    this.render(false);
  }

  // Erfahrungslog-Methoden
  async addExperienceLogEntry(entry) {
    const log = this.actor.getFlag('got-rpg', 'experienceLog') || [];
    const newEntry = {
      id: foundry.utils.randomID(),
      timestamp: new Date().toLocaleString('de-DE'),
      ...entry
    };
    log.unshift(newEntry); // Neueste zuerst
    if (log.length > 100) log.length = 100; // Limit auf 100 Einträge
    await this.actor.setFlag('got-rpg', 'experienceLog', log);
    
    // Punkte hinzufügen
    const points = Number(entry.points) || 0;
    const verfuegbar = Number(this.actor.system.punkte?.verfuegbar) || 0;
    const erhalten = Number(this.actor.system.punkte?.erhalten) || 0;
    await this.actor.update({
      'system.punkte.verfuegbar': verfuegbar + points,
      'system.punkte.erhalten': erhalten + points
    });
    
    this.render(false);
    ui.notifications?.info(`${points > 0 ? '+' : ''}${points} Punkte ${points > 0 ? 'erhalten' : 'abgezogen'}`);
  }

  async clearExperienceLog() {
    await this.actor.setFlag('got-rpg', 'experienceLog', []);
    this.render(false);
  }

  // Eigene, robuste Speicherlogik: expandObject anwenden, Rechte prüfen, direkt this.actor.update
  async _updateObject(event, formData) {
    const raw = foundry.utils.duplicate(formData);

    // expandierte Struktur, damit z.B. 'system.details.alter' korrekt in { system: { details: { alter: ... }}}
    const payload = foundry.utils.expandObject(raw);

    // Punkte-Persistenz: Verfügbar nicht zurücksetzen, sondern Ausgegeben verrechnen
    try {
      const punkte = payload?.system?.punkte ?? {};
      const verf = Number(punkte.verfuegbar ?? raw["system.punkte.verfuegbar"]) || 0;
      const ausg = Number(punkte.ausgegeben ?? raw["system.punkte.ausgegeben"]) || 0;
      if (ausg > 0) {
        const newVerf = Math.max(0, verf - ausg);
        payload.system = payload.system || {};
        payload.system.punkte = payload.system.punkte || {};
        payload.system.punkte.verfuegbar = newVerf;
        payload.system.punkte.ausgegeben = 0; // nach Verrechnung zurücksetzen
      }
    } catch (e) {
      console.warn("Punkte-Verrechnung beim Speichern fehlgeschlagen", e);
    }

    // Prüfen ob der aktuelle Benutzer Schreibrechte hat
    // permission-check: UI-Warnung wird gezeigt, keine Debug-Logs
    if (!this.actor?.isOwner) {
      ui.notifications?.warn("Du kannst diesen Charakter nicht speichern: keine Schreibrechte.");
      return;
    }

    // Versuche das Update direkt auf dem Actor (bessere Kontrolle über Fehler)
    try {
      // Basiswerte aus SessionAllocations rekonstruieren (Attribute & Fertigkeiten ohne Ausrüstungsboni)
      if (!payload.system) payload.system = {};
      const baseAttrContainer = payload.system.attribute = payload.system.attribute || {};
      const baseSkillContainer = payload.system.fertigkeiten = payload.system.fertigkeiten || {};
      const allocOrig = this._originalValues || {};
      const allocSess = this._sessionAllocations || {};
      // Mapping für Cap-Prüfung (Skill -> Attribut)
      const skillAttrMapPersist = {
        ueberreden: 'charisma',
        luegen: 'charisma',
        einschuechtern: 'charisma',
        etikette: 'charisma',
        nahkampf: 'staerke',
        zaehigkeit: 'staerke',
        geschwindigkeit: 'staerke',
        schuetze: 'staerke',
        fingerfertigkeit: 'geschick',
        faehrtenlesen: 'geschick',
        schleichen: 'geschick',
        vorahnung: 'intuition',
        beurteilung: 'intuition',
        entfernungssinn: 'intuition',
        komplexerVerstand: 'wissen',
        magie: 'wissen'
      };
      // Attribute: Schlüssel endet auf .value
      for (const [fullName, origVal] of Object.entries(allocOrig)) {
        if (!fullName.startsWith('system.attribute.')) continue;
        const attrName = fullName.split('.')[2];
        const sessionAdded = Number(allocSess[fullName] || 0);
        const newBase = Number(origVal) + sessionAdded; // Max 20 Clamp
        baseAttrContainer[attrName] = baseAttrContainer[attrName] || {};
        baseAttrContainer[attrName].value = Math.min(20, newBase);
      }
      // Skills
      for (const [fullName, origVal] of Object.entries(allocOrig)) {
        if (!fullName.startsWith('system.fertigkeiten.')) continue;
        const skillName = fullName.split('.').pop();
        const sessionAdded = Number(allocSess[fullName] || 0);
        let newBase = Number(origVal) + sessionAdded;
        // Cap durch zugehöriges Attribut (bereits evtl. aktualisiert oben)
        const attrKey = skillAttrMapPersist[skillName];
        if (attrKey) {
          const attrCap = Number(baseAttrContainer[attrKey]?.value ?? this.actor._source?.system?.attribute?.[attrKey]?.value ?? 0);
          if (newBase > attrCap) newBase = attrCap; // nicht über Basis-Attribut hinaus
        }
        baseSkillContainer[skillName] = Math.min(20, newBase);
      }
      // Entferne ausgegeben (wird neu berechnet) falls vorhanden im Payload bereits Überschreibungen durch Formwerte
      // (die sichtbaren Werte mit Boni dürfen nicht direkt gespeichert werden)
      await this.actor.update(payload);
      // Render die Sheet-UI neu damit die Änderungen sofort sichtbar sind
      try {
        this.render(false);
      } catch (renderErr) {
        console.warn("Fehler beim Neurendern des Sheets nach Update:", renderErr);
      }
      // Falls Foundry an dieser Stelle die lokale Actor-Instanz nicht aktualisiert,
      // versuchen wir, die Actor-Instanz erneut aus dem Actor-Katalog zu laden.
      // Nach erfolgreichem Update rendere das Sheet neu (keine Debug-Logs)
    } catch (err) {
      console.error("Fehler beim Actor.update:", err);
      ui.notifications?.error("Speichern fehlgeschlagen: siehe Konsole für Details.");
      throw err;
    }
  }

  activateListeners(html) {
    super.activateListeners(html);
    if (!this.isEditable) return;

    // ========================================================================
    // HELPER FUNCTIONS - Must be declared before use
    // ========================================================================

    // Gestaffelte Kosten: <8 => 1, 8–13 => 2, ab 14 => 4 pro Schritt
    function costForStep(targetValue) {
      if (targetValue >= 14) return 4;
      if (targetValue >= 8) return 2;
      return 1;
    }

    function computeSpentPoints($root) {
      let total = 0;
      // attributes: input names like system.attribute.<name>.value
      $root.find('input[name^="system.attribute."]').each((i, el) => {
        const name = $(el).attr('name');
        const valRaw = Number($(el).val()) || 0;
        // baseline (saved) value, if available, is not counted towards pool spending
        const base = (originalValues[name] !== undefined) ? (Number(originalValues[name]) || 0) : 0;
        const cappedVal = Math.min(valRaw, 20);
        const cappedBase = Math.min(base, 20);
        if (cappedVal > cappedBase) {
          for (let v = cappedBase + 1; v <= cappedVal; v++) {
            total += costForStep(v);
          }
        }
      });
      // skills: input names like system.fertigkeiten.<name>
      $root.find('input[name^="system.fertigkeiten."]').each((i, el) => {
        const name = $(el).attr('name');
        const valRaw = Number($(el).val()) || 0;
        const base = (originalValues[name] !== undefined) ? (Number(originalValues[name]) || 0) : 0;
        const cappedVal = Math.min(valRaw, 20);
        const cappedBase = Math.min(base, 20);
        if (cappedVal > cappedBase) {
          for (let v = cappedBase + 1; v <= cappedVal; v++) {
            total += costForStep(v);
          }
        }
      });
      return total;
    }

    function setDecState($ctrl, name) {
      const disabled = !(sessionAllocations[name] && sessionAllocations[name] > 0);
      $ctrl.prop('disabled', disabled);
    }

    function updatePunkteUI($root) {
      const $verfInput = $root.find('input[name="system.punkte.verfuegbar"]');
      const $ausgInput = $root.find('input[name="system.punkte.ausgegeben"]');
      const verf = Number($verfInput.val()) || 0;
      const spent = computeSpentPoints($root);
      // Update display spans
      $root.find('.punkte-verfuegbar').text(verf);
      $root.find('.punkte-ausgegeben').text(spent);
      const remaining = verf - spent;
      $root.find('.punkte-verbleibend').text(remaining);
      // update hidden field so saving persists the spent value
      $ausgInput.val(spent);
      // Hinweis: Speichern erfolgt nur beim Submit via _updateObject
    }

    // Refresh baseline values for a given set of input names (or all inputs if omitted)
    const refreshBaselinesForNames = (names) => {
      // names: array of input name strings like 'system.attribute.charisma.value'
      // WICHTIG: Immer aus _source holen, nicht aus angezeigten Werten!
      if (!names) {
        // refresh all - use _source
        html.find('input[name^="system.attribute."]').each((i, el) => {
          const name = $(el).attr('name');
          const attrName = name.split('.')[2];
          originalValues[name] = Number(this.actor._source?.system?.attribute?.[attrName]?.value) || 0;
          sessionAllocations[name] = 0;
        });
        html.find('input[name^="system.fertigkeiten."]').each((i, el) => {
          const name = $(el).attr('name');
          const skillName = name.split('.').pop();
          originalValues[name] = Number(this.actor._source?.system?.fertigkeiten?.[skillName]) || 0;
          sessionAllocations[name] = 0;
        });
      } else {
        for (const n of names) {
          const $inp = html.find(`input[name="${n}"]`);
          if ($inp.length) {
            // Use _source instead of displayed value
            if (n.startsWith('system.attribute.')) {
              const attrName = n.split('.')[2];
              originalValues[n] = Number(this.actor._source?.system?.attribute?.[attrName]?.value) || 0;
            } else if (n.startsWith('system.fertigkeiten.')) {
              const skillName = n.split('.').pop();
              originalValues[n] = Number(this.actor._source?.system?.fertigkeiten?.[skillName]) || 0;
            } else {
              originalValues[n] = Number($inp.val()) || 0;
            }
            sessionAllocations[n] = 0;
            // update dec-button state if control exists
            const $dec = $inp.closest('.alloc-control').find('.dec-alloc');
            setDecState($dec, n);
          }
        }
      }
      // Instanz-Referenzen aktualisieren
      this._originalValues = originalValues;
      this._sessionAllocations = sessionAllocations;
    };

    // ========================================================================
    // INITIALIZE SESSION ALLOCATION TRACKING
    // ========================================================================

    // Track the original (saved) values per-field and any session-only additions.
    // This baseline prevents base values, equipment bonuses or spell effects
    // that already exist on the actor from being counted against the allocation pool.
    const originalValues = {};
    const sessionAllocations = {};

    // initialize maps for attributes + skills found in the sheet
    // WICHTIG: originalValues aus _source holen (ohne Equipment-Boni)
    html.find('input[name^="system.attribute."]').each((i, el) => {
      const name = $(el).attr('name');
      const attrName = name.split('.')[2];
      const v = Number(this.actor._source?.system?.attribute?.[attrName]?.value) || 0;
      originalValues[name] = v;
      sessionAllocations[name] = 0;
    });
    html.find('input[name^="system.fertigkeiten."]').each((i, el) => {
      const name = $(el).attr('name');
      const skillName = name.split('.').pop();
      const v = Number(this.actor._source?.system?.fertigkeiten?.[skillName]) || 0;
      originalValues[name] = v;
      sessionAllocations[name] = 0;
    });
    // Referenzen auf Instanz legen, damit _updateObject sie nutzen kann
    this._originalValues = originalValues;
    this._sessionAllocations = sessionAllocations;

    // ========================================================================
    // ADELSSTAND CHARISMA RULE
    // ========================================================================

    // Adelsstand → Charisma-Regel: bestimmte Adelsstände erhalten 0 Grundcharisma
    const zeroCharismaStatuses = new Set([
      'Buergerlicher', 'Leibeigener', 'SoeldnerOhneStatus', 'Nachtwache', 'Verstossener',
      'Schnee', 'Sand', 'Stein', 'Fluss', 'Huegel', 'Blume', 'Sturm', 'Wasser'
    ]);

    // Statuses which should get a base Charisma of 2
    const twoCharismaStatuses = new Set([
      'GelehrterMaester', 'WohlhabenderHaendler', 'AnerkannterKapitaen', 'GesalbterRitter'
    ]);

    // Statuses which should get a base Charisma of 1
    const oneCharismaStatuses = new Set([
      'VerarmterRitter'
    ]);

    // Statuses which should get a base Charisma of 3
    const threeCharismaStatuses = new Set([
      'HoherOffizier', 'EinflussreicherGeistlicher'
    ]);

    // Statuses which should get a base Charisma of 4
    const fourCharismaStatuses = new Set([
      'LordKleinesTerritorium', 'MitgliedVasallenhaus'
    ]);

    function applyAdelsstandCharismaRule($html) {
      const current = $html.find('select[name="system.details.adelsstand"]').val();
      const $charisma = $html.find('input[name="system.attribute.charisma.value"]');
      if (!current) return;
      if (zeroCharismaStatuses.has(current)) {
        // set to 0 (highest priority)
        $charisma.val(0);
        // treat this as a baseline change (not a pool allocation)
        refreshBaselinesForNames(['system.attribute.charisma.value']);
        updatePunkteUI($html);
      } else if (fourCharismaStatuses.has(current)) {
        // set to 4
        $charisma.val(4);
        refreshBaselinesForNames(['system.attribute.charisma.value']);
        updatePunkteUI($html);
      } else if (threeCharismaStatuses.has(current)) {
        // set to 3
        $charisma.val(3);
        refreshBaselinesForNames(['system.attribute.charisma.value']);
        updatePunkteUI($html);
      } else if (twoCharismaStatuses.has(current)) {
        // set to 2
        $charisma.val(2);
        refreshBaselinesForNames(['system.attribute.charisma.value']);
        updatePunkteUI($html);
      } else if (oneCharismaStatuses.has(current)) {
        // set to 1
        $charisma.val(1);
        refreshBaselinesForNames(['system.attribute.charisma.value']);
        updatePunkteUI($html);
      }
    }

    // ========================================================================
    // INITIALIZATION & EFFECTS SYNC
    // ========================================================================

    // Synchronize item effects on open: ensure equipped items have effects
    // DEAKTIVIERT: Hook-Kaskaden führen zu Endlos-Schleifen bei fingerfertigkeit
    // Effekte werden nur noch bei Equip/Unequip über .item-equip handler gesetzt
    /*
    const _effectSyncPromise = (async () => {
      try {
        let anyUpdated = false;
        for (const item of this.actor.items) {
          if (item.system?.equipped) {
            const existing = this._findItemEffect(item);
            if (!existing) {
              await this._upsertItemEffect(item);
              anyUpdated = true;
            }
          }
        }
        if (anyUpdated) {
          // Force actor to re-apply effects
          await this.actor.prepareData();
        }
      } catch (e) {
        console.warn('Fehler beim Synchronisieren von Item-Effekten:', e);
      }
    })();
    // After effects are synced, refresh baselines so equipment bonuses are not counted as spent points
    _effectSyncPromise.finally(async () => {
      try {
        refreshBaselinesForNames();
        updatePunkteUI(html);
      } catch (e) {
        console.warn('Post-Sync Refresh fehlgeschlagen:', e);
      }
    });
    */
   
    // Baselines setzen beim Sheet-Öffnen
    setTimeout(() => {
      refreshBaselinesForNames();
      updatePunkteUI(html);
    }, 100);

    // Auto-Sync: Erzeuge fehlende Effekte für bereits ausgerüstete Items (generische Boni)
    setTimeout(() => {
      try {
        for (const item of this.actor.items) {
          if (!item.system?.equipped) continue;
          const existing = this._findItemEffect(item);
            if (!existing) {
              this._upsertItemEffect(item);
            }
        }
      } catch (e) {
        console.warn('Auto-Sync Item-Effekte fehlgeschlagen:', e);
      }
    }, 150);

    // Currency auto-convert: 56 KS = 1 SH, 210 SH = 1 GD
    const autoConvertCurrency = async () => {
      // Read current input values
      let ks = Number(html.find('input[name="system.waehrung.ks"]').val()) || 0;
      let sh = Number(html.find('input[name="system.waehrung.sh"]').val()) || 0;
      let gd = Number(html.find('input[name="system.waehrung.gd"]').val()) || 0;

      // KS -> SH
      if (ks >= 56) {
        const toSH = Math.floor(ks / 56);
        sh += toSH;
        ks = ks % 56; // Rest bleibt in KS
      }
      // SH -> GD
      if (sh >= 210) {
        const toGD = Math.floor(sh / 210);
        gd += toGD;
        sh = sh % 210; // Rest bleibt in SH
      }

      // Update actor
      await this.actor.update({ 'system.waehrung': { ks, sh, gd } });
      // Update input fields
      html.find('input[name="system.waehrung.ks"]').val(ks);
      html.find('input[name="system.waehrung.sh"]').val(sh);
      html.find('input[name="system.waehrung.gd"]').val(gd);
    };

    html.find('input[name="system.waehrung.ks"], input[name="system.waehrung.sh"], input[name="system.waehrung.gd"]').on('change', async ev => {
      await autoConvertCurrency();
    });

    // INVENTAR: add/edit/delete/equip
    html.find('.add-item').on('click', async ev => {
      ev.preventDefault();
      const type = ev.currentTarget.dataset.type;
      if (!type) return;
      await this.actor.createEmbeddedDocuments('Item', [{ name: `Neues ${type}`, type }]);
      this.render(false);
    });

    // Toggle Inventar-Ansicht (Detail/Kompakt)
    html.find('.toggle-inventory-view').on('click', ev => {
      const $btn = $(ev.currentTarget);
      const $table = html.find('.inventory-table');
      const isCompact = $table.hasClass('compact');
      if (isCompact) {
        $table.removeClass('compact');
        $btn.removeClass('active').attr('title', 'Ansicht wechseln');
      } else {
        $table.addClass('compact');
        $btn.addClass('active').attr('title', 'Detail-Ansicht');
      }
    });

    // Export Charakter
    html.find('.export-character').on('click', ev => {
      ev.preventDefault();
      this.exportCharacter();
    });

    // Import Charakter
    html.find('.import-character').on('click', ev => {
      ev.preventDefault();
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = '.json';
      input.onchange = async (e) => {
        const file = e.target.files[0];
        if (!file) return;
        const reader = new FileReader();
        reader.onload = async (ev) => {
          await this.importCharacter(ev.target.result);
        };
        reader.readAsText(file);
      };
      input.click();
    });

    // Bulk Equip/Unequip
    html.find('.bulk-equip-all').on('click', async ev => {
      ev.preventDefault();
      const updates = [];
      for (const it of this.actor.items) {
        if (!it.system?.equipped) updates.push({ _id: it.id, 'system.equipped': true });
      }
      if (updates.length) {
        await this.actor.updateEmbeddedDocuments('Item', updates);
        ui.notifications?.info(`${updates.length} Items ausgerüstet.`);
        this.render(false);
      }
    });

    html.find('.bulk-unequip-all').on('click', async ev => {
      ev.preventDefault();
      const updates = [];
      for (const it of this.actor.items) {
        if (it.system?.equipped) updates.push({ _id: it.id, 'system.equipped': false });
      }
      if (updates.length) {
        await this.actor.updateEmbeddedDocuments('Item', updates);
        ui.notifications?.info(`${updates.length} Items abgelegt.`);
        this.render(false);
      }
    });

    html.find('.bulk-delete-unequipped').on('click', async ev => {
      ev.preventDefault();
      const toDelete = this.actor.items.filter(it => !it.system?.equipped).map(it => it.id);
      if (!toDelete.length) return ui.notifications?.warn('Keine nicht-ausgerüsteten Items.');
      const confirm = await Dialog.confirm({
        title: 'Bulk Löschen',
        content: `<p>Wirklich ${toDelete.length} nicht-ausgerüstete Items löschen?</p>`,
        yes: () => true,
        no: () => false
      });
      if (confirm) {
        await this.actor.deleteEmbeddedDocuments('Item', toDelete);
        ui.notifications?.info(`${toDelete.length} Items gelöscht.`);
        this.render(false);
      }
    });

    // Favoriten Toggle
    html.find('.toggle-favorite').on('click', async ev => {
      ev.preventDefault();
      const id = ev.currentTarget.dataset.itemId;
      const item = this.actor.items.get(id);
      if (!item) return;
      const isFav = item.getFlag('got-rpg', 'favorite') || false;
      await item.setFlag('got-rpg', 'favorite', !isFav);
      this.render(false);
    });

    // Kampflog Eintrag hinzufügen
    html.find('.add-combat-log').on('click', async ev => {
      ev.preventDefault();
      const content = await new Promise(resolve => {
        new Dialog({
          title: 'Kampflog Eintrag',
          content: `<div><label>Aktion:</label><input type="text" id="log-action" style="width:100%;"/></div><div style="margin-top:0.5rem;"><label>Ergebnis:</label><textarea id="log-result" style="width:100%;height:60px;"></textarea></div>`,
          buttons: {
            ok: { label: 'Hinzufügen', callback: (html) => resolve({ action: html.find('#log-action').val(), result: html.find('#log-result').val() }) },
            cancel: { label: 'Abbrechen', callback: () => resolve(null) }
          },
          default: 'ok'
        }).render(true);
      });
      if (content) {
        await this.addCombatLogEntry(content);
      }
    });

    // Kampflog leeren
    html.find('.clear-combat-log').on('click', async ev => {
      ev.preventDefault();
      if (!game.user.isGM) return ui.notifications?.warn('Nur der GM kann das Kampflog löschen.');
      const confirm = await Dialog.confirm({
        title: 'Kampflog löschen',
        content: '<p>Wirklich gesamtes Kampflog löschen?</p>',
        yes: () => true,
        no: () => false
      });
      if (confirm) await this.clearCombatLog();
    });

    // Kampflog Eintrag löschen
    html.find('.delete-log-entry').on('click', async ev => {
      ev.preventDefault();
      if (!game.user.isGM) return ui.notifications?.warn('Nur der GM kann Kampflog-Einträge löschen.');
      const entryId = ev.currentTarget.dataset.entryId;
      const log = this.actor.getFlag('got-rpg', 'combatLog') || [];
      const filtered = log.filter(e => e.id !== entryId);
      await this.actor.setFlag('got-rpg', 'combatLog', filtered);
      this.render(false);
    });

    // Kampflog Notizen bearbeiten (Spieler)
    html.find('.edit-log-notes').on('click', async ev => {
      ev.preventDefault();
      const entryId = ev.currentTarget.dataset.entryId;
      const log = this.actor.getFlag('got-rpg', 'combatLog') || [];
      const entry = log.find(e => e.id === entryId);
      if (!entry) return;
      
      const newNotes = await new Promise(resolve => {
        new Dialog({
          title: 'Notizen bearbeiten',
          content: `<div style="margin-bottom:0.5rem;"><strong>Eintrag:</strong> ${entry.action}</div><div><label>Notizen:</label><textarea id="log-notes" style="width:100%;height:100px;">${entry.notes || ''}</textarea></div>`,
          buttons: {
            save: { 
              label: 'Speichern', 
              callback: (html) => resolve(html.find('#log-notes').val()) 
            },
            delete: {
              label: 'Notizen löschen',
              callback: () => resolve('')
            },
            cancel: { 
              label: 'Abbrechen', 
              callback: () => resolve(null) 
            }
          },
          default: 'save'
        }).render(true);
      });
      
      if (newNotes !== null) {
        entry.notes = newNotes;
        await this.actor.setFlag('got-rpg', 'combatLog', log);
        this.render(false);
      }
    });

    // Erfahrungslog: Neue Session hinzufügen
    html.find('.add-experience-log').on('click', async ev => {
      ev.preventDefault();
      const content = await new Promise(resolve => {
        new Dialog({
          title: 'Neue Session / Erfahrung',
          content: `
            <div style="margin-bottom:0.75rem;">
              <label>Session-Name (optional):</label>
              <input type="text" id="session-name" placeholder="z.B. Session 5, Kapitel 3..." style="width:100%;"/>
            </div>
            <div style="margin-bottom:0.75rem;">
              <label>Punkte:</label>
              <input type="number" id="exp-points" value="5" style="width:100%;"/>
            </div>
            <div>
              <label>Begründung:</label>
              <textarea id="exp-reason" placeholder="Was ist passiert? Warum wurden Punkte vergeben?" style="width:100%;height:80px;"></textarea>
            </div>
          `,
          buttons: {
            ok: { 
              label: 'Hinzufügen', 
              callback: (html) => resolve({ 
                sessionName: html.find('#session-name').val(), 
                points: Number(html.find('#exp-points').val()) || 0,
                reason: html.find('#exp-reason').val() 
              }) 
            },
            cancel: { label: 'Abbrechen', callback: () => resolve(null) }
          },
          default: 'ok'
        }).render(true);
      });
      if (content) {
        await this.addExperienceLogEntry(content);
      }
    });

    // Erfahrungslog leeren
    html.find('.clear-experience-log').on('click', async ev => {
      ev.preventDefault();
      if (!game.user.isGM) return ui.notifications?.warn('Nur der GM kann das Erfahrungslog löschen.');
      const confirm = await Dialog.confirm({
        title: 'Erfahrungslog löschen',
        content: '<p>Wirklich gesamtes Erfahrungslog löschen?</p>',
        yes: () => true,
        no: () => false
      });
      if (confirm) await this.clearExperienceLog();
    });

    // Erfahrungslog Eintrag löschen
    html.find('.delete-exp-entry').on('click', async ev => {
      ev.preventDefault();
      if (!game.user.isGM) return ui.notifications?.warn('Nur der GM kann Erfahrungseinträge löschen.');
      const entryId = ev.currentTarget.dataset.entryId;
      const log = this.actor.getFlag('got-rpg', 'experienceLog') || [];
      const entry = log.find(e => e.id === entryId);
      if (!entry) return;
      
      // Punkte zurückziehen
      const verfuegbar = Number(this.actor.system.punkte?.verfuegbar) || 0;
      const erhalten = Number(this.actor.system.punkte?.erhalten) || 0;
      await this.actor.update({
        'system.punkte.verfuegbar': verfuegbar - entry.points,
        'system.punkte.erhalten': erhalten - entry.points
      });
      
      const filtered = log.filter(e => e.id !== entryId);
      await this.actor.setFlag('got-rpg', 'experienceLog', filtered);
      this.render(false);
    });

    // Erfahrungslog Eintrag bearbeiten
    html.find('.edit-exp-entry').on('click', async ev => {
      ev.preventDefault();
      const entryId = ev.currentTarget.dataset.entryId;
      const log = this.actor.getFlag('got-rpg', 'experienceLog') || [];
      const entry = log.find(e => e.id === entryId);
      if (!entry) return;
      
      const updated = await new Promise(resolve => {
        new Dialog({
          title: 'Eintrag bearbeiten',
          content: `
            <div style="margin-bottom:0.75rem;">
              <label>Session-Name:</label>
              <input type="text" id="session-name" value="${entry.sessionName || ''}" style="width:100%;"/>
            </div>
            <div style="margin-bottom:0.75rem;">
              <label>Punkte:</label>
              <input type="number" id="exp-points" value="${entry.points}" style="width:100%;"/>
            </div>
            <div>
              <label>Begründung:</label>
              <textarea id="exp-reason" style="width:100%;height:80px;">${entry.reason || ''}</textarea>
            </div>
          `,
          buttons: {
            save: { 
              label: 'Speichern', 
              callback: (html) => resolve({
                sessionName: html.find('#session-name').val(),
                points: Number(html.find('#exp-points').val()) || 0,
                reason: html.find('#exp-reason').val()
              })
            },
            cancel: { label: 'Abbrechen', callback: () => resolve(null) }
          },
          default: 'save'
        }).render(true);
      });
      
      if (updated) {
        const oldPoints = entry.points;
        const newPoints = updated.points;
        const pointsDiff = newPoints - oldPoints;
        
        // Punkte anpassen
        if (pointsDiff !== 0) {
          const verfuegbar = Number(this.actor.system.punkte?.verfuegbar) || 0;
          const erhalten = Number(this.actor.system.punkte?.erhalten) || 0;
          await this.actor.update({
            'system.punkte.verfuegbar': verfuegbar + pointsDiff,
            'system.punkte.erhalten': erhalten + pointsDiff
          });
        }
        
        entry.sessionName = updated.sessionName;
        entry.points = updated.points;
        entry.reason = updated.reason;
        await this.actor.setFlag('got-rpg', 'experienceLog', log);
        this.render(false);
      }
    });

    // edit button removed per user request

    // Clickable attribute rolls
    html.find('.rollable-attr').on('click', async ev => {
      ev.preventDefault();
      const attr = ev.currentTarget.dataset.attribute;
      if (!attr) return;
      
      const attrLabel = attr.charAt(0).toUpperCase() + attr.slice(1);
      await DiceHelpers.showAdvancedRollDialog(
        `${attrLabel}-Wurf`,
        async (modifier, options) => {
          await DiceHelpers.rollAttribute(this.actor, attr, modifier, options);
        }
      );
    });

    // Clickable skill rolls
    html.find('.rollable-skill').on('click', async ev => {
      ev.preventDefault();
      const skill = ev.currentTarget.dataset.skill;
      if (!skill) return;
      
      const skillLabel = skill.charAt(0).toUpperCase() + skill.slice(1);
      await DiceHelpers.showAdvancedRollDialog(
        `${skillLabel}-Wurf`,
        async (modifier, options) => {
          await DiceHelpers.rollSkill(this.actor, skill, modifier, options);
        }
      );
    });

    html.find('.item-delete').on('click', async ev => {
      ev.preventDefault();
      const id = ev.currentTarget.dataset.itemId;
      await this.actor.deleteEmbeddedDocuments('Item', [id]);
      this.render(false);
    });

    html.find('.item-equip').on('click', async ev => {
      ev.preventDefault();
      const id = ev.currentTarget.dataset.itemId;
      const item = this.actor.items.get(id);
      if (!item) return;
      const equipped = !!item.system?.equipped;
      await item.update({ system: { equipped: !equipped } });
      // Effect management happens in updateItem hook - don't duplicate here
      this.render(false);
    });

    // Dynamische Anzeige: Waffenschaden mit Talentbonus (+1W6 bei Schütze>=5 UND Entfernungssinn>=5 für ausgerüstete Bögen/Armbrüste)
    const updateDamageDisplay = () => {
      const items = this.actor.items;
      for (const it of items) {
        if (it.type !== 'weapon') continue;
        const $cell = html.find(`.weapon-dmg[data-item-id="${it.id}"]`);
        if (!$cell.length) continue;
        
        // Verwende DiceHelpers für konsistente Berechnung
        const displayFormula = DiceHelpers.calculateDamageFormula(this.actor, it);
        $cell.text(displayFormula || '-');
      }
    };

    // Initial aufrufen
    updateDamageDisplay();

    // Neu berechnen bei Equip/Unequip
    html.find('.item-equip').on('click', () => setTimeout(updateDamageDisplay, 50));

    // Neu berechnen bei Änderung der relevanten Fertigkeiten
    html.find('input[name="system.fertigkeiten.schuetze"], input[name="system.fertigkeiten.entfernungssinn"]').on('change', () => updateDamageDisplay());

    // Roll: Angriff (W6, ggf. +1W6 bei Bogen/Armbrust wenn beide Skills >=5)
    html.find('.item-roll-attack').on('click', async ev => {
      ev.preventDefault();
      const id = ev.currentTarget.dataset.itemId;
      const item = this.actor.items.get(id);
      if (!item) return;
      
      // Verwende DiceHelpers für konsistente Würfellogik
      await DiceHelpers.rollAttack(this.actor, item);
    });

    // Hinweis: Verteidigungswurf-Button entfernt; Verteidigung kann später über andere Mechanik erfolgen.

    // Speichern-Button
    html.find(".save-actor").on("click", ev => {
      ev.preventDefault();
      this.submit(); // ruft _updateObject -> super._updateObject
    });

    // Portrait-Upload: öffnet Foundry FilePicker und schreibt den Pfad in input[name=img]
    html.find('.upload-portrait').on('click', ev => {
      ev.preventDefault();
      const fp = new FilePicker({
        type: "image",
        callback: path => {
          // Set the hidden input and update preview
          html.find('input[name="img"]').val(path);
          html.find('.portrait-preview').attr('src', path);
        }
      });
      fp.browse();
    });

    // Entfernen-Button: leere das Bildfeld und stelle die Standardvorschau wieder her
    html.find('.remove-portrait').on('click', ev => {
      ev.preventDefault();
      const defaultImg = "icons/svg/mystery-man.svg";
      html.find('input[name="img"]').val("");
      html.find('.portrait-preview').attr('src', defaultImg);
    });

    // Kultur / Kontinent: kontrollierte Auswahl mit Beschreibungen
    const RACES = {
      Westeros: [
        // A. Alte Ethnien
        { id: 'ErsteMenschen', label: 'Erste Menschen', desc: 'Das älteste bekannte menschliche Volk in Westeros.' },
        { id: 'Andalen', label: 'Andalen', desc: 'Spätere Eroberer; brachten den Glauben an die Sieben.' },
        { id: 'Rhoynar', label: 'Rhoynar', desc: 'Ursprünglich ein Volk aus Essos; heute kulturell weitgehend Teil der Dornischen.' },

        // B. Regionale Kulturen
        { id: 'Nordmaenner', label: 'Nordmänner', desc: 'Regionale Kultur des Nordens.' },
        { id: 'Flusslaender', label: 'Flussländer', desc: 'Regionale Kulturen entlang der Flüsse (z. B. das Riverlands).' },
        { id: 'Vale', label: 'Männer des Grünen Tals (Vale)', desc: 'Regionale Kultur des Vale, die Männer des Grünen Tals.' },
        { id: 'Westlaender', label: 'Westländer', desc: 'Regionale Kultur der Westlande.' },
        { id: 'Kronlaender', label: 'Kronländer', desc: 'Regionale Kultur der Kronländer.' },
        { id: 'Reachmen', label: 'Reachmen (Grünland / Das Reach)', desc: 'Kultur des grünen, fruchtbaren Reach.' },
        { id: 'Sturmlaender', label: 'Sturmländer', desc: 'Regionale Kultur der Sturmlande.' },
        { id: 'Dornische', label: 'Dornische', desc: 'Vermischte Abstammung aus Andalen, Ersten Menschen und Rhoynar; eigenständige Kultur in Dorne.' },

        // C. Eigenständige Völker
        { id: 'Eisenmaenner', label: 'Eisenmänner (Ironborn)', desc: 'Kriegerisches Seefahrervolk der Eiseninseln.' },
        { id: 'FreiesVolk', label: 'Freies Volk / Wildlinge', desc: 'Unabhängige Menschen nördlich der Mauer.' },
        { id: 'Thenns', label: 'Thenns', desc: 'Eigene Kultur nördlich der Mauer (Thenns).'},
        // Valyrer bleiben als mögliche Kultur in Westeros (z. B. Targaryen)
        { id: 'Valyrer', label: 'Valyrer (Targaryen & Co.)', desc: 'Altes Drachenreitervolk, blasse Haut, silberne Haare.' }
      ],
      Essos: [
        // A. Freie Städte
        { id: 'Bravosi', label: 'Bravosi', desc: 'Gemischte Bevölkerung; Stadtstaat mit starkem Handel und abtrünnigen Sklaven-Erfahrungen.' },
        { id: 'Pentoshi', label: 'Pentoshi', desc: 'Reiche Handelsstadt, Pentos ist bekannt für seinen Handel und seine Patrizier.' },
        { id: 'Tyroshi', label: 'Tyroshi', desc: 'Küstenstadt mit eigenem kulturellem Stil und starken maritimen Traditionen.' },
        { id: 'Myrische', label: 'Myrische', desc: 'Handelsstadt Myr; bekannt für Stoffe, Handwerk und Handel.' },
        { id: 'Lyseni', label: 'Lyseni', desc: 'Stadt mit berühmter Aristokratie und Luxusgütern.' },
        { id: 'Norvosi', label: 'Norvosi', desc: 'Stadtstaat mit alter Tradition und kultureller Vermischung.' },
        { id: 'Lorathi', label: 'Lorathi', desc: 'Lorath liegt auf vielen Inseln; eine See- und Handelskultur.' },
        { id: 'Qohori', label: 'Qohori', desc: 'Qohor ist berühmt für seine Schmiede und kriegerischen Traditionen.' },
        { id: 'Volanten', label: 'Volanten', desc: 'Eines der ältesten Stadtreiche, reich an Tradition und Handel.' },

        // B. Nomadenvölker
        { id: 'Dothraki', label: 'Dothraki', desc: 'Nomadisches Reitervolk der Grasebenen.' },
        { id: 'JogosNhai', label: 'Jogos Nhai', desc: 'Vielgestaltige Nomadenstämme aus den östlichen Steppen (bekannt aus Büchern).' },
        { id: 'Lhazareen', label: 'Lhazareen', desc: 'Bodenständiges, „Lämmervolk“ nahe den Dothraki; traditionell sesshafter.' },

        // C. Slaver’s Bay / Alte Ghiscari
        { id: 'Meereen', label: 'Meereen / Meereener', desc: 'Teil der alten Ghiscari-Kultur – ehemals Sklavenhalterreiche.' },
        { id: 'Yunkai', label: 'Yunkai\'i', desc: 'Teil der alten Ghiscari-Kultur – die „Gelben“ (Yunkai’i).' },
        { id: 'Astapor', label: 'Astapor / Astapori', desc: 'Teil der alten Ghiscari-Kultur; berühmt für Sklavenmärkte (Unsullied).' },

        // D. Insel- & Küstenvölker
        { id: 'Ibbenesen', label: 'Ibbenesen', desc: 'Zottelige Seefahrer von der Insel Ibben.' },
        { id: 'Naathi', label: 'Naathi', desc: 'Friedliches, gewaltabweisendes Volk (z. B. Missandei).' },

        // E. Ferner Osten
        { id: 'YiTi', label: 'Yi-Ti', desc: 'Großes Kaiserreich im fernen Osten mit vielfältigen ethnischen Gruppen.' },
        { id: 'Asshai', label: 'Asshai\'i', desc: 'Mystische, dunkle Hafenstadt Asshai – geheimnisvoll und gemischt kulturell.' },

        // Valyrer können auch in Essos leben
        { id: 'Valyrer', label: 'Valyrer (Targaryen & Co.)', desc: 'Altes Drachenreitervolk, blasse Haut, silberne Haare.' }
      ]
    };

    function populateKulturSelect($html, continent, selected) {
      const $select = $html.find('select.kultur-select');
      $select.empty();
      if (!continent || !RACES[continent]) {
        $select.append('<option value="">(Zuerst Kontinent wählen)</option>');
        $html.find('.kultur-beschreibung').text('');
        $select.prop('disabled', true);
        return;
      }
      $select.prop('disabled', false);
      $select.append('<option value="">(Bitte wählen)</option>');
      for (const r of RACES[continent]) {
        const opt = $('<option>').attr('value', r.id).text(r.label);
        if (selected && selected === r.id) opt.attr('selected', 'selected');
        $select.append(opt);
      }
      // set initial description
      const cur = selected || $select.val();
      updateDescription($html, continent, cur);
    }

    function updateDescription($html, continent, kultur) {
      const $descr = $html.find('.kultur-beschreibung');
      if (!continent || !kultur) { $descr.text(''); return; }
      if (!kultur) { $descr.text(''); return; }
      const list = RACES[continent] || [];
      const found = list.find(it => it.id === kultur);
      $descr.text(found ? found.desc : '');
    }

    // initial populate on open
    const initialContinent = html.find('select[name="system.details.kontinent"]').val();
    // try new kultur field first, then fall back to legacy rasse
    const initialKultur = html.find('select[name="system.details.kultur"]').val() || this.actor?.system?.details?.kultur || this.actor?.system?.details?.rasse || '';
    populateKulturSelect(html, initialContinent, initialKultur);

    // handlers
    html.find('select[name="system.details.kontinent"]').on('change', ev => {
      const cont = ev.currentTarget.value;
      // clear previous kultur/rasse value to avoid mismatch when switching continents
      html.find('select[name="system.details.kultur"]').val('');
      populateKulturSelect(html, cont, null);
    });

    html.find('select[name="system.details.kultur"]').on('change', ev => {
      const r = ev.currentTarget.value;
      const cont = html.find('select[name="system.details.kontinent"]').val();
      updateDescription(html, cont, r);
    });

    // initial apply on open
    applyAdelsstandCharismaRule(html);

    // apply when adelsstand changes
    html.find('select[name="system.details.adelsstand"]').on('change', ev => {
      applyAdelsstandCharismaRule(html);
    });

    // ---- Session allocation bookkeeping (already initialized above) ----------------------------------

    // initial update
    updatePunkteUI(html);

    // Ensure dec-alloc buttons start disabled (no session-added points yet)
    html.find('.dec-alloc').each((i, btn) => {
      const $btn = $(btn);
      const $input = $btn.siblings('input');
      const name = $input.attr('name');
      setDecState($btn, name);
    });

    // Add handlers for the new allocation controls
    // Map Skills -> Main Attribute
    const skillAttrMap = {
      ueberreden: 'charisma',
      luegen: 'charisma',
      einschuechtern: 'charisma',
      etikette: 'charisma',
      nahkampf: 'staerke',
      zaehigkeit: 'staerke',
      geschwindigkeit: 'staerke',
      schuetze: 'staerke',
      fingerfertigkeit: 'geschick',
      faehrtenlesen: 'geschick',
      schleichen: 'geschick',
      vorahnung: 'intuition',
      beurteilung: 'intuition',
      entfernungssinn: 'intuition',
      komplexerVerstand: 'wissen',
      magie: 'wissen'
    };

    function getAttrLimitForSkill(skillName) {
      const attr = skillAttrMap[skillName];
      if (!attr) return 20;
      // Prefer current UI input value if present, fallback to actor data
      const $attrInput = html.find(`input[name="system.attribute.${attr}.value"]`);
      if ($attrInput.length) return Number($attrInput.val()) || 0;
      return Number(this.actor?.system?.attribute?.[attr]?.value) || 0;
    }

    html.find('.inc-alloc').on('click', ev => {
      ev.preventDefault();
      // Decide which input we're operating on
      const $btn = $(ev.currentTarget);
      const $input = $btn.siblings('input');
      const name = $input.attr('name');
      const isSkill = name.startsWith('system.fertigkeiten.');
      const skillName = isSkill ? name.split('.').pop() : null;

      const verf = Number(html.find('input[name="system.punkte.verfuegbar"]').val()) || 0;
      const spent = computeSpentPoints(html);
      const remaining = verf - spent;
      if (remaining <= 0) return ui.notifications?.warn('Keine Punkte verfügbar.');

      const cur = Number($input.val()) || 0;
      
      // Für Skills: Hole den REINEN Basiswert aus actor._source (ohne Effekte)
      let base;
      if (isSkill) {
        base = Number(this.actor._source?.system?.fertigkeiten?.[skillName]) || 0;
      } else if (name.startsWith('system.attribute.')) {
        const attrName = name.split('.')[2];
        base = Number(this.actor._source?.system?.attribute?.[attrName]?.value) || 0;
      } else {
        base = (originalValues[name] !== undefined) ? (Number(originalValues[name]) || 0) : 0;
      }
      
      // Berücksichtige bereits geplante Session-Erhöhungen
      const alreadyAdded = Number(sessionAllocations[name] || 0);
      const nextBase = base + alreadyAdded + 1;
      
      if (isSkill) {
        const cap = getAttrLimitForSkill.call(this, skillName);
        
        // Prüfe ob der neue Basiswert das Cap überschreitet
        if (nextBase > cap) {
          return ui.notifications?.warn('Fertigkeitswert darf den Hauptattributswert nicht überschreiten.');
        }
      }
      
      // Maximalwert-Prüfung für den Basiswert
      if (nextBase > 20) {
        return ui.notifications?.warn('Maximalwert 20 erreicht.');
      }
      
      // Kosten basieren auf dem neuen Basiswert
      const stepCost = costForStep(nextBase);
      if (stepCost > remaining) {
        return ui.notifications?.warn(`Nicht genug Punkte für diese Erhöhung (Kosten: ${stepCost}).`);
      }
      
      // Neuer angezeigter Wert (Basis + aktuelle Boni (cur - (base+alreadyAdded)))
      const effectiveBaseSoFar = base + alreadyAdded;
      const bonus = cur - effectiveBaseSoFar; // aktueller Anzeige-Bonus
      const nextVal = nextBase + bonus;
      
      $input.val(nextVal);

      // count as session allocation
      sessionAllocations[name] = (sessionAllocations[name] || 0) + 1;
      this._sessionAllocations = sessionAllocations;

      // enable dec button, recompute UI
      setDecState($btn.siblings('.dec-alloc'), name);
      updatePunkteUI(html);
    });

    html.find('.dec-alloc').on('click', ev => {
      ev.preventDefault();
      const $btn = $(ev.currentTarget);
      const $input = $btn.siblings('input');
      const name = $input.attr('name');

      if (!(sessionAllocations[name] && sessionAllocations[name] > 0)) {
        return ui.notifications?.warn('Nur Punkte können entfernt werden, die in dieser Sitzung hinzugefügt wurden.');
      }

      const cur = Number($input.val()) || 0;
      const newVal = Math.max(0, cur - 1);
      $input.val(newVal);
      sessionAllocations[name] = Math.max(0, (sessionAllocations[name] || 0) - 1);
      this._sessionAllocations = sessionAllocations;

      setDecState($btn, name);
      updatePunkteUI(html);
    });

    // Register hooks to refresh baselines when the actor or embedded data changes
    this._onActorUpdate = (updatedActor, diff, options, userId) => {
      if (!this.actor) return;
      if (updatedActor?.id === this.actor.id) {
        // Resync baselines to avoid counting equipment/spell changes as spent
        refreshBaselinesForNames();
        updatePunkteUI(html);
      }
    };
    Hooks.on('updateActor', this._onActorUpdate);

    // item / active effect updates on this actor (equipment/zauber) should also refresh baseline
    // Guard gegen mehrfache Hook-Registrierung
    if (this._onItemUpdate) {
      Hooks.off('updateItem', this._onItemUpdate);
    }
    
    this._onItemUpdate = async (item, diff, options, userId) => {
      if (!this.actor) return;
      if (item?.parent?.id === this.actor.id) {
        // Prüfe ob 'equipped' sich geändert hat
        if (!diff?.system?.hasOwnProperty('equipped')) return;
        
        // Aktualisiere/entferne Effekte abhängig vom Equip-Status
        try {
          const isEquipped = !!item.system?.equipped;
          if (isEquipped) {
            await this._upsertItemEffect(item);
          } else {
            await this._removeItemEffect(item);
          }
        } catch (e) {
          console.warn('Fehler beim Aktualisieren von Item-Effekten:', e);
        }
        refreshBaselinesForNames();
        updatePunkteUI(html);
      }
    };
    Hooks.on('updateItem', this._onItemUpdate);

    this._onActiveEffectChange = (effect, diff, options, userId) => {
      if (!this.actor) return;
      if (effect?.parent?.id === this.actor.id) {
        // Clamp any skills and attributes to max 20 to avoid runaway stacking
        try {
          const clampUpdates = {};
          ['attribute','fertigkeiten'].forEach(section => {
            const src = foundry.utils.getProperty(this.actor.system, section) || {};
            for (const [key, val] of Object.entries(src)) {
              const path = section === 'attribute' ? `system.attribute.${key}.value` : `system.fertigkeiten.${key}`;
              const num = Number(section === 'attribute' ? (val?.value) : val) || 0;
              if (num > 20) {
                clampUpdates[path] = 20;
              }
            }
          });
          if (Object.keys(clampUpdates).length) {
            this.actor.update(clampUpdates);
          }
        } catch (e) {
          console.warn('Clamping nach Effektänderung fehlgeschlagen:', e);
        }
        refreshBaselinesForNames();
        updatePunkteUI(html);
      }
    };
    Hooks.on('updateActiveEffect', this._onActiveEffectChange);

    // Keep manual edits predictable: typed changes are treated as session allocations
    html.find('input[name^="system.attribute."]').on('change', ev => {
      const $input = $(ev.currentTarget);
      const name = $input.attr('name');
      let newVal = Number($input.val()) || 0;
      const saved = originalValues[name] || 0;
      if (newVal > 20) {
        newVal = 20;
        $input.val(20);
        ui.notifications?.warn('Maximalwert 20 erreicht.');
      }
      // If user tries to lower below the saved (base) value, prevent it
      if (newVal < saved) {
        ui.notifications?.warn('Nicht möglich: Werte unter dem gespeicherten Basiswert sind nicht entfernbar.');
        $input.val(saved);
        sessionAllocations[name] = 0;
      } else {
        const verf = Number(html.find('input[name="system.punkte.verfuegbar"]').val()) || 0;
        const totalSpent = computeSpentPoints(html);
        let costThis = 0;
        if (newVal > saved) {
          for (let v = saved + 1; v <= newVal; v++) costThis += costForStep(v);
        }
        const spentOthers = totalSpent - costThis;
        let remaining = verf - spentOthers;
        if (newVal > saved && costThis > remaining) {
          let allowed = saved;
          let rem = remaining;
          for (let v = saved + 1; v <= newVal; v++) {
            const c = costForStep(v);
            if (c <= rem) { rem -= c; allowed = v; } else break;
          }
          $input.val(allowed);
          sessionAllocations[name] = allowed - saved;
          ui.notifications?.warn(`Nicht genug Punkte: Wert auf ${allowed} begrenzt.`);
        } else {
          sessionAllocations[name] = newVal - saved;
        }
      }
      // update dec-button state
      const $dec = $input.closest('.alloc-control').find('.dec-alloc');
      setDecState($dec, name);
      updatePunkteUI(html);
      this._sessionAllocations = sessionAllocations;
    });

    html.find('input[name^="system.fertigkeiten."]').on('change', ev => {
      const $input = $(ev.currentTarget);
      const name = $input.attr('name');
      let newVal = Number($input.val()) || 0;
      const skillName = name.split('.').pop();
      
      // Hole echten Basiswert aus _source (ohne Equipment-Boni)
      const baseValue = Number(this.actor._source?.system?.fertigkeiten?.[skillName]) || 0;
      const currentDisplayed = Number(this.actor.system?.fertigkeiten?.[skillName]) || 0;
      const bonus = currentDisplayed - baseValue;
      
      // Cap-Prüfung: nur Basiswert darf Attribut-Cap nicht überschreiten
      const cap = getAttrLimitForSkill.call(this, skillName);
      const intendedBase = newVal - bonus; // Was der Nutzer als Basis setzen will
      
      if (intendedBase > cap) {
        // Setze auf Cap + Bonus
        newVal = cap + bonus;
        $input.val(newVal);
        ui.notifications?.warn(`Fertigkeits-Basiswert darf ${cap} (Attributsgrenze) nicht überschreiten.`);
      }
      const saved = originalValues[name] || 0;
      if (newVal > 20) {
        newVal = 20;
        $input.val(20);
        ui.notifications?.warn('Maximalwert 20 erreicht.');
      }
      if (newVal < saved) {
        ui.notifications?.warn('Nicht möglich: Werte unter dem gespeicherten Basiswert sind nicht entfernbar.');
        $input.val(saved);
        sessionAllocations[name] = 0;
      } else {
        const verf = Number(html.find('input[name="system.punkte.verfuegbar"]').val()) || 0;
        const totalSpent = computeSpentPoints(html);
        let costThis = 0;
        if (newVal > saved) {
          for (let v = saved + 1; v <= newVal; v++) costThis += costForStep(v);
        }
        const spentOthers = totalSpent - costThis;
        let remaining = verf - spentOthers;
        if (newVal > saved && costThis > remaining) {
          let allowed = saved;
          let rem = remaining;
          for (let v = saved + 1; v <= newVal; v++) {
            const c = costForStep(v);
            if (c <= rem) { rem -= c; allowed = v; } else break;
          }
          $input.val(allowed);
          sessionAllocations[name] = allowed - saved;
          ui.notifications?.warn(`Nicht genug Punkte: Wert auf ${allowed} begrenzt.`);
        } else {
          sessionAllocations[name] = newVal - saved;
        }
      }
      const $dec = $input.closest('.alloc-control').find('.dec-alloc');
      setDecState($dec, name);
      updatePunkteUI(html);
      this._sessionAllocations = sessionAllocations;
    });

    // Recompute when attributes or skills change
    html.find('input[name^="system.attribute."]').on('input change', ev => {
      updatePunkteUI(html);
    });
    html.find('input[name^="system.fertigkeiten."]').on('input change', ev => {
      updatePunkteUI(html);
    });

    // Keep any 'erhalten' inputs in the sheet synced (we render the input in two tabs)
    html.find('input[name="system.punkte.erhalten"]').on('input change', ev => {
      const val = ev.currentTarget.value;
      html.find('input[name="system.punkte.erhalten"]').val(val);
    });

    // Add 'erhaltene' points into verfuegbar and reset erhalten to 0
    html.find('.add-erhalten').on('click', async ev => {
      ev.preventDefault();
      if (!this.actor?.isOwner) return ui.notifications?.warn('Du hast keine Berechtigung, diesen Actor zu ändern.');
      const $erhaltenInput = html.find('input[name="system.punkte.erhalten"]');
      let toAdd = Number($erhaltenInput.val()) || 0;
      if (toAdd <= 0) return ui.notifications?.warn('Bitte eine positive Zahl zum Hinzufügen eingeben.');
      // compute new verfuegbar based on current stored value
      const currentVerf = Number(html.find('input[name="system.punkte.verfuegbar"]').val()) || 0;
      const newVerf = currentVerf + toAdd;
      try {
        await this.actor.update({ system: { punkte: { verfuegbar: newVerf, erhalten: 0 } } });
        // update the hidden input (form) and UI (keep both erhalten inputs in sync)
        html.find('input[name="system.punkte.verfuegbar"]').val(newVerf);
        html.find('input[name="system.punkte.erhalten"]').val(0);
        updatePunkteUI(html);
        ui.notifications?.info(`Erhaltene Punkte (+${toAdd}) hinzugefügt.`);
      } catch (err) {
        console.error('Fehler beim Hinzufügen erhaltene Punkte', err);
        ui.notifications?.error('Fehler beim Hinzufügen der Punkte.');
      }
    });

    // LP Modify Buttons (GM only)
    html.find('.lp-modify-btn').on('click', async ev => {
      ev.preventDefault();
      if (!game.user.isGM) return ui.notifications?.warn('Nur der GM kann LP ändern.');
      if (!this.actor?.isOwner) return ui.notifications?.warn('Du hast keine Berechtigung, diesen Actor zu ändern.');
      
      const action = ev.currentTarget.dataset.action; // 'add' or 'subtract'
      const $valueInput = html.find('.lp-modify-value');
      const value = Number($valueInput.val()) || 0;
      
      if (value <= 0) return ui.notifications?.warn('Bitte einen positiven Wert eingeben.');
      
      const currentLP = Number(this.actor.system.lebenspunkte.aktuell) || 0;
      const maxLP = Number(this.actor.system.lebenspunkte.maximum) || 100;
      
      let newLP = currentLP;
      if (action === 'add') {
        newLP = Math.min(maxLP, currentLP + value);
      } else if (action === 'subtract') {
        newLP = Math.max(0, currentLP - value);
      }
      
      try {
        await this.actor.update({ 'system.lebenspunkte.aktuell': newLP });
        $valueInput.val('');
        
        // Kampflog-Eintrag hinzufügen
        if (action === 'subtract' && value > 0) {
          await this.addCombatLogEntry({
            action: `${value} Schaden erhalten`,
            result: ``
          });
        } else if (action === 'add' && value > 0) {
          await this.addCombatLogEntry({
            action: `${value} LP geheilt`,
            result: ``
          });
        }
        
        ui.notifications?.info(`LP ${action === 'add' ? 'hinzugefügt' : 'abgezogen'}: ${value} (neu: ${newLP}/${maxLP})`);
      } catch (err) {
        console.error('Fehler beim Ändern von LP', err);
        ui.notifications?.error('Fehler beim Ändern der LP.');
      }
    });

    // --- Gewicht / Traglast Anzeige ---
    const updateWeightDisplay = () => {
      if (!this.actor.system?.attribute) return; // Neuer Charakter, noch nicht initialisiert
      const items = this.actor.items;
      let totalWeight = 0;
      for (const item of items) {
        totalWeight += Number(item.system?.gewicht) || 0;
      }
      const staerke = Number(this.actor.system.attribute.staerke?.value) || 0;
      const zaehigkeit = Number(this.actor.system.fertigkeiten?.zaehigkeit) || 0;
      const maxCarry = ((staerke + zaehigkeit) / 2) * 20;
      html.find('.current-weight').text(totalWeight.toFixed(2));
      html.find('.max-carry').text(maxCarry.toFixed(2));
      if (totalWeight > maxCarry) html.find('.weight-warning').show(); else html.find('.weight-warning').hide();
    };
    updateWeightDisplay();

    // Hooks für Item-Änderungen (diese Actor-Instanz)
    // Armor value calculation (sum equipped armor 'verteidigung' / 2, rounded down)
    const updateArmorDefense = () => {
      let total = 0;
      for (const it of this.actor.items) {
        if (it.type === 'armor' && it.system?.equipped) {
          total += Number(it.system?.verteidigung) || 0;
        }
      }
      const value = Math.floor(total / 2);
      // Display only; we don't persist derived defense automatically
      html.find('.armor-defense-value').text(value);
    };

    // Initial armor display update
    updateArmorDefense();

    // One-time default assignment for missing armor defense values (heuristic by name)
    const inferDefaultArmorDefense = (name) => {
      const s = String(name || '').toLowerCase();
      if (s.includes('platten')) return 6;
      if (s.includes('platte')) return 6;
      if (s.includes('schuppen')) return 5;
      if (s.includes('ketten') || s.includes('kette') || s.includes('ring')) return 4;
      if (s.includes('leder')) return 2;
      if (s.includes('helm')) return 1;
      if (s.includes('schild')) return 2;
      return 1; // conservative fallback
    };
    (async () => {
      try {
        const updates = [];
        for (const it of this.actor.items) {
          if (it.type !== 'armor') continue;
          const vd = it.system?.verteidigung;
          if (vd === undefined || vd === null || vd === '') {
            updates.push({ _id: it.id, 'system.verteidigung': inferDefaultArmorDefense(it.name) });
          }
        }
        if (updates.length) {
          await this.actor.updateEmbeddedDocuments('Item', updates);
          updateArmorDefense();
        }
      } catch (e) {
        console.warn('Konnte Verteidigungswerte nicht initialisieren:', e);
      }
    })();

    // Combine hooks to update both weight and armor displays on item changes
    this._weightItemUpdate = (item, changes) => { if (item.parent?.id === this.actor.id) { updateWeightDisplay(); updateArmorDefense(); } };
    this._weightItemCreate = (item) => { if (item.parent?.id === this.actor.id) { updateWeightDisplay(); updateArmorDefense(); } };
    this._weightItemDelete = (item) => { if (item.parent?.id === this.actor.id) { updateWeightDisplay(); updateArmorDefense(); } };
    Hooks.on('updateItem', this._weightItemUpdate);
    Hooks.on('createItem', this._weightItemCreate);
    Hooks.on('deleteItem', this._weightItemDelete);
  }

  /* --- Kauf- / Kostenabzugslogik beim Drag & Drop eines Items ------------------ */
  _currencyToKS(c) {
    const KS_PER_SH = 56;
    const SH_PER_GD = 210;
    const KS_PER_GD = KS_PER_SH * SH_PER_GD; // 11760
    const gd = Number(c?.gd) || 0;
    const sh = Number(c?.sh) || 0;
    const ks = Number(c?.ks) || 0;
    return gd * KS_PER_GD + sh * KS_PER_SH + ks;
  }

  _ksToCurrency(totalKS) {
    const KS_PER_SH = 56;
    const SH_PER_GD = 210;
    const KS_PER_GD = KS_PER_SH * SH_PER_GD;
    let rest = Math.max(0, Number(totalKS) || 0);
    const gd = Math.floor(rest / KS_PER_GD); rest = rest % KS_PER_GD;
    const sh = Math.floor(rest / KS_PER_SH); rest = rest % KS_PER_SH;
    const ks = rest;
    return { gd, sh, ks };
  }

  async _attemptPurchase(itemData) {
    // Preis lesen (alle drei Währungen möglich)
    const preis = itemData?.system?.preis || { gd:0, sh:0, ks:0 };
    const costKS = this._currencyToKS(preis);
    if (costKS <= 0) return true; // kostenlos
    const wallet = this.actor.system?.waehrung || { gd:0, sh:0, ks:0 };
    const walletKS = this._currencyToKS(wallet);
    if (walletKS < costKS) {
      ui.notifications?.warn(`Nicht genug Mittel für Kauf (Kosten: ${costKS} KS-Gesamtwert).`);
      return false;
    }
    const remainingKS = walletKS - costKS;
    const newWallet = this._ksToCurrency(remainingKS);
    await this.actor.update({ 'system.waehrung': newWallet });
    ui.notifications?.info(`Gekauft: ${itemData.name} (-${preis.gd||0} GD, -${preis.sh||0} SH, -${preis.ks||0} KS)`);
    return true;
  }

  async _confirmPurchase(itemData) {
    const preis = itemData?.system?.preis || { gd:0, sh:0, ks:0 };
    const costKS = this._currencyToKS(preis);
    // Kostenlos? Keine Nachfrage nötig
    if (costKS <= 0) return true;
    const content = `<p>Willst du wirklich <strong>${foundry.utils.escapeHTML(itemData.name)}</strong> kaufen?</p>
                     <p>Preis: ${preis.gd||0} GD / ${preis.sh||0} SH / ${preis.ks||0} KS (≈ ${costKS} KS Gesamtwert)</p>`;
    return await new Promise(resolve => {
      new Dialog({
        title: 'Kauf bestätigen',
        content,
        buttons: {
          ja: { label: 'Ja, kaufen', callback: () => resolve(true) },
          nein: { label: 'Abbrechen', callback: () => resolve(false) }
        },
        default: 'ja',
        close: () => resolve(false)
      }).render(true);
    });
  }

  async _onDropItem(event, data) {
    // Versuche Item aus Drop-Daten zu laden (Pack oder Sidebar)
    let item;
    try {
      item = await Item.fromDropData(data);
    } catch (e) {
      return super._onDropItem(event, data);
    }
    if (!item) return super._onDropItem(event, data);
    if (!this.actor?.isOwner) {
      ui.notifications?.warn('Keine Berechtigung, Items hinzuzufügen.');
      return false;
    }
    const itemObj = item.toObject();
    // Nur Kaufprüfung für Items mit Preisfeldern
    if (['weapon','armor','gear'].includes(itemObj.type)) {
      const confirm = await this._confirmPurchase(itemObj);
      if (!confirm) return false;
      const ok = await this._attemptPurchase(itemObj);
      if (!ok) return false; // Abbruch bei fehlenden Mitteln
    }
    // Item tatsächlich anlegen
    const created = await this.actor.createEmbeddedDocuments('Item', [itemObj]);
    if (created?.length) {
      // Bei sofortigem Equip? (nicht verlangt) -> nichts
    }
    return created?.[0] || null;
  }

  // Ensure we unregister hooks when the sheet is closed
  close(options) {
    try {
      if (this._onActorUpdate) Hooks.off('updateActor', this._onActorUpdate);
      if (this._onItemUpdate) Hooks.off('updateItem', this._onItemUpdate);
      if (this._onActiveEffectChange) Hooks.off('updateActiveEffect', this._onActiveEffectChange);
      if (this._weightItemUpdate) Hooks.off('updateItem', this._weightItemUpdate);
      if (this._weightItemCreate) Hooks.off('createItem', this._weightItemCreate);
      if (this._weightItemDelete) Hooks.off('deleteItem', this._weightItemDelete);
    } catch (e) {
      console.warn('Fehler beim Entfernen der Actor-Update-Hooks:', e);
    }
    return super.close(options);
  }
}

Hooks.once("init", function () {
  
  // Registriere Handlebars Helpers zuerst (bevor sie in Templates verwendet werden)
  try {
    registerHandlebarsHelpers();
    Logger.log("Handlebars Helpers registriert");
  } catch (e) {
    Logger.error("Fehler beim Registrieren der Handlebars Helpers:", e);
  }

  // ========== System Settings Registration ==========
  game.settings.register(MODULE_ID, SETTINGS.START_PUNKTE, {
    name: "Start-Punkte für neue Charaktere",
    hint: "Anzahl der Charakterpunkte, die ein neuer Charakter zum Start erhält (Standard: 40)",
    scope: "world",
    config: true,
    type: Number,
    default: 40,
    onChange: value => {
      Logger.log(`Start-Punkte geändert auf: ${value}`);
    }
  });

  game.settings.register(MODULE_ID, "standardLP", {
    name: "Standard-Lebenspunkte",
    hint: "Standard-Lebenspunkte für neue Charaktere (Standard: 100)",
    scope: "world",
    config: true,
    type: Number,
    default: 100,
    onChange: value => {
      console.log(`Standard-LP geändert auf: ${value}`);
    }
  });

  game.settings.register(MODULE_ID, SETTINGS.FERTIGKEITS_BONUS_AKTIV, {
    name: "Fertigkeitsbonus-Regel aktivieren",
    hint: "Wenn aktiviert, erhalten ausgerüstete Fernkampfwaffen +1W6 Schaden bei Schütze ≥5 UND Entfernungssinn ≥5",
    scope: "world",
    config: true,
    type: Boolean,
    default: true,
    onChange: value => {
      console.log(`Fertigkeitsbonus-Regel: ${value ? 'aktiviert' : 'deaktiviert'}`);
    }
  });

  game.settings.register(MODULE_ID, "autoWaehrungskonvertierung", {
    name: "Automatische Währungskonvertierung",
    hint: "Automatisch KS → SH → GD konvertieren (56 KS = 1 SH, 210 SH = 1 GD)",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register(MODULE_ID, "maxAttributWert", {
    name: "Maximaler Attributwert",
    hint: "Höchster Wert, den ein Attribut erreichen kann (Standard: 20)",
    scope: "world",
    config: true,
    type: Number,
    default: 20,
    range: {
      min: 10,
      max: 30,
      step: 1
    }
  });

  game.settings.register(MODULE_ID, "maxFertigkeitWert", {
    name: "Maximaler Fertigkeitswert",
    hint: "Höchster Wert, den eine Fertigkeit erreichen kann (Standard: 20)",
    scope: "world",
    config: true,
    type: Number,
    default: 20,
    range: {
      min: 10,
      max: 30,
      step: 1
    }
  });

  game.settings.register(MODULE_ID, "adelsstandCharismaRegel", {
    name: "Adelsstand-Charisma-Regel",
    hint: "Bestimmte Adelsstände setzen Charisma automatisch (z.B. Bürgerlicher = 0, Lord = 4)",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register(MODULE_ID, "kaufpreisAbzug", {
    name: "Automatischer Kaufpreis-Abzug",
    hint: "Beim Drag & Drop von Items aus Compendium automatisch Preis von Währung abziehen",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register(MODULE_ID, "traglastRegel", {
    name: "Traglast-Berechnung",
    hint: "Traglast = ((Stärke + Zähigkeit) / 2) × 20",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  game.settings.register(MODULE_ID, "ruestungVerteidigungRegel", {
    name: "Rüstungsverteidigung-Berechnung",
    hint: "Verteidigung = Summe aller ausgerüsteten Rüstungs-Verteidigungswerte / 2 (abgerundet)",
    scope: "world",
    config: true,
    type: Boolean,
    default: true
  });

  // ========== Ende Settings ==========

  // Sheet-Registrierung (Standard-Methode, funktioniert V11-V13)
  Actors.unregisterSheet("core", ActorSheet);
  Actors.registerSheet("got-rpg", GotCharacterSheet, {
    types: ["character"],
    makeDefault: true
  });

  // Item Sheets
  class GotItemSheet extends ItemSheet {
    static get defaultOptions() {
      return foundry.utils.mergeObject(super.defaultOptions, {
        classes: ["got-rpg", "sheet", "item"],
        width: 500,
        height: 600
      });
    }
    get template() {
      const type = this.item.type;
      const base = "systems/got-rpg/templates/items";
      if (type === 'weapon') return `${base}/weapon.hbs`;
      if (type === 'armor') return `${base}/armor.hbs`;
      return `${base}/gear.hbs`;
    }
    async getData(options) {
      const data = await super.getData(options);
      return data;
    }
  }
  Items.registerSheet("got-rpg", GotItemSheet, { makeDefault: true });

  // Formatierung für Item-Boni (Anzeige im Inventar)
  Handlebars.registerHelper('formatItemBonuses', function(boni) {
    try {
      if (!boni) return '';
      const nameMap = {
        // Attribute
        geschick: 'Geschick',
        staerke: 'Stärke',
        charisma: 'Charisma',
        intuition: 'Intuition',
        wissen: 'Wissen',
        // Fertigkeiten
        ueberreden: 'Überreden',
        luegen: 'Lügen',
        einschuechtern: 'Einschüchtern',
        etikette: 'Etikette',
        nahkampf: 'Nahkampf',
        zaehigkeit: 'Zähigkeit',
        geschwindigkeit: 'Geschwindigkeit',
        schuetze: 'Schütze',
        fingerfertigkeit: 'Fingerfertigkeit',
        faehrtenlesen: 'Fährtenlesen',
        schleichen: 'Schleichen',
        vorahnung: 'Vorahnung',
        beurteilung: 'Beurteilung',
        entfernungssinn: 'Entfernungssinn',
        komplexerVerstand: 'Komplexer Verstand',
        magie: 'Magie'
      };
      const parts = [];
      const attr = boni.attribute || {};
      for (const [k,v] of Object.entries(attr)) {
        const n = Number(v) || 0; if (!n) continue;
        const label = nameMap[k] || (k.charAt(0).toUpperCase() + k.slice(1));
        parts.push(`${label} ${n>0?'+':''}${n}`);
      }
      const skills = boni.fertigkeiten || {};
      for (const [k,v] of Object.entries(skills)) {
        const n = Number(v) || 0; if (!n) continue;
        const label = nameMap[k] || (k.charAt(0).toUpperCase() + k.replace(/([A-Z])/g,' $1').slice(1));
        parts.push(`${label} ${n>0?'+':''}${n}`);
      }
      return parts.join(', ');
    } catch(e) {
      console.warn('formatItemBonuses Helper Fehler', e); return '';
    }
  });

  // Tooltip Text für Item-Boni
  Handlebars.registerHelper('itemBonusTooltip', function(item) {
    try {
      const boni = item?.system?.boni;
      if (!boni) return '';
      const nameMap = {
        geschick: 'Geschick', staerke: 'Stärke', charisma:'Charisma', intuition:'Intuition', wissen:'Wissen',
        ueberreden:'Überreden', luegen:'Lügen', einschuechtern:'Einschüchtern', etikette:'Etikette', nahkampf:'Nahkampf', zaehigkeit:'Zähigkeit', geschwindigkeit:'Geschwindigkeit', schuetze:'Schütze', fingerfertigkeit:'Fingerfertigkeit', faehrtenlesen:'Fährtenlesen', schleichen:'Schleichen', vorahnung:'Vorahnung', beurteilung:'Beurteilung', entfernungssinn:'Entfernungssinn', komplexerVerstand:'Komplexer Verstand', magie:'Magie'
      };
      const lines = [];
      const a = boni.attribute || {}; const s = boni.fertigkeiten || {};
      for (const [k,v] of Object.entries(a)) { const n=Number(v)||0; if(!n) continue; lines.push(`${nameMap[k]||k}: ${n>0?'+':''}${n}`); }
      for (const [k,v] of Object.entries(s)) { const n=Number(v)||0; if(!n) continue; lines.push(`${nameMap[k]||k}: ${n>0?'+':''}${n}`); }
      return lines.join('\n');
    } catch(e) { return ''; }
  });

  // Helper: Object.keys
  Handlebars.registerHelper('keys', function(obj) {
    return obj ? Object.keys(obj) : [];
  });

  // Helper: Array/Object length
  Handlebars.registerHelper('length', function(arr) {
    if (Array.isArray(arr)) return arr.length;
    if (arr && typeof arr === 'object') return Object.keys(arr).length;
    return 0;
  });

  // Helper: hasActiveBonuses
  Handlebars.registerHelper('hasActiveBonuses', function(summary) {
    try {
      const a = summary?.attributes || {};
      const s = summary?.skills || {};
      return Object.keys(a).length > 0 || Object.keys(s).length > 0;
    } catch(e) { return false; }
  });

  // Helper: formatBonusKey (mit Umlauten)
  Handlebars.registerHelper('formatBonusKey', function(key) {
    const nameMap = {
      geschick: 'Geschick', staerke: 'Stärke', charisma:'Charisma', intuition:'Intuition', wissen:'Wissen',
      ueberreden:'Überreden', luegen:'Lügen', einschuechtern:'Einschüchtern', etikette:'Etikette', nahkampf:'Nahkampf', zaehigkeit:'Zähigkeit', geschwindigkeit:'Geschwindigkeit', schuetze:'Schütze', fingerfertigkeit:'Fingerfertigkeit', faehrtenlesen:'Fährtenlesen', schleichen:'Schleichen', vorahnung:'Vorahnung', beurteilung:'Beurteilung', entfernungssinn:'Entfernungssinn', komplexerVerstand:'Komplexer Verstand', magie:'Magie'
    };
    return nameMap[key] || (key.charAt(0).toUpperCase() + key.slice(1));
  });

  // Helper: getFlag
  Handlebars.registerHelper('getFlag', function(doc, scope, key) {
    if (!doc || typeof doc.getFlag !== 'function') return null;
    return doc.getFlag(scope, key);
  });

  // Helper: includes (für String-Suche)
  Handlebars.registerHelper('includes', function(str, substring) {
    if (!str || typeof str !== 'string') return false;
    return str.includes(substring);
  });

  // Migrationssetting registrieren (unsichtbar im UI)
  game.settings.register('got-rpg', 'migrationVersion', {
    scope: 'world',
    config: false,
    type: Number,
    default: 0
  });

  // --- Migrationen (nach Settings-Registrierung) --------------
  const GOT_RPG_MIGRATION_VERSION = 3;
  
  // Migration direkt hier ausführen (nach Settings-Registrierung)
  setTimeout(async () => {
    try {
      const current = game.settings.get('got-rpg', 'migrationVersion') || 0;
      if (current >= GOT_RPG_MIGRATION_VERSION) return;

      console.log(`GoT RPG: Führe Migration von v${current} zu v${GOT_RPG_MIGRATION_VERSION} durch...`);

      // v1: Actor-gebundene Waffen vereinheitlichen
      if (current < 1) {
        for (const actor of game.actors?.contents || []) {
          if (!actor?.isOwner) continue;
          const toUpdate = [];
          for (const item of actor.items) {
            if (item.type === 'weapon') {
              const dmg = item.system?.schaden;
              if (dmg && dmg !== '1d6') {
                toUpdate.push({ _id: item.id, system: { schaden: '1d6' } });
              }
            }
          }
          if (toUpdate.length) {
            await actor.updateEmbeddedDocuments('Item', toUpdate);
          }
        }
      }

      // v2: Alte actor.system.boni zu Items übertragen
      if (current < 2) {
        for (const actor of game.actors?.contents || []) {
          if (!actor?.isOwner || !actor.system?.boni) continue;
          const oldBoni = actor.system.boni;
          const hasAttr = oldBoni.attribute && Object.keys(oldBoni.attribute).length;
          const hasFert = oldBoni.fertigkeiten && Object.keys(oldBoni.fertigkeiten).length;
          if (!hasAttr && !hasFert) continue;
          
          const migrationItem = {
            name: 'Migrierte Boni (alt)',
            type: 'gear',
            system: {
              gewicht: 0,
              preis: 0,
              equipped: true,
              boni: foundry.utils.duplicate(oldBoni)
            }
          };
          await actor.createEmbeddedDocuments('Item', [migrationItem]);
          await actor.update({ 'system.-=boni': null });
        }
      }

      // v3: Zustaende initialisieren
      if (current < 3) {
        for (const actor of game.actors?.contents || []) {
          if (!actor?.isOwner) continue;
          if (!actor.system?.zustaende) {
            await actor.update({
              'system.zustaende': {
                verwundet: false, erschoepft: false, vergiftet: false,
                betrunken: false, bewusstlos: false, blutend: false,
                verkrueppelt: false, verbrannt: false, erfroren: false,
                verhungert: false, verdurstet: false, krank: false,
                wahnsinnig: false, verflucht: false
              }
            });
          }
        }
      }

      await game.settings.set('got-rpg', 'migrationVersion', GOT_RPG_MIGRATION_VERSION);
      Logger.log('Migration erfolgreich abgeschlossen.');
    } catch (err) {
      Logger.error('Migration fehlgeschlagen:', err);
      ui.notifications?.error('Migration fehlgeschlagen – siehe Konsole.');
    }
  }, 100); // Kurze Verzögerung um sicherzustellen dass Settings bereit sind
});

// Hook to initialize new actors with default values
Hooks.on("preCreateActor", (actor, data, options, userId) => {
  if (actor.type === "character") {
    const updates = {};
    
    // Set initial points if not already set
    if (!data.system?.punkte?.verfuegbar) {
      updates["system.punkte.verfuegbar"] = 40;
    }
    
    // Set initial LP if not already set
    if (!data.system?.lebenspunkte?.aktuell) {
      updates["system.lebenspunkte.aktuell"] = 100;
    }
    if (!data.system?.lebenspunkte?.maximum) {
      updates["system.lebenspunkte.maximum"] = 100;
    }
    
    // Set initial currency if not already set
    if (!data.system?.waehrung?.gd) {
      updates["system.waehrung.gd"] = 1;
    }
    if (!data.system?.waehrung?.sh) {
      updates["system.waehrung.sh"] = 100;
    }
    
    if (Object.keys(updates).length > 0) {
      actor.updateSource(updates);
    }
  }
});

// Runtime Fallback: ersetze fehlerhafte Bilder auf der Seite
Hooks.on('renderCompendium', () => {
  setTimeout(() => {
    const PLACEHOLDER_ICON = 'icons/svg/sword.svg';
    document.querySelectorAll('.directory .document img').forEach(img => {
      if (!img.dataset.gotRpgFallbackBound) {
        img.dataset.gotRpgFallbackBound = '1';
        img.addEventListener('error', () => {
          if (img.src.endsWith('.webp')) {
            img.src = PLACEHOLDER_ICON;
          }
        });
      }
    });
  }, 250);
});

// Seeding-Hook: Falls Waffen-Paket leer ist, fülle es mit Standardwaffen
Hooks.once('ready', async () => {
  try {
    // Waffen Pack
    const wPack = game.packs.get('got-rpg.got-weapons');
    if (wPack) {
      // Dynamische Waffen-Icon Pfade aus fonts/weapons
      const WEAPON_ICON_BASE = 'systems/got-rpg/fonts/weapons';
      const weaponSlug = (name) => name.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '');
      const weaponIcon = (name) => `${WEAPON_ICON_BASE}/${weaponSlug(name)}.svg`;
      const wIndex = await wPack.getIndex();
      if (wIndex.size === 0) {
        console.group('[got-rpg] Seeding Waffen-Pack');
        const wSeed = [
          { name: 'Langschwert', type: 'weapon', img: weaponIcon('Langschwert'), system: { equipped:false, gewicht: 3, preis: { gd:0, sh:50, ks:0 }, schaden: '1d6', reichweite: 'Nahkampf', beschreibung:'Standard-Schwert.', boni:{ attribute:{ geschick:0, staerke:1, charisma:0, intuition:0, wissen:0 }, fertigkeiten:{ nahkampf:1 } } } },
          { name: 'Kurzschwert', type: 'weapon', img: weaponIcon('Kurzschwert'), system: { equipped:false, gewicht: 2, preis: { gd:0, sh:30, ks:0 }, schaden: '1d6', reichweite: 'Nahkampf', beschreibung:'Handliche Klinge.', boni:{ attribute:{ geschick:1, staerke:0, charisma:0, intuition:0, wissen:0 }, fertigkeiten:{ } } } },
          { name: 'Dolch', type: 'weapon', img: weaponIcon('Dolch'), system: { equipped:false, gewicht: 0.5, preis: { gd:0, sh:5, ks:0 }, schaden: '1d6', reichweite: 'Nahkampf/Wurf', beschreibung:'Kurze Klinge.', boni:{ attribute:{ geschick:1, staerke:0, charisma:0, intuition:0, wissen:0 }, fertigkeiten:{ fingerfertigkeit:1 } } } }
        ];
        let created;
        if (wPack.importDocuments) created = await wPack.importDocuments(wSeed);
        else if (wPack.createDocuments) created = await wPack.createDocuments(wSeed);
        else created = await Promise.all(wSeed.map(src => Item.create(src, {pack: wPack.collection})));        
        console.log('[got-rpg] Waffen-Pack seeding Ergebnis:', created.map(c => c.name));
        const newIndex = await wPack.getIndex();
        console.log('[got-rpg] Waffen-Pack Einträge nach Seeding:', newIndex.size);
        console.groupEnd();
        ui.notifications?.info('Basis-Waffen eingefügt.');
      } else {
        console.log('[got-rpg] Waffen-Pack bereits gefüllt, Größe:', wIndex.size);
        // Falls nur wenige (Seed-)Waffen vorhanden sind, fehlende aus voller Liste ergänzen
        if (wIndex.size < 20) {
          console.group('[got-rpg] Ergänze fehlende Waffen auf volle Liste');
          const existingNames = new Set(Array.from(wIndex.values()).map(e => e.name));
          const fullWeapons = [
            { name:'Langschwert', img: weaponIcon('Langschwert'), gewicht:3, preis:{gd:0,sh:50,ks:0}, reichweite:'Nahkampf', beschreibung:'Vielseitige Klinge.', boni:{attribute:{staerke:1,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Kurzschwert', img: weaponIcon('Kurzschwert'), gewicht:2, preis:{gd:0,sh:30,ks:0}, reichweite:'Nahkampf', beschreibung:'Handliche Waffe.', boni:{attribute:{staerke:0,geschick:1,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} },
            { name:'Dolch / Messer', img: weaponIcon('Dolch Messer'), gewicht:0.5, preis:{gd:0,sh:5,ks:0}, reichweite:'Nahkampf/Wurf', beschreibung:'Kleine Klinge.', boni:{attribute:{staerke:0,geschick:1,charisma:0,intuition:0,wissen:0}, fertigkeiten:{fingerfertigkeit:1}} },
            { name:'Speer', img: weaponIcon('Speer'), gewicht:2, preis:{gd:0,sh:10,ks:0}, reichweite:'Nahkampf/Wurf', beschreibung:'Vielseitige Stangenwaffe.', boni:{attribute:{staerke:0,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Lanze', img: weaponIcon('Lanze'), gewicht:4, preis:{gd:0,sh:40,ks:0}, reichweite:'Beritten', beschreibung:'Stoßwaffe für Reiter.', boni:{attribute:{staerke:2,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Jagdspieß', img: weaponIcon('Jagdspiess'), gewicht:3, preis:{gd:0,sh:15,ks:0}, reichweite:'Nahkampf', beschreibung:'Robuster Spieß.', boni:{attribute:{staerke:1,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} },
            { name:'Hellebarde', img: weaponIcon('Hellebarde'), gewicht:5, preis:{gd:0,sh:45,ks:0}, reichweite:'Nahkampf', beschreibung:'Schwere Stangenwaffe.', boni:{attribute:{staerke:2,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Kriegshammer', img: weaponIcon('Kriegshammer'), gewicht:4, preis:{gd:0,sh:35,ks:0}, reichweite:'Nahkampf', beschreibung:'Wuchtiger Hammer.', boni:{attribute:{staerke:2,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Streithammer', img: weaponIcon('Streithammer'), gewicht:3, preis:{gd:0,sh:25,ks:0}, reichweite:'Nahkampf', beschreibung:'Einhändiger Hammer.', boni:{attribute:{staerke:1,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} },
            { name:'Streitkolben (Morgenstern)', img: weaponIcon('Streitkolben Morgenstern'), gewicht:3, preis:{gd:0,sh:30,ks:0}, reichweite:'Nahkampf', beschreibung:'Stachelbesetzte Keule.', boni:{attribute:{staerke:1,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Keule', img: weaponIcon('Keule'), gewicht:2, preis:{gd:0,sh:2,ks:0}, reichweite:'Nahkampf', beschreibung:'Einfache Holzwaffe.', boni:{attribute:{staerke:0,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} },
            { name:'Axt (einfach)', img: weaponIcon('Axt einfach'), gewicht:3, preis:{gd:0,sh:20,ks:0}, reichweite:'Nahkampf', beschreibung:'Robuste Axt.', boni:{attribute:{staerke:1,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} },
            { name:'Doppelaxt', img: weaponIcon('Doppelaxt'), gewicht:5, preis:{gd:0,sh:50,ks:0}, reichweite:'Nahkampf', beschreibung:'Zweischneidige Axt.', boni:{attribute:{staerke:2,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Wurfaxt', img: weaponIcon('Wurfaxt'), gewicht:1, preis:{gd:0,sh:8,ks:0}, reichweite:'Wurf', beschreibung:'Leichte Wurfaxt.', boni:{attribute:{staerke:0,geschick:1,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} },
            { name:'Bogen', img: weaponIcon('Bogen'), gewicht:1, preis:{gd:0,sh:15,ks:0}, reichweite:'Fernkampf', beschreibung:'Einfacher Bogen.', boni:{attribute:{geschick:1,staerke:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{geschwindigkeit:0}} },
            { name:'Langbogen', img: weaponIcon('Langbogen'), gewicht:2, preis:{gd:0,sh:40,ks:0}, reichweite:'Fernkampf', beschreibung:'Mächtiger Langbogen.', boni:{attribute:{geschick:1,staerke:1,charisma:0,intuition:0,wissen:0}, fertigkeiten:{geschwindigkeit:1}} },
            { name:'Armbrust', img: weaponIcon('Armbrust'), gewicht:4, preis:{gd:0,sh:60,ks:0}, reichweite:'Fernkampf', beschreibung:'Schwere Armbrust.', boni:{attribute:{geschick:0,staerke:1,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} },
            { name:'Schild', img: weaponIcon('Schild'), gewicht:3, preis:{gd:0,sh:25,ks:0}, reichweite:'Nahkampf', beschreibung:'Defensives Schild.', boni:{attribute:{staerke:0,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{zaehigkeit:2}} },
            { name:'Streitflegel', img: weaponIcon('Streitflegel'), gewicht:3, preis:{gd:0,sh:28,ks:0}, reichweite:'Nahkampf', beschreibung:'Kettenwaffe.', boni:{attribute:{staerke:1,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{nahkampf:1}} },
            { name:'Sichelklinge / Bauernwerkzeug', img: weaponIcon('Sichelklinge Bauernwerkzeug'), gewicht:1, preis:{gd:0,sh:3,ks:0}, reichweite:'Nahkampf', beschreibung:'Improvisierte Waffe.', boni:{attribute:{staerke:0,geschick:0,charisma:0,intuition:0,wissen:0}, fertigkeiten:{}} }
          ];
          const missing = fullWeapons.filter(w => !existingNames.has(w.name));
          if (missing.length) {
            const docs = missing.map(w => ({
              name: w.name,
              type: 'weapon',
              img: w.img,
              system: {
                equipped: false,
                gewicht: w.gewicht,
                preis: w.preis,
                schaden: '1d6',
                reichweite: w.reichweite,
                beschreibung: w.beschreibung,
                boni: w.boni
              }
            }));
            let createdMissing;
            if (wPack.importDocuments) createdMissing = await wPack.importDocuments(docs);
            else if (wPack.createDocuments) createdMissing = await wPack.createDocuments(docs);
            else createdMissing = await Promise.all(docs.map(src => Item.create(src, {pack: wPack.collection})));            
            console.log('[got-rpg] Fehlende Waffen hinzugefügt:', createdMissing.map(c => c.name));
            ui.notifications?.info(`Fehlende Waffen ergänzt: ${createdMissing.length}`);
          } else {
            console.log('[got-rpg] Keine fehlenden Waffen zu ergänzen.');
          }
          console.groupEnd();
        }
      }
    }
    // Rüstungen Pack
    const aPack = game.packs.get('got-rpg.got-armor');
    if (aPack) {
      const aIndex = await aPack.getIndex();
      const fullArmor = [
        { name:'Gambeson / Waffenrock', img:'icons/equipment/chest/shirt-gambeson.webp', gewicht:6, preis:{gd:0,sh:18,ks:0}, schutz:'leicht', beschreibung:'Gepolsterte Stoffrüstung, grundliegender Schutz.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Lederharnisch / gehärtetes Leder', img:'icons/equipment/chest/leather-armor-brown.webp', gewicht:8, preis:{gd:0,sh:25,ks:0}, schutz:'leicht', beschreibung:'Gehärtetes Leder für Flexibilität.', boni:{ fertigkeiten:{ verteidigung:1, zaehigkeit:1 } } },
        { name:'Verstärktes Leder (genietet)', img:'icons/equipment/chest/leather-armor-studded.webp', gewicht:10, preis:{gd:0,sh:40,ks:0}, schutz:'leicht', beschreibung:'Genietetes Leder erhöht Widerstand.', boni:{ fertigkeiten:{ verteidigung:2 } } },
        { name:'Kettenhemd (Hauberk)', img:'icons/equipment/chest/chainmail-shirt.webp', gewicht:15, preis:{gd:0,sh:65,ks:0}, schutz:'mittel', beschreibung:'Standard-Kettenhemd für Torso.', boni:{ fertigkeiten:{ verteidigung:2 } } },
        { name:'Kettenhemd mit Ärmel und Coif', img:'icons/equipment/chest/chainmail-armor.webp', gewicht:18, preis:{gd:0,sh:80,ks:0}, schutz:'mittel', beschreibung:'Erweitertes Kettenhemd mit Haube.', boni:{ fertigkeiten:{ verteidigung:3 } } },
        { name:'Kettenbeinlinge', img:'icons/equipment/legs/chainmail-greaves.webp', gewicht:7, preis:{gd:0,sh:30,ks:0}, schutz:'mittel', beschreibung:'Beinschutz aus Kettengliedern.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Ringpanzer (Ringmail)', img:'icons/equipment/chest/breastplate-ringmail.webp', gewicht:14, preis:{gd:0,sh:55,ks:0}, schutz:'mittel', beschreibung:'Geflochtene Ringe – etwas leichter.', boni:{ fertigkeiten:{ verteidigung:2 } } },
        { name:'Schuppenpanzer (Scale Armor)', img:'icons/equipment/chest/scale-mail-breastplate.webp', gewicht:17, preis:{gd:0,sh:85,ks:0}, schutz:'mittel', beschreibung:'Überlappende Schuppen für soliden Schutz.', boni:{ fertigkeiten:{ verteidigung:3 } } },
        { name:'Lamellenpanzer', img:'icons/equipment/chest/lamellar-armor.webp', gewicht:16, preis:{gd:0,sh:90,ks:0}, schutz:'mittel', beschreibung:'Gebundene Plättchen (Osten / freie Städte).', boni:{ fertigkeiten:{ verteidigung:3 } } },
        { name:'Brustplatte (einfach)', img:'icons/equipment/chest/breastplate-simple.webp', gewicht:12, preis:{gd:0,sh:95,ks:0}, schutz:'mittel', beschreibung:'Einfache Plattenbrust für den Torso.', boni:{ fertigkeiten:{ verteidigung:3 } } },
        { name:'Plattenschultern (Pauldrons)', img:'icons/equipment/shoulder/pauldrons-metal.webp', gewicht:5, preis:{gd:0,sh:35,ks:0}, schutz:'mittel', beschreibung:'Metall-Schulterschutz.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Armschienen (Vambraces)', img:'icons/equipment/wrist/bracer-mettallic.webp', gewicht:3, preis:{gd:0,sh:20,ks:0}, schutz:'leicht', beschreibung:'Schutz für Unterarme.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Beinpanzer (Greaves)', img:'icons/equipment/legs/leg-armor-metal.webp', gewicht:6, preis:{gd:0,sh:30,ks:0}, schutz:'mittel', beschreibung:'Metallene Beinschienen.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Helm mit Nasal (Nasenhelm)', img:'icons/equipment/head/helm-barbute.webp', gewicht:4, preis:{gd:0,sh:22,ks:0}, schutz:'leicht', beschreibung:'Offener Helm mit Nasenschutz.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Vollhelm / Topfhelm', img:'icons/equipment/head/helm-great.webp', gewicht:6, preis:{gd:0,sh:45,ks:0}, schutz:'mittel', beschreibung:'Rundum geschlossener Helm.', boni:{ fertigkeiten:{ verteidigung:2, wahrnehmung:-1 } } },
        { name:'Kettenhaube unter dem Helm', img:'icons/equipment/head/hood-chainmail.webp', gewicht:3, preis:{gd:0,sh:18,ks:0}, schutz:'leicht', beschreibung:'Kettenschutz für Kopf/Hals.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Rundschild (Holz)', img:'icons/equipment/shield/round-wooden-boss.webp', gewicht:5, preis:{gd:0,sh:25,ks:0}, schutz:'leicht', beschreibung:'Holzschild mit Metallkante.', boni:{ fertigkeiten:{ verteidigung:2 } } },
        { name:'Drachenschild / Ovalschild', img:'icons/equipment/shield/kite-wooden-boss.webp', gewicht:6, preis:{gd:0,sh:38,ks:0}, schutz:'mittel', beschreibung:'Verlängerter Schild für mehr Abdeckung.', boni:{ fertigkeiten:{ verteidigung:3 } } },
        { name:'Tartsche (kleiner Schild)', img:'icons/equipment/shield/buckler-metal.webp', gewicht:2, preis:{gd:0,sh:15,ks:0}, schutz:'leicht', beschreibung:'Kleiner Rundschild für Beweglichkeit.', boni:{ fertigkeiten:{ verteidigung:1, geschwindigkeit:1 } } },
        { name:'Reiterhelm / Kesselhelm', img:'icons/equipment/head/helm-cavalry.webp', gewicht:5, preis:{gd:0,sh:40,ks:0}, schutz:'mittel', beschreibung:'Helm mit Sichtschlitzen für Reiter.', boni:{ fertigkeiten:{ verteidigung:2 } } },
        { name:'Gepolsterte Handschuhe', img:'icons/equipment/hand/gauntlet-leather-padded.webp', gewicht:1, preis:{gd:0,sh:8,ks:0}, schutz:'leicht', beschreibung:'Grundschutz für Hände.', boni:{ fertigkeiten:{ verteidigung:1 } } },
        { name:'Lederhandschuhe', img:'icons/equipment/hand/glove-leather-brown.webp', gewicht:1, preis:{gd:0,sh:12,ks:0}, schutz:'leicht', beschreibung:'Robuste Lederhandschuhe.', boni:{ fertigkeiten:{ verteidigung:1, fingerfertigkeit:1 } } },
        { name:'Plattenhandschuhe (Stulpen)', img:'icons/equipment/hand/gauntlet-metal.webp', gewicht:2, preis:{gd:0,sh:28,ks:0}, schutz:'mittel', beschreibung:'Metallene Stulpen für maximale Handabwehr.', boni:{ fertigkeiten:{ verteidigung:2, fingerfertigkeit:-1 } } }
      ];
      if (aIndex.size === 0) {
        console.group('[got-rpg] Seeding Rüstungen-Pack (vollständige Liste)');
        const seedPayload = fullArmor.map(a => ({
          name: a.name,
          type:'armor',
          img: a.img,
          system:{
            equipped:false,
            gewicht: a.gewicht,
            preis: a.preis,
            beschreibung: a.beschreibung,
            schutz: a.schutz,
            boni: a.boni || { attribute:{}, fertigkeiten:{} }
          }
        }));
        let createdA;
        if (aPack.importDocuments) createdA = await aPack.importDocuments(seedPayload);
        else if (aPack.createDocuments) createdA = await aPack.createDocuments(seedPayload);
        else createdA = await Promise.all(seedPayload.map(src => Item.create(src, {pack:aPack.collection})));
        console.log('[got-rpg] Rüstungen-Pack seeding Ergebnis:', createdA.map(c=>c.name));
        const newAIndex = await aPack.getIndex();
        console.log('[got-rpg] Rüstungen-Pack Einträge nach Seeding:', newAIndex.size);
        console.groupEnd();
        ui.notifications?.info('Alle Rüstungen eingefügt.');
      } else {
        console.log('[got-rpg] Rüstungen-Pack bereits gefüllt, Größe:', aIndex.size);
        if (aIndex.size < fullArmor.length) {
          console.group('[got-rpg] Ergänze fehlende Rüstungen');
          const existingArmorNames = new Set(Array.from(aIndex.values()).map(e => e.name));
          const missingArmor = fullArmor.filter(a => !existingArmorNames.has(a.name));
          if (missingArmor.length) {
            const docs = missingArmor.map(a => ({
              name:a.name,
              type:'armor',
              img:a.img,
              system:{
                equipped:false,
                gewicht:a.gewicht,
                preis:a.preis,
                beschreibung:a.beschreibung,
                schutz:a.schutz,
                boni:a.boni || { attribute:{}, fertigkeiten:{} }
              }
            }));
            let createdMissingArmor;
            if (aPack.importDocuments) createdMissingArmor = await aPack.importDocuments(docs);
            else if (aPack.createDocuments) createdMissingArmor = await aPack.createDocuments(docs);
            else createdMissingArmor = await Promise.all(docs.map(src => Item.create(src, {pack:aPack.collection})));
            console.log('[got-rpg] Fehlende Rüstungen hinzugefügt:', createdMissingArmor.map(c=>c.name));
            ui.notifications?.info(`Fehlende Rüstungen ergänzt: ${createdMissingArmor.length}`);
          } else {
            console.log('[got-rpg] Keine fehlenden Rüstungen.');
          }
          console.groupEnd();
        }
      }
    }
    // Ausrüstung Pack
    const gPack = game.packs.get('got-rpg.got-gear');
    if (gPack) {
      const GEAR_PARENT = 'Ausrüstung';
      const GEAR_ICONS = {
        'Basis-Ausrüstung & Werkzeug': 'icons/tools/hand/hammer-simple-iron-grey.webp',
        'Camping & Reiseutensilien': 'icons/environment/settlement/tent-leather-brown.webp',
        'Kleidung & Alltag': 'icons/equipment/chest/shirt-simple-white.webp',
        'Transport & Behälter': 'icons/containers/bags/pouch-leather-tan-red.webp',
        'Werkzeug & Handwerk': 'icons/tools/hand/saw-simple-steel-brown.webp',
        'Reichtümer & Handel': 'icons/commodities/currency/coin-inset-gold-orange.webp',
        'Persönliche & kulturelle Gegenstände': 'icons/sundries/books/book-embossed-gold-red.webp',
        'Pferde- & Reiseausrüstung': 'icons/environment/creatures/horse.webp',
        'Erkundungs- & Spezialausrüstung': 'icons/tools/navigation/compass-brass-blue-red.webp'
      };
      const gearCategories = {
        'Basis-Ausrüstung & Werkzeug': [
          { n:'Rucksack', w:1.5, p:{gd:0,sh:8,ks:0} },
          { n:'Ledertasche', w:0.8, p:{gd:0,sh:5,ks:0} },
          { n:'Beutel aus Stoff', w:0.2, p:{gd:0,sh:1,ks:0} },
          { n:'Gürtel mit Schlaufen', w:0.5, p:{gd:0,sh:3,ks:0} },
          { n:'Seil (10 m)', w:2, p:{gd:0,sh:2,ks:0} },
          { n:'Seil (20 m)', w:4, p:{gd:0,sh:4,ks:0} },
          { n:'Seil (30 m)', w:6, p:{gd:0,sh:6,ks:0} },
          { n:'Haken', w:0.3, p:{gd:0,sh:1,ks:0} },
          { n:'Fackel', w:1, p:{gd:0,sh:0,ks:50} },
          { n:'Feuerstein und Stahl', w:0.2, p:{gd:0,sh:2,ks:0} },
          { n:'Zunderbeutel', w:0.1, p:{gd:0,sh:1,ks:0} },
          { n:'Laterne', w:1.5, p:{gd:0,sh:10,ks:0} },
          { n:'Öllampe', w:0.8, p:{gd:0,sh:6,ks:0} },
          { n:'Nähset', w:0.3, p:{gd:0,sh:3,ks:0} },
          { n:'Schaufel (klein)', w:2, p:{gd:0,sh:5,ks:0} },
          { n:'Spitzhacke (klein)', w:2.5, p:{gd:0,sh:6,ks:0} },
          { n:'Hammer', w:1.5, p:{gd:0,sh:4,ks:0} },
          { n:'Meißel', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Axtstiel / Werkzeuggriff', w:1, p:{gd:0,sh:2,ks:0} },
          { n:'Schleifstein', w:2, p:{gd:0,sh:3,ks:0} },
          { n:'Wetzstein', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Metallstift', w:0.1, p:{gd:0,sh:1,ks:50} }
        ],
        'Camping & Reiseutensilien': [
          { n:'Decke', w:2, p:{gd:0,sh:4,ks:0} },
          { n:'Umhang', w:1.5, p:{gd:0,sh:6,ks:0} },
          { n:'Fellrollen', w:3, p:{gd:0,sh:10,ks:0} },
          { n:'Zeltplane', w:4, p:{gd:0,sh:12,ks:0} },
          { n:'Zeltstangen', w:3, p:{gd:0,sh:5,ks:0} },
          { n:'Seile fürs Zelt', w:1.5, p:{gd:0,sh:2,ks:0} },
          { n:'Heringe', w:0.5, p:{gd:0,sh:1,ks:0} },
          { n:'Bedroll (Schlafrolle)', w:2.5, p:{gd:0,sh:7,ks:0} },
          { n:'Reisekissen', w:0.8, p:{gd:0,sh:3,ks:0} },
          { n:'Wachsplanen', w:2, p:{gd:0,sh:8,ks:0} }
        ],
        'Kleidung & Alltag': [
          { n:'Zusätzliche Unterwäsche', w:0.3, p:{gd:0,sh:2,ks:0} },
          { n:'Reisehose', w:0.8, p:{gd:0,sh:5,ks:0} },
          { n:'Reisehemd', w:0.5, p:{gd:0,sh:4,ks:0} },
          { n:'Umhängetuch', w:0.4, p:{gd:0,sh:3,ks:0} },
          { n:'Handschuhe (Leder)', w:0.2, p:{gd:0,sh:4,ks:0} },
          { n:'Wollsocken', w:0.2, p:{gd:0,sh:1,ks:50} },
          { n:'Sandalen', w:0.5, p:{gd:0,sh:3,ks:0} },
          { n:'Mantelbroche', w:0.1, p:{gd:0,sh:8,ks:0} },
          { n:'Gürtelriemen', w:0.3, p:{gd:0,sh:2,ks:0} },
          { n:'Hut oder Kapuze', w:0.3, p:{gd:0,sh:3,ks:0} }
        ],
        'Transport & Behälter': [
          { n:'Wasserschlauch (leer)', w:0.5, p:{gd:0,sh:3,ks:0} },
          { n:'Holzschüssel', w:0.4, p:{gd:0,sh:1,ks:50} },
          { n:'Holzteller', w:0.3, p:{gd:0,sh:1,ks:30} },
          { n:'Besteck (Holz)', w:0.2, p:{gd:0,sh:1,ks:0} },
          { n:'Dosen aus Metall', w:0.6, p:{gd:0,sh:5,ks:0} },
          { n:'Keramikgefäß', w:1.2, p:{gd:0,sh:4,ks:0} },
          { n:'Holzkiste', w:3, p:{gd:0,sh:6,ks:0} },
          { n:'Lederscheide (Werkzeug)', w:0.4, p:{gd:0,sh:3,ks:0} },
          { n:'Leinensäcke', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Weidenkorb', w:1, p:{gd:0,sh:4,ks:0} }
        ],
        'Werkzeug & Handwerk': [
          { n:'Schnitzmesser', w:0.3, p:{gd:0,sh:3,ks:0} },
          { n:'Reibe', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Nadelbügel', w:0.2, p:{gd:0,sh:2,ks:0} },
          { n:'Zange', w:0.8, p:{gd:0,sh:5,ks:0} },
          { n:'Feuerhaken', w:1, p:{gd:0,sh:4,ks:0} },
          { n:'Kleine Säge', w:1.2, p:{gd:0,sh:6,ks:0} },
          { n:'Klammern aus Holz', w:0.1, p:{gd:0,sh:0,ks:50} },
          { n:'Holzkeile', w:0.3, p:{gd:0,sh:1,ks:0} },
          { n:'Metallhaken', w:0.4, p:{gd:0,sh:2,ks:0} },
          { n:'Maurerkelle', w:0.6, p:{gd:0,sh:3,ks:0} }
        ],
        'Reichtümer & Handel': [
          { n:'Münzbeutel', w:0.2, p:{gd:0,sh:3,ks:0} },
          { n:'Siegelwachs', w:0.3, p:{gd:0,sh:5,ks:0} },
          { n:'Siegelring', w:0.05, p:{gd:0,sh:15,ks:0} },
          { n:'Dokumentenrolle', w:0.2, p:{gd:0,sh:4,ks:0} },
          { n:'Handelsvertrag', w:0.1, p:{gd:0,sh:2,ks:0} },
          { n:'Kleines Buch über Schulden', w:0.5, p:{gd:0,sh:6,ks:0} },
          { n:'Stoffballen zum Tauschen', w:5, p:{gd:0,sh:20,ks:0} }
        ],
        'Persönliche & kulturelle Gegenstände': [
          { n:'Tagebuch', w:0.8, p:{gd:0,sh:10,ks:0} },
          { n:'Federkiel', w:0.05, p:{gd:0,sh:1,ks:0} },
          { n:'Tintenfass', w:0.3, p:{gd:0,sh:4,ks:0} },
          { n:'Pergamentrollen', w:0.2, p:{gd:0,sh:3,ks:0} },
          { n:'Kleines Gebetsbuch', w:0.5, p:{gd:0,sh:8,ks:0} },
          { n:'Glücksbringer', w:0.1, p:{gd:0,sh:2,ks:0} },
          { n:'Talisman', w:0.1, p:{gd:0,sh:5,ks:0} },
          { n:'Familienmedaillon', w:0.1, p:{gd:0,sh:12,ks:0} },
          { n:'Gebetssteine', w:0.3, p:{gd:0,sh:3,ks:0} },
          { n:'Holzfigur', w:0.4, p:{gd:0,sh:4,ks:0} }
        ],
        'Pferde- & Reiseausrüstung': [
          { n:'Satteltaschen', w:2, p:{gd:0,sh:15,ks:0} },
          { n:'Zaumzeug', w:1.5, p:{gd:0,sh:10,ks:0} },
          { n:'Pferdekamm', w:0.3, p:{gd:0,sh:3,ks:0} },
          { n:'Hufkratzer', w:0.2, p:{gd:0,sh:2,ks:0} },
          { n:'Hufeisen', w:0.5, p:{gd:0,sh:4,ks:0} },
          { n:'Pferdedecke', w:3, p:{gd:0,sh:12,ks:0} },
          { n:'Stricke', w:1.5, p:{gd:0,sh:3,ks:0} },
          { n:'Halfter', w:0.8, p:{gd:0,sh:5,ks:0} },
          { n:'Packgurte', w:1, p:{gd:0,sh:6,ks:0} },
          { n:'Lederfett', w:0.4, p:{gd:0,sh:4,ks:0} }
        ],
        'Erkundungs- & Spezialausrüstung': [
          { n:'Kompass', w:0.3, p:{gd:0,sh:25,ks:0} },
          { n:'Karte (Reisekarte)', w:0.2, p:{gd:0,sh:8,ks:0} },
          { n:'Maßband aus Leinen', w:0.3, p:{gd:0,sh:3,ks:0} },
          { n:'Kreide', w:0.1, p:{gd:0,sh:0,ks:50} },
          { n:'Signalhorn', w:0.8, p:{gd:0,sh:10,ks:0} },
          { n:'Kerze', w:0.2, p:{gd:0,sh:1,ks:0} },
          { n:'Wachsblock', w:0.5, p:{gd:0,sh:3,ks:0} },
          { n:'Leere Flaschen', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Glaskugeln', w:0.3, p:{gd:0,sh:6,ks:0} },
          { n:'Kleines Netz', w:1, p:{gd:0,sh:5,ks:0} }
        ]
      };
      const gIndex = await gPack.getIndex();
      const existingGNames = new Set(Array.from(gIndex.values()).map(e=>e.name));
      const needsGearSeed = gIndex.size === 0;
      // Folder Helfer
      async function ensureGearFolders(pack, categoryNames) {
        let parentFolder = game.folders.find(f => f.type==='Item' && f.pack===pack.collection && f.name===GEAR_PARENT && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: GEAR_PARENT, type:'Item', pack:pack.collection, sorting:'a' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type==='Item' && f.pack===pack.collection && f.name===cat && f.parent?.id===parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type:'Item', parent: parentFolder.id, pack: pack.collection, sorting:'a' });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      async function ensureWorldGearFolders(categoryNames) {
        let parentFolder = game.folders.find(f => f.type==='Item' && f.name===GEAR_PARENT && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: GEAR_PARENT, type:'Item' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type==='Item' && f.name===cat && f.parent?.id===parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type:'Item', parent: parentFolder.id });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      if (gPack.locked) {
        console.warn('[got-rpg] Ausrüstung-Pack locked. Nutze World-Fallback.');
        const worldExisting = game.items.contents.filter(i => i.system?.kategorie && Object.keys(gearCategories).includes(i.system.kategorie));
        if (!worldExisting.length) {
          const folderMap = await ensureWorldGearFolders(Object.keys(gearCategories));
          const docs = [];
          for (const [cat, arr] of Object.entries(gearCategories)) {
            for (const item of arr) {
              docs.push({ name:item.n, type:'gear', folder:folderMap[cat], img:GEAR_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          await Item.create(docs);
          ui.notifications?.info('Ausrüstung (World) mit Unterordnern eingefügt.');
        }
      } else {
        if (needsGearSeed) {
          console.group('[got-rpg] Seeding Ausrüstung-Pack');
          const folderMap = await ensureGearFolders(gPack, Object.keys(gearCategories));
          const docs = [];
          for (const [cat, arr] of Object.entries(gearCategories)) {
            for (const item of arr) {
              docs.push({ name:item.n, type:'gear', folder:folderMap[cat], img:GEAR_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          let createdG;
          if (gPack.importDocuments) createdG = await gPack.importDocuments(docs);
          else if (gPack.createDocuments) createdG = await gPack.createDocuments(docs);
          else createdG = await Promise.all(docs.map(src => Item.create(src, {pack:gPack.collection})));
          console.log('[got-rpg] Ausrüstung-Pack seeding Ergebnis:', createdG.map(c=>c.name));
          console.groupEnd();
          ui.notifications?.info('Ausrüstung eingefügt.');
        } else {
          const missing = [];
          for (const [cat, arr] of Object.entries(gearCategories)) {
            for (const item of arr) {
              if (!existingGNames.has(item.n)) missing.push({ name:item.n, type:'gear', img:GEAR_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          if (missing.length) {
            console.group('[got-rpg] Ergänze fehlende Ausrüstung');
            let createdMissingG;
            if (gPack.importDocuments) createdMissingG = await gPack.importDocuments(missing);
            else if (gPack.createDocuments) createdMissingG = await gPack.createDocuments(missing);
            else createdMissingG = await Promise.all(missing.map(src => Item.create(src, {pack:gPack.collection})));
            console.log('[got-rpg] Fehlende Ausrüstung hinzugefügt:', createdMissingG.map(c=>c.name));
            console.groupEnd();
            ui.notifications?.info(`Fehlende Ausrüstung ergänzt: ${missing.length}`);
          }
        }
      }
    }

    // Food Pack (Essen & Vorräte)
    const fPack = game.packs.get('got-rpg.got-food');
    if (fPack) {
      if (fPack.locked) {
        console.log('[got-rpg] Food-Pack locked: erstelle Ersatz-Pack mit Kategorien & Unterordnern.');
      }
      // World-Folder Helfer (für direkten World-Seeding ohne Pack)
      async function ensureWorldFoodFolders(categoryNames) {
        const parentName = 'Essen & Vorräte';
        let parentFolder = game.folders.find(f => f.type === 'Item' && f.name === parentName && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: parentName, type: 'Item' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type === 'Item' && f.name === cat && f.parent?.id === parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type: 'Item', parent: parentFolder.id });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      // Pack-Folder Helfer (für World-Compendium altPack)
      async function ensurePackFoodFolders(pack, categoryNames) {
        const parentName = 'Essen & Vorräte';
        let parentFolder = game.folders.find(f => f.type === 'Item' && f.pack === pack.collection && f.name === parentName && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: parentName, type: 'Item', pack: pack.collection, sorting: 'a' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type === 'Item' && f.pack === pack.collection && f.name === cat && f.parent?.id === parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type: 'Item', parent: parentFolder.id, pack: pack.collection, sorting: 'a' });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      // Falls System-Pack gesperrt (locked), nutze World-Pack mit voller Kategorienliste
      if (fPack.locked) {
        console.warn('[got-rpg] Food-Pack locked (System). Erzeuge World-Variante inkl. Unterordner.');
        let altPack = game.packs.get('world.got-food-world');
        if (!altPack && game.packs.createCompendium) {
          try {
            altPack = await game.packs.createCompendium({ label: 'Essen & Vorräte (World)', type: 'Item', name: 'got-food-world', private: false });
            console.log('[got-rpg] World Food-Pack erstellt:', altPack.collection);
          } catch (cpErr) {
            console.warn('[got-rpg] Konnte World Food-Pack nicht erstellen:', cpErr);
          }
        }
        const foodCategoriesFull = {
          'Fleisch & Fisch': [
            { n:'Geräuchertes Schwein', w:1.0, p:{gd:0,sh:6,ks:0} },
            { n:'Gebratener Hirsch', w:1.5, p:{gd:0,sh:9,ks:0} },
            { n:'Eintopf aus Hammel', w:0.8, p:{gd:0,sh:5,ks:0} },
            { n:'Ziege am Spieß', w:1.2, p:{gd:0,sh:7,ks:0} },
            { n:'Lammkeule', w:1.0, p:{gd:0,sh:8,ks:0} },
            { n:'Rinderschmorbraten', w:1.4, p:{gd:0,sh:10,ks:0} },
            { n:'Wildschwein', w:1.6, p:{gd:0,sh:12,ks:0} },
            { n:'Gebratene Tauben', w:0.6, p:{gd:0,sh:4,ks:0} },
            { n:'Huhn am Spieß', w:1.0, p:{gd:0,sh:6,ks:0} },
            { n:'Geräucherte Forelle', w:0.5, p:{gd:0,sh:5,ks:0} },
            { n:'Gesalzener Dorsch', w:0.7, p:{gd:0,sh:6,ks:0} },
            { n:'Heiße Krabben', w:0.6, p:{gd:0,sh:9,ks:0} },
            { n:'Austern', w:0.4, p:{gd:0,sh:11,ks:0} },
            { n:'Aal', w:0.6, p:{gd:0,sh:7,ks:0} },
            { n:'Gepökelter Speck', w:0.5, p:{gd:0,sh:5,ks:0} }
          ],
          'Brot & Getreide': [
            { n:'Schwarzbrot (Nordbrot)', w:0.6, p:{gd:0,sh:3,ks:0} },
            { n:'Gerstenbrot', w:0.5, p:{gd:0,sh:2,ks:40} },
            { n:'Honigbrot', w:0.5, p:{gd:0,sh:4,ks:0} },
            { n:'Haferbrei', w:0.4, p:{gd:0,sh:2,ks:0} },
            { n:'Gerstenbrei', w:0.4, p:{gd:0,sh:2,ks:0} },
            { n:'Gebratene Zwiebeln', w:0.3, p:{gd:0,sh:1,ks:50} },
            { n:'Knoblauchknollen', w:0.2, p:{gd:0,sh:1,ks:20} },
            { n:'Gebackene Kartoffeln', w:0.5, p:{gd:0,sh:2,ks:0} },
            { n:'Geröstete Nüsse', w:0.3, p:{gd:0,sh:2,ks:50} },
            { n:'Hartkäse', w:0.7, p:{gd:0,sh:5,ks:0} }
          ],
          'Milch & Einfaches': [
            { n:'Butter', w:0.2, p:{gd:0,sh:2,ks:0} },
            { n:'Frischer Ziegenkäse', w:0.4, p:{gd:0,sh:4,ks:0} },
            { n:'Schafskäse', w:0.5, p:{gd:0,sh:5,ks:0} },
            { n:'Kuhmilch', w:0.5, p:{gd:0,sh:2,ks:0} },
            { n:'Rahm', w:0.3, p:{gd:0,sh:3,ks:0} },
            { n:'Dickmilch (Essos)', w:0.4, p:{gd:0,sh:3,ks:0} }
          ],
          'Früchte & Gemüse': [
            { n:'Äpfel', w:0.4, p:{gd:0,sh:2,ks:0} },
            { n:'Birnen', w:0.4, p:{gd:0,sh:2,ks:0} },
            { n:'Pflaumen', w:0.3, p:{gd:0,sh:2,ks:0} },
            { n:'Trauben', w:0.5, p:{gd:0,sh:3,ks:0} },
            { n:'Beerenmix', w:0.3, p:{gd:0,sh:2,ks:50} },
            { n:'Zwiebeln', w:0.3, p:{gd:0,sh:1,ks:50} },
            { n:'Rüben', w:0.5, p:{gd:0,sh:1,ks:50} },
            { n:'Möhren', w:0.4, p:{gd:0,sh:1,ks:50} },
            { n:'Kohl', w:0.8, p:{gd:0,sh:2,ks:0} },
            { n:'Lauch', w:0.3, p:{gd:0,sh:1,ks:50} }
          ],
          'Süßspeisen & Gebäck': [
            { n:'Törtchen mit Honig', w:0.2, p:{gd:0,sh:3,ks:0} },
            { n:'Zitronenkuchen', w:0.4, p:{gd:0,sh:6,ks:0} },
            { n:'Apfelkuchen', w:0.5, p:{gd:0,sh:5,ks:0} },
            { n:'Gebratene Kastanien', w:0.3, p:{gd:0,sh:2,ks:50} },
            { n:'Süßer Fruchtsirup', w:0.3, p:{gd:0,sh:7,ks:0} }
          ],
          'Eintöpfe & Gerichte': [
            { n:'Dicke Fleischsuppe', w:0.8, p:{gd:0,sh:5,ks:0} },
            { n:'Fischsuppe', w:0.8, p:{gd:0,sh:5,ks:0} },
            { n:'Brei-Eintopf aus Gemüse', w:0.7, p:{gd:0,sh:4,ks:0} },
            { n:'Bohnen mit Speck', w:0.7, p:{gd:0,sh:5,ks:0} }
          ]
        };
        const targetPack = altPack && !altPack.locked ? altPack : null;
        const seedIntoWorld = !targetPack;
        const fIndex = targetPack ? await targetPack.getIndex() : new Map();
        const doSeeding = seedIntoWorld || fIndex.size === 0;
        if (doSeeding) {
          const foodDocs = [];
          for (const [cat, arr] of Object.entries(foodCategoriesFull)) {
            for (const item of arr) {
              foodDocs.push({ name:item.n, type:'gear', img:'icons/commodities/food/loaf-bread-brown.webp', system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          try {
            if (seedIntoWorld) {
              const folderMap = await ensureWorldFoodFolders(Object.keys(foodCategoriesFull));
              for (const doc of foodDocs) doc.folder = folderMap[doc.system.kategorie];
              await Item.create(foodDocs);
              console.log('[got-rpg] Food-Items als World-Items (mit Unterordnern) angelegt.');
              ui.notifications?.info('Food-Items als Weltobjekte mit Unterordnern eingefügt.');
            } else {
              const folderMap = await ensurePackFoodFolders(targetPack, Object.keys(foodCategoriesFull));
              for (const doc of foodDocs) doc.folder = folderMap[doc.system.kategorie];
              let createdF;
              if (targetPack.importDocuments) createdF = await targetPack.importDocuments(foodDocs);
              else if (targetPack.createDocuments) createdF = await targetPack.createDocuments(foodDocs);
              else createdF = await Promise.all(foodDocs.map(src => Item.create(src, {pack:targetPack.collection})));
              console.log('[got-rpg] World Food-Pack seeding mit Unterordnern Ergebnis:', createdF.map(c=>c.name));
              ui.notifications?.info('World Food-Pack mit Unterordnern eingefügt.');
            }
          } catch (foodErr) {
            console.warn('[got-rpg] Food-Seeding Fehler (locked fallback mit Unterordnern):', foodErr);
          }
        }
        // Locked Pack normaler Block wird übersprungen
      } else {
        // Ursprünglicher (unlocked) Food-Seeding Block folgt
      const fIndex = await fPack.getIndex();
      const foodCategories = {
        'Fleisch & Fisch': [
          { n:'Geräuchertes Schwein', w:1.0, p:{gd:0,sh:6,ks:0} },
          { n:'Gebratener Hirsch', w:1.5, p:{gd:0,sh:9,ks:0} },
          { n:'Eintopf aus Hammel', w:0.8, p:{gd:0,sh:5,ks:0} },
          { n:'Ziege am Spieß', w:1.2, p:{gd:0,sh:7,ks:0} },
          { n:'Lammkeule', w:1.0, p:{gd:0,sh:8,ks:0} },
          { n:'Rinderschmorbraten', w:1.4, p:{gd:0,sh:10,ks:0} },
          { n:'Wildschwein', w:1.6, p:{gd:0,sh:12,ks:0} },
          { n:'Gebratene Tauben', w:0.6, p:{gd:0,sh:4,ks:0} },
          { n:'Huhn am Spieß', w:1.0, p:{gd:0,sh:6,ks:0} },
          { n:'Geräucherte Forelle', w:0.5, p:{gd:0,sh:5,ks:0} },
          { n:'Gesalzener Dorsch', w:0.7, p:{gd:0,sh:6,ks:0} },
          { n:'Heiße Krabben', w:0.6, p:{gd:0,sh:9,ks:0} },
          { n:'Austern', w:0.4, p:{gd:0,sh:11,ks:0} },
          { n:'Aal', w:0.6, p:{gd:0,sh:7,ks:0} },
          { n:'Gepökelter Speck', w:0.5, p:{gd:0,sh:5,ks:0} }
        ],
        'Brot & Getreide': [
          { n:'Schwarzbrot (Nordbrot)', w:0.6, p:{gd:0,sh:3,ks:0} },
          { n:'Gerstenbrot', w:0.5, p:{gd:0,sh:2,ks:40} },
          { n:'Honigbrot', w:0.5, p:{gd:0,sh:4,ks:0} },
          { n:'Haferbrei', w:0.4, p:{gd:0,sh:2,ks:0} },
          { n:'Gerstenbrei', w:0.4, p:{gd:0,sh:2,ks:0} },
          { n:'Gebratene Zwiebeln', w:0.3, p:{gd:0,sh:1,ks:50} },
          { n:'Knoblauchknollen', w:0.2, p:{gd:0,sh:1,ks:20} },
          { n:'Gebackene Kartoffeln', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Geröstete Nüsse', w:0.3, p:{gd:0,sh:2,ks:50} },
          { n:'Hartkäse', w:0.7, p:{gd:0,sh:5,ks:0} }
        ],
        'Milch & Einfaches': [
          { n:'Butter', w:0.2, p:{gd:0,sh:2,ks:0} },
          { n:'Frischer Ziegenkäse', w:0.4, p:{gd:0,sh:4,ks:0} },
          { n:'Schafskäse', w:0.5, p:{gd:0,sh:5,ks:0} },
          { n:'Kuhmilch', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Rahm', w:0.3, p:{gd:0,sh:3,ks:0} },
          { n:'Dickmilch (Essos)', w:0.4, p:{gd:0,sh:3,ks:0} }
        ],
        'Früchte & Gemüse': [
          { n:'Äpfel', w:0.4, p:{gd:0,sh:2,ks:0} },
          { n:'Birnen', w:0.4, p:{gd:0,sh:2,ks:0} },
          { n:'Pflaumen', w:0.3, p:{gd:0,sh:2,ks:0} },
          { n:'Trauben', w:0.5, p:{gd:0,sh:3,ks:0} },
          { n:'Beerenmix', w:0.3, p:{gd:0,sh:2,ks:50} },
          { n:'Zwiebeln', w:0.3, p:{gd:0,sh:1,ks:50} },
          { n:'Rüben', w:0.5, p:{gd:0,sh:1,ks:50} },
          { n:'Möhren', w:0.4, p:{gd:0,sh:1,ks:50} },
          { n:'Kohl', w:0.8, p:{gd:0,sh:2,ks:0} },
          { n:'Lauch', w:0.3, p:{gd:0,sh:1,ks:50} }
        ],
        'Süßspeisen & Gebäck': [
          { n:'Törtchen mit Honig', w:0.2, p:{gd:0,sh:3,ks:0} },
          { n:'Zitronenkuchen', w:0.4, p:{gd:0,sh:6,ks:0} },
          { n:'Apfelkuchen', w:0.5, p:{gd:0,sh:5,ks:0} },
          { n:'Gebratene Kastanien', w:0.3, p:{gd:0,sh:2,ks:50} },
          { n:'Süßer Fruchtsirup', w:0.3, p:{gd:0,sh:7,ks:0} }
        ],
        'Eintöpfe & Gerichte': [
          { n:'Dicke Fleischsuppe', w:0.8, p:{gd:0,sh:5,ks:0} },
          { n:'Fischsuppe', w:0.8, p:{gd:0,sh:5,ks:0} },
          { n:'Brei-Eintopf aus Gemüse', w:0.7, p:{gd:0,sh:4,ks:0} },
          { n:'Bohnen mit Speck', w:0.7, p:{gd:0,sh:5,ks:0} }
        ]
      };
      if (fIndex.size === 0) {
        console.group('[got-rpg] Seeding Food-Pack');
        const foodDocs = [];
        for (const [cat, arr] of Object.entries(foodCategories)) {
          for (const item of arr) {
            foodDocs.push({
              name: `${item.n}`,
              type: 'gear',
              img: 'icons/commodities/food/loaf-bread-brown.webp', // Placeholder icon
              system: {
                equipped:false,
                gewicht:item.w,
                preis:item.p,
                beschreibung: `${cat}`,
                kategorie: cat,
                boni:{ attribute:{}, fertigkeiten:{} }
              }
            });
          }
        }
        let createdF;
        if (fPack.importDocuments) createdF = await fPack.importDocuments(foodDocs);
        else if (fPack.createDocuments) createdF = await fPack.createDocuments(foodDocs);
        else createdF = await Promise.all(foodDocs.map(src => Item.create(src, {pack:fPack.collection})));
        console.log('[got-rpg] Food-Pack seeding Ergebnis:', createdF.map(c=>c.name));
        console.groupEnd();
        ui.notifications?.info('Essen & Vorräte eingefügt.');
      } else {
        console.log('[got-rpg] Food-Pack bereits gefüllt, Größe:', fIndex.size);
        // Supplement fehlende
        const existingNames = new Set(Array.from(fIndex.values()).map(e=>e.name));
        const missingFood = [];
        for (const [cat, arr] of Object.entries(foodCategories)) {
          for (const item of arr) {
            if (!existingNames.has(item.n)) missingFood.push({
              name:item.n,
              type:'gear',
              img:'icons/commodities/food/loaf-bread-brown.webp',
              system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } }
            });
          }
        }
        if (missingFood.length) {
          console.group('[got-rpg] Ergänze fehlende Food Items');
            let createdMissingF;
            if (fPack.importDocuments) createdMissingF = await fPack.importDocuments(missingFood);
            else if (fPack.createDocuments) createdMissingF = await fPack.createDocuments(missingFood);
            else createdMissingF = await Promise.all(missingFood.map(src => Item.create(src, {pack:fPack.collection})));
            console.log('[got-rpg] Fehlende Food Items hinzugefügt:', createdMissingF.map(c=>c.name));
            console.groupEnd();
            ui.notifications?.info(`Fehlende Lebensmittel ergänzt: ${missingFood.length}`);
        }
      }
      } // Ende locked/unlocked Verzweigung
    }

    // Getränke Pack (Getränke)
    const dPack = game.packs.get('got-rpg.got-drinks');
    if (dPack) {
      const DRINK_PARENT = 'Getränke';
      // Icon-Mapping nach Kategorie
      const DRINK_ICONS = {
        'Weine (Westeros & Essos)': 'icons/consumables/drinks/wine-bottle-round-cork-green.webp',
        'Biere & Ales': 'icons/consumables/drinks/beer-pint-glass-brown.webp',
        'Spirituosen & harte Getränke': 'icons/consumables/drinks/whiskey-bottle-brown.webp',
        'Met & Honiggetränke': 'icons/consumables/drinks/mead-jug-clay-brown.webp',
        'Milchgetränke': 'icons/consumables/drinks/milk-jug-white.webp',
        'Kräuter- & Pflanzengetränke': 'icons/consumables/tea/teacup-chinese-white.webp',
        'Exotische & seltene Getränke': 'icons/consumables/potions/bottle-round-corked-pink.webp'
      };
      const drinkCategories = {
        'Weine (Westeros & Essos)': [
          { n:'Dornischer Rotwein', w:0.75, p:{gd:0,sh:10,ks:0} },
          { n:'Dornischer Weißwein', w:0.75, p:{gd:0,sh:11,ks:0} },
          { n:'Arbor-Gold', w:0.75, p:{gd:1,sh:50,ks:0} },
          { n:'Arbor-Rot', w:0.75, p:{gd:0,sh:18,ks:0} },
          { n:'Sommerwein', w:0.75, p:{gd:0,sh:14,ks:0} },
          { n:'Winterwein', w:0.75, p:{gd:0,sh:16,ks:0} },
          { n:'Stark gewürzter Klosterwein', w:0.75, p:{gd:0,sh:12,ks:0} },
          { n:'Billiger Tavernenwein', w:0.75, p:{gd:0,sh:3,ks:0} },
          { n:'Essosi-Süßwein', w:0.75, p:{gd:0,sh:15,ks:0} },
          { n:'Volantenischer Elefantenwein', w:0.75, p:{gd:0,sh:20,ks:0} }
        ],
        'Biere & Ales': [
          { n:'Starkbier aus den Nordlanden', w:1.0, p:{gd:0,sh:4,ks:0} },
          { n:'Braunes Ale', w:1.0, p:{gd:0,sh:3,ks:0} },
          { n:'Dünnes Bauernbier', w:1.0, p:{gd:0,sh:1,ks:30} },
          { n:'Gerstenbier', w:1.0, p:{gd:0,sh:2,ks:50} },
          { n:'Starkes Malzbier', w:1.0, p:{gd:0,sh:5,ks:0} },
          { n:'Dunkles Ale aus den Flusslanden', w:1.0, p:{gd:0,sh:4,ks:0} },
          { n:'Festbier', w:1.0, p:{gd:0,sh:5,ks:0} },
          { n:'Helles Getreidebier', w:1.0, p:{gd:0,sh:3,ks:0} },
          { n:'Scharfes Ingwerbier', w:1.0, p:{gd:0,sh:6,ks:0} },
          { n:'Hafen-Ale aus Königsmund', w:1.0, p:{gd:0,sh:4,ks:0} }
        ],
        'Spirituosen & harte Getränke': [
          { n:'Feuerwhisky / Feuerbrand', w:0.5, p:{gd:0,sh:18,ks:0} },
          { n:'Stark destillierter Kornbrand', w:0.5, p:{gd:0,sh:14,ks:0} },
          { n:'Kräuterschnaps', w:0.5, p:{gd:0,sh:12,ks:0} },
          { n:'Rübengeist', w:0.5, p:{gd:0,sh:9,ks:0} },
          { n:'Apfelbrand', w:0.5, p:{gd:0,sh:11,ks:0} },
          { n:'Starkes Dattel-Destillat', w:0.5, p:{gd:0,sh:20,ks:0} },
          { n:'Rotbrenn Tavernen-Spirituose', w:0.5, p:{gd:0,sh:8,ks:0} },
          { n:'Fermentierter Honigmet (hoch)', w:0.5, p:{gd:0,sh:15,ks:0} }
        ],
        'Met & Honiggetränke': [
          { n:'Honigmet (klassisch)', w:0.8, p:{gd:0,sh:8,ks:0} },
          { n:'Würzmet (Nelke/Zimt)', w:0.8, p:{gd:0,sh:10,ks:0} },
          { n:'Dünner Met (Volk)', w:0.8, p:{gd:0,sh:4,ks:0} },
          { n:'Met mit Beeren', w:0.8, p:{gd:0,sh:10,ks:0} },
          { n:'Starker Krieger-Met', w:0.8, p:{gd:0,sh:14,ks:0} }
        ],
        'Milchgetränke': [
          { n:'Heißer Milchwein', w:0.6, p:{gd:0,sh:5,ks:0} },
          { n:'Dickmilch (Norden)', w:0.6, p:{gd:0,sh:3,ks:0} },
          { n:'Buttertee (Wildlinge)', w:0.6, p:{gd:0,sh:5,ks:0} },
          { n:'Fermentierter Milchtrank', w:0.6, p:{gd:0,sh:7,ks:0} },
          { n:'Süße Ziegenmilch', w:0.6, p:{gd:0,sh:3,ks:0} },
          { n:'Gewürzte warme Milch', w:0.6, p:{gd:0,sh:4,ks:0} }
        ],
        'Kräuter- & Pflanzengetränke': [
          { n:'Pfefferminztee', w:0.3, p:{gd:0,sh:2,ks:0} },
          { n:'Kamillentee', w:0.3, p:{gd:0,sh:2,ks:0} },
          { n:'Bitterer Dornentee', w:0.3, p:{gd:0,sh:3,ks:0} },
          { n:'Süßgras-Aufguss', w:0.3, p:{gd:0,sh:4,ks:0} },
          { n:'Kräuterbrühe Krankentrunk', w:0.4, p:{gd:0,sh:3,ks:0} },
          { n:'Dornischer Zitronenaufguss', w:0.3, p:{gd:0,sh:4,ks:0} }
        ],
        'Exotische & seltene Getränke': [
          { n:'Mirisch-Minzlikör', w:0.5, p:{gd:0,sh:16,ks:0} },
          { n:'Qartheenischer Eiswein', w:0.5, p:{gd:0,sh:25,ks:0} },
          { n:'Braavosi-Spiritus', w:0.5, p:{gd:0,sh:30,ks:0} },
          { n:'Fermentierter Palmensaft', w:0.6, p:{gd:0,sh:11,ks:0} },
          { n:'Dunkler Schattenwein aus Asshai', w:0.5, p:{gd:1,sh:100,ks:0} }
        ]
      };
      const dIndex = await dPack.getIndex();
      const existingDNames = new Set(Array.from(dIndex.values()).map(e=>e.name));
      const needsSeed = dIndex.size === 0;
      // Folder Helfer für Drinks (Pack)
      async function ensureDrinkFolders(pack, categoryNames) {
        let parentFolder = game.folders.find(f => f.type==='Item' && f.pack===pack.collection && f.name===DRINK_PARENT && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: DRINK_PARENT, type:'Item', pack:pack.collection, sorting:'a' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type==='Item' && f.pack===pack.collection && f.name===cat && f.parent?.id===parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type:'Item', parent: parentFolder.id, pack: pack.collection, sorting:'a' });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      // World-Folder Fallback bei locked
      async function ensureWorldDrinkFolders(categoryNames) {
        let parentFolder = game.folders.find(f => f.type==='Item' && f.name===DRINK_PARENT && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: DRINK_PARENT, type:'Item' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type==='Item' && f.name===cat && f.parent?.id===parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type:'Item', parent: parentFolder.id });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      if (dPack.locked) {
        console.warn('[got-rpg] Getränke-Pack locked. Nutze World-Fallback.');
        // World seeding falls kein World Ersatz-Pack vorgesehen
        const worldExisting = game.items.contents.filter(i => i.system?.kategorie && Object.keys(drinkCategories).includes(i.system.kategorie));
        if (!worldExisting.length) {
          const folderMap = await ensureWorldDrinkFolders(Object.keys(drinkCategories));
          const docs = [];
          for (const [cat, arr] of Object.entries(drinkCategories)) {
            for (const item of arr) {
              docs.push({ name:item.n, type:'gear', folder:folderMap[cat], img:DRINK_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          await Item.create(docs);
          ui.notifications?.info('Getränke (World) mit Unterordnern eingefügt.');
        }
      } else {
        // Normales Pack-Seeding
        if (needsSeed) {
          console.group('[got-rpg] Seeding Getränke-Pack');
          const folderMap = await ensureDrinkFolders(dPack, Object.keys(drinkCategories));
          const docs = [];
          for (const [cat, arr] of Object.entries(drinkCategories)) {
            for (const item of arr) {
              docs.push({ name:item.n, type:'gear', folder:folderMap[cat], img:DRINK_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          let createdD;
          if (dPack.importDocuments) createdD = await dPack.importDocuments(docs);
          else if (dPack.createDocuments) createdD = await dPack.createDocuments(docs);
          else createdD = await Promise.all(docs.map(src => Item.create(src, {pack:dPack.collection})));
          console.log('[got-rpg] Getränke-Pack seeding Ergebnis:', createdD.map(c=>c.name));
          console.groupEnd();
          ui.notifications?.info('Getränke eingefügt.');
        } else {
          // Ergänzen fehlende Getränke
          const missing = [];
            for (const [cat, arr] of Object.entries(drinkCategories)) {
              for (const item of arr) {
                if (!existingDNames.has(item.n)) missing.push({ name:item.n, type:'gear', img:DRINK_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
              }
            }
          if (missing.length) {
            console.group('[got-rpg] Ergänze fehlende Getränke');
            let createdMissingD;
            if (dPack.importDocuments) createdMissingD = await dPack.importDocuments(missing);
            else if (dPack.createDocuments) createdMissingD = await dPack.createDocuments(missing);
            else createdMissingD = await Promise.all(missing.map(src => Item.create(src, {pack:dPack.collection})));
            console.log('[got-rpg] Fehlende Getränke hinzugefügt:', createdMissingD.map(c=>c.name));
            console.groupEnd();
            ui.notifications?.info(`Fehlende Getränke ergänzt: ${missing.length}`);
          }
        }
      }
    }

    // Medizin & Heilmittel Pack
    const mPack = game.packs.get('got-rpg.got-medicine');
    if (mPack) {
      const MED_PARENT = 'Medizin & Heilmittel';
      const MED_ICONS = {
        'Heilkräuter & pflanzliche Mittel': 'icons/consumables/herbs/leaf-spotted-green.webp',
        'Salben, Tinkturen & Öle': 'icons/consumables/potions/jar-round-corked-blue.webp',
        'Tränke, Aufgüsse & Mixturen': 'icons/consumables/potions/potion-bottle-corked-labeled-pink.webp',
        'Chirurgische & praktische Mittel': 'icons/tools/laboratory/bowl-mix-stone.webp'
      };
      const medCategories = {
        'Heilkräuter & pflanzliche Mittel': [
          { n:'Weirwood-Paste', w:0.1, p:{gd:5,sh:0,ks:0} },
          { n:'Schwarzsalbe', w:0.2, p:{gd:0,sh:8,ks:0} },
          { n:'Schafgarbe', w:0.1, p:{gd:0,sh:4,ks:0} },
          { n:'Kamille', w:0.1, p:{gd:0,sh:3,ks:0} },
          { n:'Katzenminze', w:0.1, p:{gd:0,sh:3,ks:50} },
          { n:'Milchdistel', w:0.1, p:{gd:0,sh:5,ks:0} },
          { n:'Bitterkraut', w:0.1, p:{gd:0,sh:6,ks:0} },
          { n:'Mäusedorn', w:0.1, p:{gd:0,sh:4,ks:0} },
          { n:'Schlangenkraut', w:0.1, p:{gd:0,sh:7,ks:0} },
          { n:'Wermut', w:0.1, p:{gd:0,sh:3,ks:0} }
        ],
        'Salben, Tinkturen & Öle': [
          { n:'Heilsalbe der Maester', w:0.3, p:{gd:0,sh:12,ks:0} },
          { n:'Kräuterkompressen', w:0.2, p:{gd:0,sh:5,ks:0} },
          { n:'Harzsalbe', w:0.2, p:{gd:0,sh:8,ks:0} },
          { n:'Nelkenöl', w:0.1, p:{gd:0,sh:6,ks:0} },
          { n:'Essigwasser', w:0.5, p:{gd:0,sh:2,ks:0} },
          { n:'Honigumschläge', w:0.2, p:{gd:0,sh:7,ks:0} },
          { n:'Aloe-Saft', w:0.3, p:{gd:0,sh:9,ks:0} }
        ],
        'Tränke, Aufgüsse & Mixturen': [
          { n:'Schlafwein', w:0.4, p:{gd:0,sh:15,ks:0} },
          { n:'Traumwein', w:0.4, p:{gd:0,sh:10,ks:0} },
          { n:'Mondtee', w:0.2, p:{gd:0,sh:8,ks:0} },
          { n:'Mohnblumensaft', w:0.2, p:{gd:0,sh:18,ks:0} },
          { n:'Kräutertee gegen Fieber', w:0.3, p:{gd:0,sh:4,ks:0} },
          { n:'Krankentrunk', w:0.4, p:{gd:0,sh:5,ks:0} },
          { n:'Tee aus Süßgras', w:0.3, p:{gd:0,sh:6,ks:0} }
        ],
        'Chirurgische & praktische Mittel': [
          { n:'Kupferkügelchen', w:0.05, p:{gd:0,sh:3,ks:0} },
          { n:'Schröpfgläser', w:0.5, p:{gd:0,sh:10,ks:0} },
          { n:'Wundnähte aus Katzendarm', w:0.02, p:{gd:0,sh:2,ks:0} },
          { n:'Abgekochtes Wasser', w:1.0, p:{gd:0,sh:0,ks:10} },
          { n:'Räucherkräuter (Desinfektion)', w:0.3, p:{gd:0,sh:5,ks:0} },
          { n:'Schienen aus Holz und Leder', w:1.5, p:{gd:0,sh:8,ks:0} }
        ]
      };
      const mIndex = await mPack.getIndex();
      const existingMNames = new Set(Array.from(mIndex.values()).map(e=>e.name));
      const needsMedSeed = mIndex.size === 0;
      // Folder Helfer für Medizin (Pack)
      async function ensureMedFolders(pack, categoryNames) {
        let parentFolder = game.folders.find(f => f.type==='Item' && f.pack===pack.collection && f.name===MED_PARENT && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: MED_PARENT, type:'Item', pack:pack.collection, sorting:'a' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type==='Item' && f.pack===pack.collection && f.name===cat && f.parent?.id===parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type:'Item', parent: parentFolder.id, pack: pack.collection, sorting:'a' });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      // World-Folder Fallback bei locked
      async function ensureWorldMedFolders(categoryNames) {
        let parentFolder = game.folders.find(f => f.type==='Item' && f.name===MED_PARENT && !f.parent);
        if (!parentFolder) parentFolder = await Folder.create({ name: MED_PARENT, type:'Item' });
        const mapping = {};
        for (const cat of categoryNames) {
          let sub = game.folders.find(f => f.type==='Item' && f.name===cat && f.parent?.id===parentFolder.id);
          if (!sub) sub = await Folder.create({ name: cat, type:'Item', parent: parentFolder.id });
          mapping[cat] = sub.id;
        }
        return mapping;
      }
      if (mPack.locked) {
        console.warn('[got-rpg] Medizin-Pack locked. Nutze World-Fallback.');
        const worldExisting = game.items.contents.filter(i => i.system?.kategorie && Object.keys(medCategories).includes(i.system.kategorie));
        if (!worldExisting.length) {
          const folderMap = await ensureWorldMedFolders(Object.keys(medCategories));
          const docs = [];
          for (const [cat, arr] of Object.entries(medCategories)) {
            for (const item of arr) {
              docs.push({ name:item.n, type:'gear', folder:folderMap[cat], img:MED_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          await Item.create(docs);
          ui.notifications?.info('Medizin (World) mit Unterordnern eingefügt.');
        }
      } else {
        // Normales Pack-Seeding
        if (needsMedSeed) {
          console.group('[got-rpg] Seeding Medizin-Pack');
          const folderMap = await ensureMedFolders(mPack, Object.keys(medCategories));
          const docs = [];
          for (const [cat, arr] of Object.entries(medCategories)) {
            for (const item of arr) {
              docs.push({ name:item.n, type:'gear', folder:folderMap[cat], img:MED_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
            }
          }
          let createdM;
          if (mPack.importDocuments) createdM = await mPack.importDocuments(docs);
          else if (mPack.createDocuments) createdM = await mPack.createDocuments(docs);
          else createdM = await Promise.all(docs.map(src => Item.create(src, {pack:mPack.collection})));
          console.log('[got-rpg] Medizin-Pack seeding Ergebnis:', createdM.map(c=>c.name));
          console.groupEnd();
          ui.notifications?.info('Medizin eingefügt.');
        } else {
          // Ergänzen fehlende Medizin
          const missing = [];
            for (const [cat, arr] of Object.entries(medCategories)) {
              for (const item of arr) {
                if (!existingMNames.has(item.n)) missing.push({ name:item.n, type:'gear', img:MED_ICONS[cat], system:{ equipped:false, gewicht:item.w, preis:item.p, beschreibung:cat, kategorie:cat, boni:{ attribute:{}, fertigkeiten:{} } } });
              }
            }
          if (missing.length) {
            console.group('[got-rpg] Ergänze fehlende Medizin');
            let createdMissingM;
            if (mPack.importDocuments) createdMissingM = await mPack.importDocuments(missing);
            else if (mPack.createDocuments) createdMissingM = await mPack.createDocuments(missing);
            else createdMissingM = await Promise.all(missing.map(src => Item.create(src, {pack:mPack.collection})));
            console.log('[got-rpg] Fehlende Medizin hinzugefügt:', createdMissingM.map(c=>c.name));
            console.groupEnd();
            ui.notifications?.info(`Fehlende Medizin ergänzt: ${missing.length}`);
          }
        }
      }
    }

    // --- Nachbereitungs-Cleanup: vereinheitliche evtl. verbliebene Waffen-Icons & reindex ---
    try {
      const PLACEHOLDER_ICON = 'icons/svg/sword.svg';
      const wPackCleanup = game.packs.get('got-rpg.got-weapons');
      if (wPackCleanup) {
        // Reindex in dieser Foundry-Version nicht verfügbar – Index neu laden via getIndex()
        await wPackCleanup.getIndex();
        const docs = await wPackCleanup.getDocuments();
        const packFixes = [];
        for (const it of docs) {
          if (it.type === 'weapon' && /^icons\/weapons\//.test(it.img)) {
            packFixes.push({ _id: it.id, img: PLACEHOLDER_ICON });
          }
        }
        if (packFixes.length) {
          await wPackCleanup.updateDocuments(packFixes);
          console.log('[got-rpg] Weapon image cleanup applied (pack):', packFixes.length);
        } else {
          console.log('[got-rpg] Weapon image cleanup: keine Pack-Fixes nötig.');
        }
      }
      // World Items normalisieren
      const worldFixes = [];
      for (const it of game.items.contents) {
        if (it.type === 'weapon' && /^icons\/weapons\//.test(it.img)) {
          worldFixes.push({ _id: it.id, img: PLACEHOLDER_ICON });
        }
      }
      if (worldFixes.length) {
        await Item.updateDocuments(worldFixes);
        console.log('[got-rpg] Weapon image cleanup applied (world):', worldFixes.length);
      } else {
        console.log('[got-rpg] Weapon image cleanup: keine World-Fixes nötig.');
      }
    } catch (cleanupErr) {
      console.warn('[got-rpg] Cleanup Fehler:', cleanupErr);
    }
  } catch (e) {
    console.warn('Seeding Packs fehlgeschlagen:', e);
  }
});

// --- Manuelle Rebuild-Funktion für Waffen-Pack (Chat-Befehl /got-rebuild-weapons) ---
Hooks.once('ready', () => {
  game.gotRpgRebuildWeapons = async () => {
    try {
      const wPack = game.packs.get('got-rpg.got-weapons');
      if (!wPack) { ui.notifications?.warn('Waffen-Pack nicht gefunden.'); return; }
      const docs = await wPack.getDocuments();
      // Sicheres Löschen: einzeln entfernen (deleteDocuments fehlt in dieser Foundry-Version)
      if (docs.length) {
        for (const d of docs) {
          try { await d.delete(); } catch (delErr) { console.warn('Delete Fehler für', d.name, delErr); }
        }
        // Reindex ersetzt durch erneutes Laden des Index
        await wPack.getIndex();
      }
      const PLACEHOLDER_ICON = 'icons/svg/sword.svg';
      const full = [
        'Langschwert','Kurzschwert','Dolch / Messer','Speer','Lanze','Jagdspieß','Hellebarde','Kriegshammer','Streithammer','Streitkolben (Morgenstern)','Keule','Axt (einfach)','Doppelaxt','Wurfaxt','Bogen','Langbogen','Armbrust','Schild','Streitflegel','Sichelklinge / Bauernwerkzeug'
      ];
      // Gewicht & Preis grob an Basis-Liste angleichen statt alles identisch
      const baseData = {
        'Langschwert': {gewicht:3, preis:{gd:0,sh:50,ks:0}, reichweite:'Nahkampf'},
        'Kurzschwert': {gewicht:2, preis:{gd:0,sh:30,ks:0}, reichweite:'Nahkampf'},
        'Dolch / Messer': {gewicht:0.5, preis:{gd:0,sh:5,ks:0}, reichweite:'Nahkampf/Wurf'},
        'Speer': {gewicht:2, preis:{gd:0,sh:10,ks:0}, reichweite:'Nahkampf/Wurf'},
        'Lanze': {gewicht:4, preis:{gd:0,sh:40,ks:0}, reichweite:'Beritten'},
        'Jagdspieß': {gewicht:3, preis:{gd:0,sh:15,ks:0}, reichweite:'Nahkampf'},
        'Hellebarde': {gewicht:5, preis:{gd:0,sh:45,ks:0}, reichweite:'Nahkampf'},
        'Kriegshammer': {gewicht:4, preis:{gd:0,sh:35,ks:0}, reichweite:'Nahkampf'},
        'Streithammer': {gewicht:3, preis:{gd:0,sh:25,ks:0}, reichweite:'Nahkampf'},
        'Streitkolben (Morgenstern)': {gewicht:3, preis:{gd:0,sh:30,ks:0}, reichweite:'Nahkampf'},
        'Keule': {gewicht:2, preis:{gd:0,sh:2,ks:0}, reichweite:'Nahkampf'},
        'Axt (einfach)': {gewicht:3, preis:{gd:0,sh:20,ks:0}, reichweite:'Nahkampf'},
        'Doppelaxt': {gewicht:5, preis:{gd:0,sh:50,ks:0}, reichweite:'Nahkampf'},
        'Wurfaxt': {gewicht:1, preis:{gd:0,sh:8,ks:0}, reichweite:'Wurf'},
        'Bogen': {gewicht:1, preis:{gd:0,sh:15,ks:0}, reichweite:'Fernkampf'},
        'Langbogen': {gewicht:2, preis:{gd:0,sh:40,ks:0}, reichweite:'Fernkampf'},
        'Armbrust': {gewicht:4, preis:{gd:0,sh:60,ks:0}, reichweite:'Fernkampf'},
        'Schild': {gewicht:3, preis:{gd:0,sh:25,ks:0}, reichweite:'Nahkampf'},
        'Streitflegel': {gewicht:3, preis:{gd:0,sh:28,ks:0}, reichweite:'Nahkampf'},
        'Sichelklinge / Bauernwerkzeug': {gewicht:1, preis:{gd:0,sh:3,ks:0}, reichweite:'Nahkampf'}
      };
      const payload = full.map(n => ({
        name:n,
        type:'weapon',
        img:PLACEHOLDER_ICON,
        system:{
          equipped:false,
          gewicht: baseData[n].gewicht,
          preis: baseData[n].preis,
          schaden:'1d6',
          reichweite: baseData[n].reichweite,
          beschreibung:n,
          boni:{ attribute:{}, fertigkeiten:{} }
        }
      }));
      let created;
      if (wPack.importDocuments) created = await wPack.importDocuments(payload);
      else if (wPack.createDocuments) created = await wPack.createDocuments(payload);
      else created = await Promise.all(payload.map(src => Item.create(src, {pack: wPack.collection})));      
      // Reindex ersetzt durch erneutes Laden des Index
      await wPack.getIndex();
      console.log('[got-rpg] Rebuild Waffen-Pack:', created.map(c=>c.name));
      ui.notifications?.info(`Waffen-Pack neu aufgebaut (${created.length} Einträge).`);
    } catch (err) {
      console.error('Rebuild Waffen-Pack Fehler:', err);
      ui.notifications?.error('Rebuild Waffen-Pack fehlgeschlagen – Konsole prüfen.');
    }
  };
});

Hooks.on('chatMessage', (log, content, data) => {
  if (content?.trim() === '/got-rebuild-weapons') {
    game.gotRpgRebuildWeapons();
    return false;
  }
  if (content?.trim() === '/got-clean-ff') {
    // Bereinige ALLE ActiveEffects vom ausgewählten Actor (radikale Variante)
    const actor = canvas?.tokens?.controlled?.[0]?.actor || game.user?.character;
    if (!actor) {
      ui.notifications?.warn('Kein Actor ausgewählt. Wähle einen Token oder setze einen Standard-Charakter.');
      return false;
    }
    (async () => {
      try {
        const allEffects = Array.from(actor.effects || []);
        const allIds = allEffects.map(e => e.id);
        if (allIds.length) {
          await actor.deleteEmbeddedDocuments('ActiveEffect', allIds);
          ui.notifications?.info(`Alle ${allIds.length} ActiveEffects entfernt. Lege die Lederhandschuhe jetzt neu an.`);
        } else {
          ui.notifications?.info('Keine ActiveEffects gefunden.');
        }
      } catch (e) {
        console.error('Fehler bei Cleanup:', e);
        ui.notifications?.error('Cleanup fehlgeschlagen – siehe Konsole.');
      }
    })();
    return false;
  }
});

// --- Item Effekt-Helferfunktionen am Prototyp der Sheet-Klasse -----------------
GotCharacterSheet.prototype._buildItemEffectChanges = function (item) {
  const changes = [];
  try {
    const sys = item.system || {};
    const attr = (sys.boni && sys.boni.attribute) ? sys.boni.attribute : {};
    const skills = (sys.boni && sys.boni.fertigkeiten) ? sys.boni.fertigkeiten : {};

    // Attribute-Boni
    for (const [key, bonus] of Object.entries(attr)) {
      const val = Number(bonus) || 0;
      if (!val) continue;
      changes.push({ key: `system.attribute.${key}.value`, mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: val, priority: 20 });
    }

    // Fertigkeits-Boni (alle erlauben, Fingerfertigkeit nicht mehr exklusiv)
    for (const [key, bonus] of Object.entries(skills)) {
      let val = Number(bonus) || 0;
      if (!val) continue;
      // Begrenze extrem hohe Werte zur Sicherheit
      if (val > 10) val = 10;
      if (val < -10) val = -10;
      changes.push({ key: `system.fertigkeiten.${key}`, mode: CONST.ACTIVE_EFFECT_MODES.ADD, value: val, priority: 20 });
    }
  } catch (e) {
    console.warn('Fehler beim Erzeugen der Item-Änderungen', e);
  }
  return changes;
};

GotCharacterSheet.prototype._findItemEffect = function (item) {
  if (!this.actor?.effects) return null;
  const effs = this.actor.effects;
  
  const byFlag = effs.find(e => e.getFlag('got-rpg', 'itemEffect') === item.id);
  if (byFlag) return byFlag;
  
  // Fallback: über origin suchen
  const byOrigin = effs.find(e => e.origin === item.uuid);
  if (byOrigin) return byOrigin;
  
  // Last resort: match by standardized name
  const byName = effs.find(e => e.name === `Item: ${item.name}`);
  return byName || null;
};

GotCharacterSheet.prototype._upsertItemEffect = async function (item) {
  // Guard gegen gleichzeitige Aufrufe für dasselbe Item
  const lockKey = `_effectLock_${item.id}`;
  if (this[lockKey]) return;
  this[lockKey] = true;
  
  try {
    const changes = this._buildItemEffectChanges(item);
    if (!changes.length) return; // nichts anzuwenden
    
    // Finde existierenden Effekt (nur ein Match, kein Dedup)
    const existing = this._findItemEffect(item);
    if (existing) {
      await existing.update({ changes });
      return existing;
    }
    
    // Erstelle neuen Effekt
    const data = {
      name: `Item: ${item.name}`,
      label: `Item: ${item.name}`,
      origin: item.uuid,
      changes,
      disabled: false,
      flags: { 'got-rpg': { itemEffect: item.id } }
    };
    
    const created = await this.actor.createEmbeddedDocuments('ActiveEffect', [data]);
    return created?.[0] || null;
  } finally {
    delete this[lockKey];
  }
};

GotCharacterSheet.prototype._removeItemEffect = async function (item) {
  // Finde ALLE Effekte für dieses Item (auch Duplikate) und lösche sie
  const toDelete = this.actor.effects.filter(e => (
    e.getFlag('got-rpg', 'itemEffect') === item.id ||
    e.origin === item.uuid ||
    e.name === `Item: ${item.name}`
  )).map(e => e.id);
  if (toDelete.length) {
    await this.actor.deleteEmbeddedDocuments('ActiveEffect', toDelete);
  }
};

// ============================================================================
// MIGRATION: Attribute-Umbenennung (geschick->geschicklichkeit, intuition->intelligenz, wissen->zaehigkeit)
// Führt einmalig beim Laden aus. Erstellt fehlende neue Keys aus alten, ohne alte zu löschen.
// Migriert auch Item-Boni.
// ============================================================================
Hooks.once('ready', async () => {
  try {
    for (const actor of game.actors?.contents || []) {
      if (actor.type !== 'character') continue;
      const sys = actor.system || {};
      const a = sys.attribute || {};
      const update = {};
      // Actor Attribute Migration
      if (a.geschick && !a.geschicklichkeit) {
        const val = (typeof a.geschick === 'object') ? (a.geschick.value ?? 0) : a.geschick;
        update['system.attribute.geschicklichkeit.value'] = Number(val) || 0;
      }
      if (a.intuition && !a.intelligenz) {
        const val = (typeof a.intuition === 'object') ? (a.intuition.value ?? 0) : a.intuition;
        update['system.attribute.intelligenz.value'] = Number(val) || 0;
      }
      if (a.wissen && !a.zaehigkeit) {
        const val = (typeof a.wissen === 'object') ? (a.wissen.value ?? 0) : a.wissen;
        // Nur setzen wenn noch keine Zähigkeit vorhanden
        update['system.attribute.zaehigkeit.value'] = Number(val) || 0;
      }
      if (!a.willenskraft) {
        update['system.attribute.willenskraft.value'] = 0;
      }
      if (Object.keys(update).length) {
        await actor.update(update);
      }
      // Item Boni Migration
      for (const item of actor.items || []) {
        const boniAttr = item.system?.boni?.attribute;
        if (!boniAttr) continue;
        const itemUpdates = {};
        if (boniAttr.geschick !== undefined && boniAttr.geschicklichkeit === undefined) {
          itemUpdates['system.boni.attribute.geschicklichkeit'] = boniAttr.geschick;
        }
        if (boniAttr.intuition !== undefined && boniAttr.intelligenz === undefined) {
          itemUpdates['system.boni.attribute.intelligenz'] = boniAttr.intuition;
        }
        if (boniAttr.wissen !== undefined && boniAttr.zaehigkeit === undefined) {
          itemUpdates['system.boni.attribute.zaehigkeit'] = boniAttr.wissen;
        }
        if (Object.keys(itemUpdates).length) {
          await item.update(itemUpdates);
        }
      }
    }
    Logger.log('Attribut-Migration abgeschlossen.');
  } catch (e) {
    Logger.warn('Attribut-Migration fehlgeschlagen:', e);
  }
});

// ============================================
// OPTIONAL: Rolltabellen-System initialisieren (DEAKTIVIERT)
// ============================================
// Rufe Hook-Registrierung auf (nur wenn Import oben aktiviert ist)
// if (typeof registerRolltableHooks === 'function') {
//   registerRolltableHooks();
// }
// ============================================
