# GoT RPG - Rolltabellen & SL-Makros

Dieses Feature ist **modular** aufgebaut und kann jederzeit aktiviert oder deaktiviert werden.

## 🎲 Enthaltene Features

### Rolltabellen
- **Intrigen-Ereignisse** - Politische Verwicklungen und Komplotte
- **Reise-Komplikationen** - Unvorhergesehene Ereignisse auf Reisen
- **Gerüchte** - Klatsch aus den Sieben Königslanden
- **Haus-Ereignisse** - Ereignisse die ein Adelshaus betreffen

### SL-Makros
- Würfle zufälliges Gerücht
- Würfle Haus-Ereignis
- Würfle Intrigen-Ereignis
- Würfle Reise-Komplikation
- Wähle zufälligen NSC (aus allen oder aus Ordner)

## ✅ Feature AKTIVIEREN

Das Feature ist **standardmäßig AKTIVIERT**.

Falls es deaktiviert wurde, zum Aktivieren:

1. Öffne `module/got-rpg.js`
2. Finde die Zeile (ca. Zeile 11):
   ```javascript
   // import { registerRolltableHooks } from './init-rolltables.js';
   ```
3. Entferne die `//` am Anfang:
   ```javascript
   import { registerRolltableHooks } from './init-rolltables.js';
   ```
4. Speichere die Datei
5. Lade Foundry neu (F5)

## ❌ Feature DEAKTIVIEREN

Um das Feature zu deaktivieren:

1. Öffne `module/got-rpg.js`
2. Finde die Zeile (ca. Zeile 11):
   ```javascript
   import { registerRolltableHooks } from './init-rolltables.js';
   ```
3. Setze `//` vor die Zeile:
   ```javascript
   // import { registerRolltableHooks } from './init-rolltables.js';
   ```
4. Speichere die Datei
5. Lade Foundry neu (F5)

## 🗑️ Feature KOMPLETT ENTFERNEN

Falls du das Feature komplett löschen willst:

1. Deaktiviere es wie oben beschrieben
2. Lösche folgende Dateien/Ordner:
   - `module/logic/rolltables.js`
   - `module/logic/macros.js`
   - `module/logic/rolltables-init.js`
   - `module/init-rolltables.js`
   - `styles/rolltables.css`
3. Entferne aus `system.json` die Zeile:
   ```json
   "styles/rolltables.css"
   ```
4. Entferne aus `got-rpg.js` alle Zeilen die mit "OPTIONAL: Rolltabellen" markiert sind

## 📖 Verwendung

### In Foundry (für GMs)

#### Über Scene Controls
1. Klicke auf das Notizen-Icon in der linken Toolbar
2. Klicke auf "GoT Rolltabellen" 📜 oder "GoT SL-Makros" 🎲

#### Über die Konsole (F12)
```javascript
// Rolltabelle würfeln
game.gotRpg.rolltables.roll('geruechte');    // Gerüchte
game.gotRpg.rolltables.roll('haus');         // Haus-Ereignisse
game.gotRpg.rolltables.roll('intrigen');     // Intrigen
game.gotRpg.rolltables.roll('reise');        // Reise-Komplikationen

// Dialog öffnen
game.gotRpg.rolltables.showDialog();

// Makros ausführen
game.gotRpg.macros.rollRandomRumor();        // Zufälliges Gerücht
game.gotRpg.macros.rollHouseEvent();         // Haus-Ereignis
game.gotRpg.macros.pickRandomNPC();          // Zufälliger NSC
game.gotRpg.macros.pickRandomNPC('Stadtwache'); // NSC aus Ordner
game.gotRpg.macros.showMacroDialog();        // Makro-Dialog
```

#### Foundry-Makros erstellen (optional)

Um vorgefertigte Makros zu erstellen, öffne `module/logic/rolltables-init.js` und entferne die Kommentarzeichen:

```javascript
// Vorher (auskommentiert):
/*
Hooks.once('ready', async () => {
  await setupMacros();
});
*/

// Nachher (aktiviert):
Hooks.once('ready', async () => {
  await setupMacros();
});
```

Nach einem Reload werden 6 Makros erstellt die in der Makro-Leiste erscheinen.

## 📝 Eigene Tabellen hinzufügen

Bearbeite `module/logic/rolltables.js`:

```javascript
export const ROLLTABLES = {
  // ... bestehende Tabellen ...
  
  meine_tabelle: {
    name: "Meine eigene Tabelle",
    description: "Beschreibung",
    entries: [
      "Eintrag 1",
      "Eintrag 2",
      "Eintrag 3",
      // ... mehr Einträge
    ]
  }
};
```

Dann kannst du sie verwenden mit:
```javascript
game.gotRpg.rolltables.roll('meine_tabelle');
```

## 🎨 Styling anpassen

Bearbeite `styles/rolltables.css` um das Aussehen der Chat-Ausgaben zu ändern.

## ⚠️ Wichtig

- Das Feature hat **keine Abhängigkeiten** zu anderen Systemteilen
- Es kann **jederzeit** aktiviert/deaktiviert werden
- **Keine Daten** gehen verloren beim Deaktivieren
- Alle Dateien sind **klar gekennzeichnet** und dokumentiert
